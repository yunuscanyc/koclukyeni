export interface WinFormsFile {
  name: string;
  category: 'Model' | 'Form' | 'Designer' | 'Veritabanı' | 'Program';
  description: string;
  code: string;
}

export const WINFORMS_PROJECT_FILES: WinFormsFile[] = [
  {
    name: 'Ogrenci.cs',
    category: 'Model',
    description: 'Kapsamlı Öğrenci Entity Sınıfı (YKS Hedefleri ve Koçluk Alanları)',
    code: `using System;
using System.Collections.Generic;

namespace EgitimKocluğu.Models
{
    public enum SinifSeviyesi
    {
        Sinif9,
        Sinif10,
        Sinif11,
        Sinif12,
        Mezun
    }

    public enum YksAlani
    {
        Sayisal,
        EsitAgirlik,
        Sozel,
        Dil
    }

    public enum OgrenciDurumu
    {
        Aktif,
        Pasif
    }

    public class Ogrenci
    {
        public int Id { get; set; }
        public string AdSoyad { get; set; }
        public DateTime? DogumTarihi { get; set; }
        
        // ComboBox Seçimleri
        public SinifSeviyesi Sinif { get; set; }
        public YksAlani Alan { get; set; }
        public int YksHedefYili { get; set; } // Örn: 2026, 2027
        
        // Ayrıştırılmış Üniversite ve Bölüm Bilgisi
        public string HedefUniversite { get; set; }
        public string HedefBolum { get; set; }
        
        // Hedef İstatistikleri
        public double HedefPuan { get; set; }
        public int HedefSiralama { get; set; }
        
        public DateTime KayitTarihi { get; set; } = DateTime.Now;
        public OgrenciDurumu Durum { get; set; } = OgrenciDurumu.Aktif;
        
        public string GenelKocNotu { get; set; }

        // İlişkili Alt Kayıtlar (Bire-Çok)
        public List<KocNotu> Notlar { get; set; } = new List<KocNotu>();
        public List<GunlukCalisma> Calismalar { get; set; } = new List<GunlukCalisma>();
        public List<SoruKaydi> Sorular { get; set; } = new List<SoruKaydi>();
        public List<DenemeSinavi> Denemeler { get; set; } = new List<DenemeSinavi>();
        public List<KazanimDurumu> Kazanimlar { get; set; } = new List<KazanimDurumu>();

        public override string ToString()
        {
            return $"{AdSoyad} ({Sinif} - {Alan})";
        }
    }
}`
  },
  {
    name: 'AltKayitModelleri.cs',
    category: 'Model',
    description: 'Koç Notları, Günlük Çalışmalar, Soru Takibi, Denemeler ve Kazanım Modelleri',
    code: `using System;

namespace EgitimKocluğu.Models
{
    public class KocNotu
    {
        public int Id { get; set; }
        public int OgrenciId { get; set; }
        public DateTime Tarih { get; set; } = DateTime.Now;
        public string Baslik { get; set; }
        public string Icerik { get; set; }
        public string Kategori { get; set; } // Haftalık, Hedef, Veli, vb.
        public string Oncelik { get; set; }  // Kritik, Önemli, Normal
    }

    public class GunlukCalisma
    {
        public int Id { get; set; }
        public int OgrenciId { get; set; }
        public DateTime Tarih { get; set; } = DateTime.Now;
        public string Ders { get; set; }
        public string Konu { get; set; }
        public int SureDakika { get; set; }
        public int VerimlilikPuani { get; set; } // 1 - 5 arası
        public bool KocOnayi { get; set; }
        public string Notlar { get; set; }
    }

    public class SoruKaydi
    {
        public int Id { get; set; }
        public int OgrenciId { get; set; }
        public DateTime Tarih { get; set; } = DateTime.Now;
        public string Ders { get; set; }
        public string Konu { get; set; }
        public int DogruSayisi { get; set; }
        public int YanlisSayisi { get; set; }
        public int BosSayisi { get; set; }

        public int ToplamSoru => DogruSayisi + YanlisSayisi + BosSayisi;
        public double BasariYuzdesi => ToplamSoru > 0 ? Math.Round(((double)DogruSayisi / ToplamSoru) * 100, 1) : 0;
    }

    public class DenemeSinavi
    {
        public int Id { get; set; }
        public int OgrenciId { get; set; }
        public string SinavTuru { get; set; } // "TYT" veya "AYT"
        public string SinavAdi { get; set; }
        public string YayinEvi { get; set; }
        public DateTime Tarih { get; set; } = DateTime.Now;

        // TYT Netleri
        public double? TurkceNet { get; set; }
        public double? SosyalNet { get; set; }
        public double? TemelMatNet { get; set; }
        public double? FenNet { get; set; }

        // AYT Netleri
        public double? AytMatNet { get; set; }
        public double? AytFizikNet { get; set; }
        public double? AytKimyaNet { get; set; }
        public double? AytBiyolojiNet { get; set; }
        public double? AytEdebiyatNet { get; set; }
        public double? AytTarihNet { get; set; }
        public double? AytCografyaNet { get; set; }

        public double ToplamNet { get; set; }
        public double TahminiPuan { get; set; }
        public string KocGorusNotu { get; set; }
    }

    public class KazanimDurumu
    {
        public int Id { get; set; }
        public int OgrenciId { get; set; }
        public string SinavGrubu { get; set; } // TYT / AYT
        public string Ders { get; set; }
        public string KonuBasligi { get; set; }
        public string Durum { get; set; } // Tamamlandı, Eksik Var, Tekrar Edilecek, Başlanmadı
        public string Aciklama { get; set; }
    }
}`
  },
  {
    name: 'FormOgrenciProfil.cs',
    category: 'Form',
    description: 'Windows Forms Ana Profil Ekranı (TabControl, ComboBoxes, DataGridView)',
    code: `using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using EgitimKocluğu.Models;
using EgitimKocluğu.Database;

namespace EgitimKocluğu
{
    public partial class FormOgrenciProfil : Form
    {
        private Ogrenci _aktifOgrenci;
        private readonly DatabaseContext _db;

        public FormOgrenciProfil()
        {
            InitializeComponent();
            _db = new DatabaseContext();
        }

        private void FormOgrenciProfil_Load(object sender, EventArgs e)
        {
            // ComboBox Verilerini Yükle
            YukleComboBoxSecenekleri();
            
            // Öğrenci Listesini Getir
            YenileOgrenciListesi();
        }

        private void YukleComboBoxSecenekleri()
        {
            // Sınıf ComboBox
            cmbSinif.Items.Clear();
            cmbSinif.Items.AddRange(new object[] { 
                "9. Sınıf", 
                "10. Sınıf", 
                "11. Sınıf", 
                "12. Sınıf", 
                "Mezun" 
            });

            // Alan ComboBox
            cmbAlan.Items.Clear();
            cmbAlan.Items.AddRange(new object[] { 
                "Sayısal", 
                "Eşit Ağırlık", 
                "Sözel", 
                "Dil" 
            });

            // YKS Hedef Yılı ComboBox
            cmbYksYili.Items.Clear();
            int buYil = DateTime.Now.Year;
            for (int i = buYil; i <= buYil + 4; i++)
            {
                cmbYksYili.Items.Add(i.ToString());
            }

            // Durum ComboBox
            cmbDurum.Items.Clear();
            cmbDurum.Items.AddRange(new object[] { "Aktif", "Pasif" });
        }

        private void YenileOgrenciListesi()
        {
            lstOgrenciler.DataSource = null;
            var ogrenciler = _db.TumOgrencileriGetir();
            lstOgrenciler.DataSource = ogrenciler;
            lstOgrenciler.DisplayMember = "AdSoyad";
            lstOgrenciler.ValueMember = "Id";

            if (ogrenciler.Any())
            {
                lstOgrenciler.SelectedIndex = 0;
            }
        }

        private void lstOgrenciler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstOgrenciler.SelectedItem is Ogrenci secilen)
            {
                _aktifOgrenci = secilen;
                GosterOgrenciProfilDetaylari(secilen);
            }
        }

        private void GosterOgrenciProfilDetaylari(Ogrenci ogrenci)
        {
            // 1. GENEL BİLGİLER SEKMESİ
            txtAdSoyad.Text = ogrenci.AdSoyad;
            dtpDogumTarihi.Value = ogrenci.DogumTarihi ?? DateTime.Now.AddYears(-17);
            cmbSinif.SelectedItem = ogrenci.Sinif.ToString().Replace("Sinif", "") + (ogrenci.Sinif == SinifSeviyesi.Mezun ? "" : ". Sınıf");
            cmbAlan.SelectedItem = ogrenci.Alan.ToString();
            cmbYksYili.SelectedItem = ogrenci.YksHedefYili.ToString();
            txtHedefUniversite.Text = ogrenci.HedefUniversite;
            txtHedefBolum.Text = ogrenci.HedefBolum;
            txtHedefPuan.Text = ogrenci.HedefPuan.ToString();
            txtHedefSiralama.Text = ogrenci.HedefSiralama.ToString("N0");
            cmbDurum.SelectedItem = ogrenci.Durum.ToString();
            txtKocNotu.Text = ogrenci.GenelKocNotu;

            // 2. KOÇ NOTLARI SEKMESİ
            dgvKocNotlari.DataSource = _db.OgrenciNotlariniGetir(ogrenci.Id);

            // 3. GÜNLÜK ÇALIŞMALAR SEKMESİ
            dgvCalismalar.DataSource = _db.OgrenciCalismalariniGetir(ogrenci.Id);

            // 4. SORU TAKİBİ SEKMESİ
            dgvSorular.DataSource = _db.OgrenciSorulariniGetir(ogrenci.Id);

            // 5. DENEMELER SEKMESİ
            dgvDenemeler.DataSource = _db.OgrenciDenemeleriniGetir(ogrenci.Id);

            // 6. KAZANIMLAR SEKMESİ
            dgvKazanimlar.DataSource = _db.OgrenciKazanimlariniGetir(ogrenci.Id);

            // 7. RAPORLAR SEKMESİ
            HesaplaVeGosterRaporlar(ogrenci);
        }

        private void HesaplaVeGosterRaporlar(Ogrenci ogrenci)
        {
            var denemeler = _db.OgrenciDenemeleriniGetir(ogrenci.Id);
            var sonDeneme = denemeler.OrderByDescending(d => d.Tarih).FirstOrDefault();

            double mevcutPuan = sonDeneme?.TahminiPuan ?? 0;
            double hedefPuan = ogrenci.HedefPuan;
            double puanFarki = hedefPuan - mevcutPuan;

            lblRaporHedefUniversite.Text = $"Hedef: {ogrenci.HedefUniversite} - {ogrenci.HedefBolum}";
            lblRaporHedefPuan.Text = $"Hedef Puan: {hedefPuan} | Hedef Sıralama: {ogrenci.HedefSiralama:N0}";
            lblRaporMevcutPuan.Text = $"Son Deneme Puanı: {mevcutPuan:F1} (Net: {sonDeneme?.ToplamNet ?? 0:F1})";
            lblRaporFark.Text = puanFarki > 0 ? $"Gereken Artış: +{puanFarki:F1} Puan" : "Hedefe Ulaşıldı!";
            lblRaporFark.ForeColor = puanFarki > 0 ? Color.DarkRed : Color.DarkGreen;
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (_aktifOgrenci == null) return;

            _aktifOgrenci.AdSoyad = txtAdSoyad.Text.Trim();
            _aktifOgrenci.DogumTarihi = dtpDogumTarihi.Value;
            _aktifOgrenci.HedefUniversite = txtHedefUniversite.Text.Trim();
            _aktifOgrenci.HedefBolum = txtHedefBolum.Text.Trim();
            double.TryParse(txtHedefPuan.Text, out double hp);
            _aktifOgrenci.HedefPuan = hp;
            int.TryParse(txtHedefSiralama.Text.Replace(".", "").Replace(",", ""), out int hs);
            _aktifOgrenci.HedefSiralama = hs;
            _aktifOgrenci.GenelKocNotu = txtKocNotu.Text.Trim();

            _db.OgrenciGuncelle(_aktifOgrenci);
            MessageBox.Show("Öğrenci profili başarıyla güncellendi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            YenileOgrenciListesi();
        }

        private void btnYeniOgrenci_Click(object sender, EventArgs e)
        {
            using (var formEkle = new FormOgrenciEkle())
            {
                if (formEkle.ShowDialog() == DialogResult.OK)
                {
                    YenileOgrenciListesi();
                }
            }
        }
    }
}`
  },
  {
    name: 'FormOgrenciProfil.Designer.cs',
    category: 'Designer',
    description: 'Windows Forms Designer Kodları (SplitContainer, TabControl, 7 TabPage)',
    code: `namespace EgitimKocluğu
{
    partial class FormOgrenciProfil
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dosyaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeniOgrenciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cikisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainerMain = new System.Windows.Forms.SplitContainer();
            this.grpOgrenciListesi = new System.Windows.Forms.GroupBox();
            this.lstOgrenciler = new System.Windows.Forms.ListBox();
            this.txtOgrenciAra = new System.Windows.Forms.TextBox();
            this.btnYeniOgrenci = new System.Windows.Forms.Button();
            
            // TabControl & 7 Sekme
            this.tabControlOgrenci = new System.Windows.Forms.TabControl();
            this.tabPageGenel = new System.Windows.Forms.TabPage();
            this.tabPageNotlar = new System.Windows.Forms.TabPage();
            this.tabPageCalismalar = new System.Windows.Forms.TabPage();
            this.tabPageSorular = new System.Windows.Forms.TabPage();
            this.tabPageDenemeler = new System.Windows.Forms.TabPage();
            this.tabPageKazanimlar = new System.Windows.Forms.TabPage();
            this.tabPageRaporlar = new System.Windows.Forms.TabPage();

            // Form Ayarları
            this.ClientSize = new System.Drawing.Size(1150, 720);
            this.Text = "Eğitim Koçluğu - Öğrenci Profil Dosyası";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            
            // TabPage Başlıkları
            this.tabPageGenel.Text = "Genel Bilgiler";
            this.tabPageNotlar.Text = "Koç Notları";
            this.tabPageCalismalar.Text = "Günlük Çalışmalar";
            this.tabPageSorular.Text = "Soru Takibi";
            this.tabPageDenemeler.Text = "Denemeler";
            this.tabPageKazanimlar.Text = "Kazanımlar";
            this.tabPageRaporlar.Text = "Raporlar & Analiz";
        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dosyaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeniOgrenciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cikisToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainerMain;
        private System.Windows.Forms.GroupBox grpOgrenciListesi;
        private System.Windows.Forms.ListBox lstOgrenciler;
        private System.Windows.Forms.TextBox txtOgrenciAra;
        private System.Windows.Forms.Button btnYeniOgrenci;
        
        // TabControl & TabPages
        private System.Windows.Forms.TabControl tabControlOgrenci;
        private System.Windows.Forms.TabPage tabPageGenel;
        private System.Windows.Forms.TabPage tabPageNotlar;
        private System.Windows.Forms.TabPage tabPageCalismalar;
        private System.Windows.Forms.TabPage tabPageSorular;
        private System.Windows.Forms.TabPage tabPageDenemeler;
        private System.Windows.Forms.TabPage tabPageKazanimlar;
        private System.Windows.Forms.TabPage tabPageRaporlar;

        // Kontroller
        private System.Windows.Forms.TextBox txtAdSoyad;
        private System.Windows.Forms.DateTimePicker dtpDogumTarihi;
        private System.Windows.Forms.ComboBox cmbSinif;
        private System.Windows.Forms.ComboBox cmbAlan;
        private System.Windows.Forms.ComboBox cmbYksYili;
        private System.Windows.Forms.TextBox txtHedefUniversite;
        private System.Windows.Forms.TextBox txtHedefBolum;
        private System.Windows.Forms.TextBox txtHedefPuan;
        private System.Windows.Forms.TextBox txtHedefSiralama;
        private System.Windows.Forms.ComboBox cmbDurum;
        private System.Windows.Forms.TextBox txtKocNotu;
        private System.Windows.Forms.DataGridView dgvKocNotlari;
        private System.Windows.Forms.DataGridView dgvCalismalar;
        private System.Windows.Forms.DataGridView dgvSorular;
        private System.Windows.Forms.DataGridView dgvDenemeler;
        private System.Windows.Forms.DataGridView dgvKazanimlar;
        private System.Windows.Forms.Label lblRaporHedefUniversite;
        private System.Windows.Forms.Label lblRaporHedefPuan;
        private System.Windows.Forms.Label lblRaporMevcutPuan;
        private System.Windows.Forms.Label lblRaporFark;
    }
}`
  },
  {
    name: 'DatabaseContext.cs',
    category: 'Veritabanı',
    description: 'Windows Forms SQLite Veritabanı ve CRUD İşlemleri (ADO.NET / SQLite)',
    code: `using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using EgitimKocluğu.Models;

namespace EgitimKocluğu.Database
{
    public class DatabaseContext
    {
        private readonly string _connectionString;
        private const string DbFileName = "EgitimKocluğu.db";

        public DatabaseContext()
        {
            _connectionString = $"Data Source={DbFileName};Version=3;";
            VeritabaniniOlusturEgerYoksa();
        }

        private void VeritabaniniOlusturEgerYoksa()
        {
            if (!File.Exists(DbFileName))
            {
                SQLiteConnection.CreateFile(DbFileName);
            }

            using (var conn = new SQLiteConnection(_connectionString))
            {
                conn.Open();
                string sql = @"
                    CREATE TABLE IF NOT EXISTS Ogrenciler (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        AdSoyad TEXT NOT NULL,
                        DogumTarihi TEXT,
                        Sinif INTEGER NOT NULL,
                        Alan INTEGER NOT NULL,
                        YksHedefYili INTEGER NOT NULL,
                        HedefUniversite TEXT,
                        HedefBolum TEXT,
                        HedefPuan REAL,
                        HedefSiralama INTEGER,
                        KayitTarihi TEXT,
                        Durum INTEGER,
                        GenelKocNotu TEXT
                    );

                    CREATE TABLE IF NOT EXISTS KocNotlari (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        OgrenciId INTEGER,
                        Tarih TEXT,
                        Baslik TEXT,
                        Icerik TEXT,
                        Kategori TEXT,
                        Oncelik TEXT,
                        FOREIGN KEY(OgrenciId) REFERENCES Ogrenciler(Id)
                    );

                    CREATE TABLE IF NOT EXISTS GunlukCalismalar (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        OgrenciId INTEGER,
                        Tarih TEXT,
                        Ders TEXT,
                        Konu TEXT,
                        SureDakika INTEGER,
                        VerimlilikPuani INTEGER,
                        KocOnayi INTEGER,
                        Notlar TEXT,
                        FOREIGN KEY(OgrenciId) REFERENCES Ogrenciler(Id)
                    );

                    CREATE TABLE IF NOT EXISTS Denemeler (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        OgrenciId INTEGER,
                        SinavTuru TEXT,
                        SinavAdi TEXT,
                        YayinEvi TEXT,
                        Tarih TEXT,
                        TurkceNet REAL,
                        SosyalNet REAL,
                        TemelMatNet REAL,
                        FenNet REAL,
                        AytMatNet REAL,
                        ToplamNet REAL,
                        TahminiPuan REAL,
                        KocGorusNotu TEXT,
                        FOREIGN KEY(OgrenciId) REFERENCES Ogrenciler(Id)
                    );
                ";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<Ogrenci> TumOgrencileriGetir()
        {
            var liste = new List<Ogrenci>();
            using (var conn = new SQLiteConnection(_connectionString))
            {
                conn.Open();
                string sql = "SELECT * FROM Ogrenciler ORDER BY AdSoyad ASC";
                using (var cmd = new SQLiteCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        liste.Add(new Ogrenci
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            AdSoyad = reader["AdSoyad"].ToString(),
                            HedefUniversite = reader["HedefUniversite"].ToString(),
                            HedefBolum = reader["HedefBolum"].ToString(),
                            HedefPuan = reader["HedefPuan"] != DBNull.Value ? Convert.ToDouble(reader["HedefPuan"]) : 0,
                            HedefSiralama = reader["HedefSiralama"] != DBNull.Value ? Convert.ToInt32(reader["HedefSiralama"]) : 0,
                            Sinif = (SinifSeviyesi)Convert.ToInt32(reader["Sinif"]),
                            Alan = (YksAlani)Convert.ToInt32(reader["Alan"]),
                            YksHedefYili = Convert.ToInt32(reader["YksHedefYili"]),
                            Durum = (OgrenciDurumu)Convert.ToInt32(reader["Durum"]),
                            GenelKocNotu = reader["GenelKocNotu"].ToString()
                        });
                    }
                }
            }
            return liste;
        }

        public void OgrenciGuncelle(Ogrenci o)
        {
            using (var conn = new SQLiteConnection(_connectionString))
            {
                conn.Open();
                string sql = @"UPDATE Ogrenciler SET 
                    AdSoyad = @AdSoyad, 
                    HedefUniversite = @HedefUniversite, 
                    HedefBolum = @HedefBolum, 
                    HedefPuan = @HedefPuan, 
                    HedefSiralama = @HedefSiralama, 
                    GenelKocNotu = @GenelKocNotu 
                    WHERE Id = @Id";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@AdSoyad", o.AdSoyad);
                    cmd.Parameters.AddWithValue("@HedefUniversite", o.HedefUniversite ?? "");
                    cmd.Parameters.AddWithValue("@HedefBolum", o.HedefBolum ?? "");
                    cmd.Parameters.AddWithValue("@HedefPuan", o.HedefPuan);
                    cmd.Parameters.AddWithValue("@HedefSiralama", o.HedefSiralama);
                    cmd.Parameters.AddWithValue("@GenelKocNotu", o.GenelKocNotu ?? "");
                    cmd.Parameters.AddWithValue("@Id", o.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<KocNotu> OgrenciNotlariniGetir(int ogrenciId)
        {
            // Örnek liste veya SQLite tablosundan çekme
            return new List<KocNotu>();
        }

        public List<GunlukCalisma> OgrenciCalismalariniGetir(int ogrenciId)
        {
            return new List<GunlukCalisma>();
        }

        public List<SoruKaydi> OgrenciSorulariniGetir(int ogrenciId)
        {
            return new List<SoruKaydi>();
        }

        public List<DenemeSinavi> OgrenciDenemeleriniGetir(int ogrenciId)
        {
            return new List<DenemeSinavi>();
        }

        public List<KazanimDurumu> OgrenciKazanimlariniGetir(int ogrenciId)
        {
            return new List<KazanimDurumu>();
        }
    }
}`
  },
  {
    name: 'Program.cs',
    category: 'Program',
    description: 'Windows Forms Uygulama Giriş Noktası (.NET 8 / .NET Framework)',
    code: `using System;
using System.Windows.Forms;

namespace EgitimKocluğu
{
    internal static class Program
    {
        /// <summary>
        ///  Uygulamanın ana girdi noktası.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Windows Forms Görsel Stillerini Etkinleştir
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // DPI Farkındalığı (Yüksek Çözünürlüklü Monitörler İçin)
            #if NET8_0_OR_GREATER
            ApplicationConfiguration.Initialize();
            #endif

            // Ana Profil Formunu Başlat
            Application.Run(new FormOgrenciProfil());
        }
    }
}`
  }
];
