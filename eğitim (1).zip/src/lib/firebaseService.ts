import {
  Student,
  CoachNote,
  GorevProgrami,
  SoruTakipKaydi,
  DenemeSinavi,
  Kazanim,
  OgrenciSinavKaydi
} from '../types';

/**
 * Utility function for cleaning object properties before sending to API if needed.
 */
export function cleanForFirestore<T>(data: T): T {
  return data;
}

/**
 * Database seeding is handled directly by PostgreSQL on server start.
 */
export async function seedDatabaseIfEmpty(): Promise<boolean> {
  return true;
}

// ==================== STUDENTS ====================
export async function getStudents(): Promise<Student[]> {
  try {
    const res = await fetch('/api/students');
    if (!res.ok) return [];
    return await res.json();
  } catch (error) {
    console.warn('API getStudents error:', error);
    return [];
  }
}

export async function saveStudent(student: Student): Promise<void> {
  try {
    await fetch('/api/students', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(student)
    });
  } catch (error) {
    console.warn('API saveStudent error:', error);
  }
}

export async function deleteStudent(studentId: string): Promise<void> {
  try {
    await fetch(`/api/students/${studentId}`, { method: 'DELETE' });
  } catch (error) {
    console.warn('API deleteStudent error:', error);
  }
}

// ==================== COACH NOTES ====================
export async function getCoachNotes(): Promise<CoachNote[]> {
  try {
    const res = await fetch('/api/notes');
    if (!res.ok) return [];
    return await res.json();
  } catch (error) {
    console.warn('API getCoachNotes error:', error);
    return [];
  }
}

export async function saveCoachNote(note: CoachNote): Promise<void> {
  try {
    await fetch('/api/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(note)
    });
  } catch (error) {
    console.warn('API saveCoachNote error:', error);
  }
}

export async function deleteCoachNote(noteId: string): Promise<void> {
  try {
    await fetch(`/api/notes/${noteId}`, { method: 'DELETE' });
  } catch (error) {
    console.warn('API deleteCoachNote error:', error);
  }
}

// ==================== TASKS (GÖREV PROGRAMI) ====================
export async function getTasks(): Promise<GorevProgrami[]> {
  try {
    const res = await fetch('/api/tasks');
    if (!res.ok) return [];
    return await res.json();
  } catch (error) {
    console.warn('API getTasks error:', error);
    return [];
  }
}

export async function saveTask(task: GorevProgrami): Promise<void> {
  try {
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(task)
    });
  } catch (error) {
    console.warn('API saveTask error:', error);
  }
}

export async function deleteTask(taskId: string): Promise<void> {
  try {
    await fetch(`/api/tasks/${taskId}`, { method: 'DELETE' });
  } catch (error) {
    console.warn('API deleteTask error:', error);
  }
}

// ==================== QUESTIONS (SORU TAKİP) ====================
export async function getQuestions(): Promise<SoruTakipKaydi[]> {
  try {
    const res = await fetch('/api/questions');
    if (!res.ok) return [];
    return await res.json();
  } catch (error) {
    console.warn('API getQuestions error:', error);
    return [];
  }
}

export async function saveQuestion(question: SoruTakipKaydi): Promise<void> {
  try {
    await fetch('/api/questions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(question)
    });
  } catch (error) {
    console.warn('API saveQuestion error:', error);
  }
}

export async function deleteQuestion(questionId: string): Promise<void> {
  try {
    await fetch(`/api/questions/${questionId}`, { method: 'DELETE' });
  } catch (error) {
    console.warn('API deleteQuestion error:', error);
  }
}

// ==================== EXAMS (DENEME SINAVI) ====================
export async function getExams(): Promise<DenemeSinavi[]> {
  try {
    const res = await fetch('/api/exams');
    if (!res.ok) return [];
    return await res.json();
  } catch (error) {
    console.warn('API getExams error:', error);
    return [];
  }
}

export async function saveExam(exam: DenemeSinavi): Promise<void> {
  try {
    await fetch('/api/exams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(exam)
    });
  } catch (error) {
    console.warn('API saveExam error:', error);
  }
}

export async function deleteExam(examId: string): Promise<void> {
  try {
    await fetch(`/api/exams/${examId}`, { method: 'DELETE' });
  } catch (error) {
    console.warn('API deleteExam error:', error);
  }
}

// ==================== CURRICULUM (KAZANIMLAR) ====================
export async function getCurriculum(): Promise<Kazanim[]> {
  try {
    const res = await fetch('/api/curriculum');
    if (!res.ok) return [];
    return await res.json();
  } catch (error) {
    console.warn('API getCurriculum error:', error);
    return [];
  }
}

export async function saveCurriculumItem(item: Kazanim): Promise<void> {
  try {
    await fetch('/api/curriculum/item', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(item)
    });
  } catch (error) {
    console.warn('API saveCurriculumItem error:', error);
  }
}

export async function deleteCurriculumItem(itemId: string): Promise<void> {
  try {
    await fetch(`/api/curriculum/${itemId}`, { method: 'DELETE' });
  } catch (error) {
    console.warn('API deleteCurriculumItem error:', error);
  }
}

export async function bulkReplaceCurriculumInFirestore(newItems: Kazanim[]): Promise<void> {
  try {
    await fetch('/api/curriculum/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: newItems, replaceAll: true })
    });
  } catch (error) {
    console.warn('API bulkReplaceCurriculum error:', error);
  }
}

export async function bulkAppendCurriculumToFirestore(newItems: Kazanim[]): Promise<void> {
  try {
    await fetch('/api/curriculum/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: newItems, replaceAll: false })
    });
  } catch (error) {
    console.warn('API bulkAppendCurriculum error:', error);
  }
}

// ==================== ARCHIVES (ÖĞRENCİ SINAV KAYDI) ====================
export async function getExamArchives(): Promise<OgrenciSinavKaydi[]> {
  try {
    const res = await fetch('/api/archives');
    if (!res.ok) return [];
    return await res.json();
  } catch (error) {
    console.warn('API getExamArchives error:', error);
    return [];
  }
}

export async function saveExamArchive(archive: OgrenciSinavKaydi): Promise<void> {
  try {
    await fetch('/api/archives', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(archive)
    });
  } catch (error) {
    console.warn('API saveExamArchive error:', error);
  }
}

export async function deleteExamArchive(archiveId: string): Promise<void> {
  try {
    await fetch(`/api/archives/${archiveId}`, { method: 'DELETE' });
  } catch (error) {
    console.warn('API deleteExamArchive error:', error);
  }
}
