import { 
  Student, 
  CoachNote, 
  GorevProgrami, 
  SoruTakipKaydi, 
  DenemeSinavi, 
  Kazanim, 
  OgrenciSinavKaydi 
} from '../types';

// Helper for sending POST/GET/DELETE requests to our own Express Backend APIs
async function fetchApi<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers || {}),
    },
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API Error on ${url}: ${response.status} - ${errorText}`);
  }
  return response.json() as Promise<T>;
}

// 1. STUDENTS
export async function getStudents(): Promise<Student[]> {
  return fetchApi<Student[]>('/api/students');
}

export async function saveStudent(student: Student): Promise<void> {
  await fetchApi<void>('/api/students', {
    method: 'POST',
    body: JSON.stringify(student),
  });
}

export async function deleteStudent(id: string): Promise<void> {
  await fetchApi<void>(`/api/students/${id}`, {
    method: 'DELETE',
  });
}

// 2. COACH NOTES
export async function getCoachNotes(): Promise<CoachNote[]> {
  return fetchApi<CoachNote[]>('/api/notes');
}

export async function saveCoachNote(note: CoachNote): Promise<void> {
  await fetchApi<void>('/api/notes', {
    method: 'POST',
    body: JSON.stringify(note),
  });
}

export async function deleteCoachNote(id: string): Promise<void> {
  await fetchApi<void>(`/api/notes/${id}`, {
    method: 'DELETE',
  });
}

// 3. TASKS
export async function getTasks(): Promise<GorevProgrami[]> {
  return fetchApi<GorevProgrami[]>('/api/tasks');
}

export async function saveTask(task: GorevProgrami): Promise<void> {
  await fetchApi<void>('/api/tasks', {
    method: 'POST',
    body: JSON.stringify(task),
  });
}

export async function deleteTask(id: string): Promise<void> {
  await fetchApi<void>(`/api/tasks/${id}`, {
    method: 'DELETE',
  });
}

// 4. QUESTIONS
export async function getQuestions(): Promise<SoruTakipKaydi[]> {
  return fetchApi<SoruTakipKaydi[]>('/api/questions');
}

export async function saveQuestion(q: SoruTakipKaydi): Promise<void> {
  await fetchApi<void>('/api/questions', {
    method: 'POST',
    body: JSON.stringify(q),
  });
}

export async function deleteQuestion(id: string): Promise<void> {
  await fetchApi<void>(`/api/questions/${id}`, {
    method: 'DELETE',
  });
}

// 5. EXAMS
export async function getExams(): Promise<DenemeSinavi[]> {
  return fetchApi<DenemeSinavi[]>('/api/exams');
}

export async function saveExam(exam: DenemeSinavi): Promise<void> {
  await fetchApi<void>('/api/exams', {
    method: 'POST',
    body: JSON.stringify(exam),
  });
}

export async function deleteExam(id: string): Promise<void> {
  await fetchApi<void>(`/api/exams/${id}`, {
    method: 'DELETE',
  });
}

// 6. CURRICULUM
export async function getCurriculum(): Promise<Kazanim[]> {
  return fetchApi<Kazanim[]>('/api/curriculum');
}

export async function saveCurriculumItem(item: Kazanim): Promise<void> {
  await fetchApi<void>('/api/curriculum/item', {
    method: 'POST',
    body: JSON.stringify(item),
  });
}

export async function deleteCurriculumItem(id: string): Promise<void> {
  await fetchApi<void>(`/api/curriculum/${id}`, {
    method: 'DELETE',
  });
}

// 7. EXAM ARCHIVES
export async function getExamArchives(): Promise<OgrenciSinavKaydi[]> {
  return fetchApi<OgrenciSinavKaydi[]>('/api/archives');
}

export async function saveExamArchive(archive: OgrenciSinavKaydi): Promise<void> {
  await fetchApi<void>('/api/archives', {
    method: 'POST',
    body: JSON.stringify(archive),
  });
}

export async function deleteExamArchive(id: string): Promise<void> {
  await fetchApi<void>(`/api/archives/${id}`, {
    method: 'DELETE',
  });
}

// 8. STUDENT MULTI-IMAGE AI TEST ANALYSIS & UPLOAD
export async function analyzeAndSaveStudentTest(payload: {
  archiveId?: string;
  studentId: string;
  studentName: string;
  testName: string;
  sinavTuru: 'TYT' | 'AYT';
  studentNote?: string;
  images: Array<{ imageBase64: string; mimeType?: string } | string>;
  existingCurriculum?: Kazanim[];
}): Promise<{ success: boolean; archive: OgrenciSinavKaydi; message: string }> {
  return fetchApi<{ success: boolean; archive: OgrenciSinavKaydi; message: string }>('/api/ai/analyze-student-test', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function retryExamAIAnalysis(archiveId: string, archive?: OgrenciSinavKaydi): Promise<{ success: boolean; message: string }> {
  return fetchApi<{ success: boolean; message: string }>(`/api/archives/${archiveId}/retry-ai`, {
    method: 'POST',
    body: archive ? JSON.stringify({ archive }) : undefined,
  });
}

// No-op placeholder, as Express backend handles initialization and seeding automatically on server startup
export async function seedDatabaseIfEmpty(): Promise<void> {
  return Promise.resolve();
}
