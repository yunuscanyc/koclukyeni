import React, { useState } from 'react';
import { 
  GraduationCap, 
  LogOut, 
  KeyRound, 
  Target, 
  Sparkles, 
  Calendar, 
  Award, 
  BookOpen, 
  Clock, 
  ShieldCheck,
  CheckCircle2,
  Circle,
  AlertCircle,
  Lock,
  Camera,
  Upload,
  Layers,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Eye,
  FileCheck,
  XCircle,
  HelpCircle,
  Loader2,
  Hourglass,
  RefreshCw,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  X,
  ListTodo,
  CalendarDays,
  Search,
  Filter,
  CheckSquare2,
  MessageSquareQuote,
  MessageSquare,
  Flame,
  ArrowRight
} from 'lucide-react';
import { Student, OgrenciSinavKaydi, Kazanim, SoruAnalizDetay, GorevProgrami, GorevDurumu, CoachNote, isQuestionTaskType } from '../../types';
import { StudentTestUploadModal } from './StudentTestUploadModal';
import { PWAInstallButton } from '../pwa/PWAInstallButton';

interface StudentPortalViewProps {
  student: Student;
  studentArchives?: OgrenciSinavKaydi[];
  studentTasks?: GorevProgrami[];
  coachNotes?: CoachNote[];
  curriculum?: Kazanim[];
  onLogout: () => void;
  onSaveExamArchive?: (archive: OgrenciSinavKaydi) => void;
  onToggleTask?: (id: string, ogrenciNotu?: string) => void;
}

export const StudentPortalView: React.FC<StudentPortalViewProps> = ({
  student,
  studentArchives = [],
  studentTasks = [],
  coachNotes = [],
  curriculum = [],
  onLogout,
  onSaveExamArchive,
  onToggleTask,
}) => {
  const [activePortalTab, setActivePortalTab] = useState<'program' | 'testler' | 'hedefler'>('program');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [selectedArchive, setSelectedArchive] = useState<OgrenciSinavKaydi | null>(null);
  const [viewingPhotoModal, setViewingPhotoModal] = useState<{
    photoUrl: string;
    pageNo: number;
    question?: SoruAnalizDetay;
  } | null>(null);
  const [modalZoom, setModalZoom] = useState(1);
  const [modalPan, setModalPan] = useState({ x: 0, y: 0 });
  const [modalIsDragging, setModalIsDragging] = useState(false);
  const [modalDragStart, setModalDragStart] = useState({ x: 0, y: 0 });

  // Student Portal Testler Booklet Viewer states
  const [studentActivePageIndex, setStudentActivePageIndex] = useState(0);
  const [studentZoom, setStudentZoom] = useState(1);
  const [studentPan, setStudentPan] = useState({ x: 0, y: 0 });
  const [studentIsDragging, setStudentIsDragging] = useState(false);
  const [studentDragStart, setStudentDragStart] = useState({ x: 0, y: 0 });
  const [studentSelectedQuestionNo, setStudentSelectedQuestionNo] = useState<number | null>(null);
  const [studentSelectedPageFilter, setStudentSelectedPageFilter] = useState<number | 'all'>('all');

  // Program filters
  const [taskStatusFilter, setTaskStatusFilter] = useState<'Tümü' | 'Bugün' | 'Bekleyenler' | 'Tamamlandı'>('Tümü');
  const [taskSearch, setTaskSearch] = useState('');
  const [recentlyToggledIds, setRecentlyToggledIds] = useState<Set<string>>(new Set());
  const [optimisticStatusMap, setOptimisticStatusMap] = useState<Record<string, GorevDurumu>>({});
  const [portalToast, setPortalToast] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);
  const [retryingArchiveId, setRetryingArchiveId] = useState<string | null>(null);

  const showPortalToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setPortalToast({ text, type });
    setTimeout(() => setPortalToast(null), 3500);
  };

  const handleToggleTaskWithFeedback = (taskId: string, customNote?: string) => {
    if (!onToggleTask) return;
    const currentTask = myTasks.find((t) => t.id === taskId);
    const willBeDone = currentTask?.durum !== 'Tamamlandı';
    const nextStatus: GorevDurumu = willBeDone ? 'Tamamlandı' : 'Devam Ediyor';

    setOptimisticStatusMap((prev) => ({ ...prev, [taskId]: nextStatus }));
    setRecentlyToggledIds((prev) => new Set(prev).add(taskId));
    onToggleTask(taskId, customNote);

    if (willBeDone) {
      showPortalToast(`🎉 Harika! "${currentTask?.ders || 'Ders'} - ${currentTask?.konu || 'Görev'}" tamamlandı olarak işaretlendi.`);
    } else {
      showPortalToast(`🔄 "${currentTask?.konu || 'Görev'}" yeniden devam ediyor durumuna alındı.`, 'info');
    }
  };

  const handleStudentRetryAI = async (archive: OgrenciSinavKaydi) => {
    setRetryingArchiveId(archive.id);
    try {
      const res = await fetch(`/api/archives/${archive.id}/retry-ai`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archive }),
      });
      const data = await res.json();
      showPortalToast(data.message || 'Yapay zekâ çözümü kaldığı sayfadan devam ettiriliyor.', 'info');
    } catch (err) {
      console.error("Retry AI error:", err);
      showPortalToast('Yeniden başlatma sırasında bağlantı hatası oluştu.', 'error');
    } finally {
      setTimeout(() => setRetryingArchiveId(null), 1500);
    }
  };

  // Filter student's own exams & tasks
  const myArchives = studentArchives.filter((a) => !a.studentId || a.studentId === student.id || a.ogrenciAdSoyad === student.adSoyad);
  const myTasks = React.useMemo(() => {
    return studentTasks
      .filter((t) => !t.studentId || t.studentId === student.id)
      .map((t) => {
        if (optimisticStatusMap[t.id]) {
          return { ...t, durum: optimisticStatusMap[t.id] };
        }
        return t;
      });
  }, [studentTasks, student.id, optimisticStatusMap]);
  const myNotes = coachNotes.filter((n) => !n.studentId || n.studentId === student.id);

  // Reset page and selection when switching active student archive
  React.useEffect(() => {
    setStudentActivePageIndex(0);
    setStudentSelectedQuestionNo(null);
    setStudentSelectedPageFilter('all');
    setStudentZoom(1);
    setStudentPan({ x: 0, y: 0 });
  }, [selectedArchive?.id]);

  // Drag booklet photo mouse & touch handlers
  const handleStudentMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setStudentIsDragging(true);
    setStudentDragStart({ x: e.clientX - studentPan.x, y: e.clientY - studentPan.y });
  };

  const handleStudentMouseMove = (e: React.MouseEvent) => {
    if (!studentIsDragging) return;
    e.preventDefault();
    setStudentPan({ x: e.clientX - studentDragStart.x, y: e.clientY - studentDragStart.y });
  };

  const handleStudentMouseUp = () => {
    setStudentIsDragging(false);
  };

  const handleStudentTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setStudentIsDragging(true);
      setStudentDragStart({ x: e.touches[0].clientX - studentPan.x, y: e.touches[0].clientY - studentPan.y });
    }
  };

  const handleStudentTouchMove = (e: React.TouchEvent) => {
    if (!studentIsDragging || e.touches.length !== 1) return;
    setStudentPan({ x: e.touches[0].clientX - studentDragStart.x, y: e.touches[0].clientY - studentDragStart.y });
  };

  const handleStudentTouchEnd = () => {
    setStudentIsDragging(false);
  };

  // Modal Drag Handlers
  const handleModalMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setModalIsDragging(true);
    setModalDragStart({ x: e.clientX - modalPan.x, y: e.clientY - modalPan.y });
  };

  const handleModalMouseMove = (e: React.MouseEvent) => {
    if (!modalIsDragging) return;
    e.preventDefault();
    setModalPan({ x: e.clientX - modalDragStart.x, y: e.clientY - modalDragStart.y });
  };

  const handleModalMouseUp = () => {
    setModalIsDragging(false);
  };

  const handleModalTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setModalIsDragging(true);
      setModalDragStart({ x: e.touches[0].clientX - modalPan.x, y: e.touches[0].clientY - modalPan.y });
    }
  };

  const handleModalTouchMove = (e: React.TouchEvent) => {
    if (!modalIsDragging || e.touches.length !== 1) return;
    setModalPan({ x: e.touches[0].clientX - modalDragStart.x, y: e.touches[0].clientY - modalDragStart.y });
  };

  const handleModalTouchEnd = () => {
    setModalIsDragging(false);
  };

  // Today ISO string (YYYY-MM-DD)
  const todayStr = new Date().toISOString().split('T')[0];

  // Task filtering logic
  const filteredTasks = myTasks.filter((t) => {
    // Status / Date Filter
    if (taskStatusFilter === 'Bugün' && t.tarih !== todayStr) return false;
    if (taskStatusFilter === 'Bekleyenler' && t.durum === 'Tamamlandı' && !recentlyToggledIds.has(t.id)) return false;
    if (taskStatusFilter === 'Tamamlandı' && t.durum !== 'Tamamlandı') return false;

    // Search filter
    if (taskSearch.trim()) {
      const q = taskSearch.toLowerCase();
      const matchTopic = t.konu.toLowerCase().includes(q);
      const matchLesson = t.ders.toLowerCase().includes(q);
      const matchKazanim = t.hedefKazanim?.toLowerCase().includes(q);
      const matchKocNot = t.kocAciklamasi?.toLowerCase().includes(q);
      if (!matchTopic && !matchLesson && !matchKazanim && !matchKocNot) return false;
    }

    return true;
  });

  // Calculate task statistics
  const totalTasksCount = myTasks.length;
  const completedTasksCount = myTasks.filter((t) => t.durum === 'Tamamlandı').length;
  const pendingTasksCount = myTasks.filter((t) => t.durum !== 'Tamamlandı').length;
  const todayTasks = myTasks.filter((t) => t.tarih === todayStr);
  const todayCompleted = todayTasks.filter((t) => t.durum === 'Tamamlandı').length;

  const totalTargetMinutes = myTasks.reduce((sum, t) => sum + (t.hedefSureDakika || 0), 0);
  const totalTargetQuestions = myTasks.reduce((sum, t) => sum + (t.hedefSoruSayisi || 0), 0);
  const completionPercentage = totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0;

  const handleTestUploaded = (archive: OgrenciSinavKaydi) => {
    if (onSaveExamArchive) {
      onSaveExamArchive(archive);
    }
  };

  const getAIStatusBadge = (archive: OgrenciSinavKaydi) => {
    const hasQuestions = Array.isArray(archive.sorular) && archive.sorular.length > 0;
    const isCompleted = archive.aiStatus === 'completed' || (hasQuestions && archive.aiStatus !== 'rate_limited');

    if (isCompleted) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-bold">
          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
          <span>Yapay Zekâ Çözdü</span>
        </span>
      );
    }

    if (archive.aiStatus === 'rate_limited') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-bold animate-pulse">
          <Hourglass className="w-3 h-3 text-amber-600" />
          <span>Kota Bekleniyor (Yeniden Deneniyor)</span>
        </span>
      );
    }

    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px] font-bold">
        <Loader2 className="w-3 h-3 text-indigo-600 animate-spin" />
        <span>{archive.aiStatusMessage || 'Devam Ediyor'}</span>
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Top Header */}
      <header className="bg-white border-b border-slate-200/90 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-5xl w-full mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-100">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-1.5">
                <span>Öğrenci Portalı</span>
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Aktif Oturum
                </span>
              </div>
              <div className="text-[11px] text-slate-500 font-medium">
                {student.adSoyad} • {student.sinif}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* PWA Install Button */}
            <PWAInstallButton variant="header" />

            {/* Student PIN Badge */}
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs text-slate-600 font-semibold">
              <KeyRound className="w-3.5 h-3.5 text-indigo-600" />
              <span>Öğrenci PIN: <strong className="text-slate-900 font-mono">{student.pinCode}</strong></span>
            </div>

            {/* Logout Button */}
            <button
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs transition-all active:scale-95"
              title="Çıkış Yap ve PIN Ekranına Dön"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Çıkış Yap</span>
            </button>
          </div>
        </div>
      </header>

      {/* Student Navigation Tab Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-16 z-20">
        <div className="max-w-5xl w-full mx-auto px-4 sm:px-6 flex items-center gap-2 overflow-x-auto py-2">
          <button
            onClick={() => setActivePortalTab('program')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${
              activePortalTab === 'program'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-200'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <ListTodo className="w-4 h-4" />
            <span>Çalışma Programım & Görevler</span>
            {pendingTasksCount > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                activePortalTab === 'program' ? 'bg-indigo-800 text-white' : 'bg-amber-100 text-amber-900'
              }`}>
                {pendingTasksCount} Bekleyen
              </span>
            )}
          </button>

          <button
            onClick={() => setActivePortalTab('testler')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${
              activePortalTab === 'testler'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-200'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>Testlerim & AI Çözümleri</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
              activePortalTab === 'testler' ? 'bg-indigo-800 text-white' : 'bg-slate-200 text-slate-700'
            }`}>
              {myArchives.length}
            </span>
          </button>

          <button
            onClick={() => setActivePortalTab('hedefler')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap ${
              activePortalTab === 'hedefler'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-200'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Target className="w-4 h-4" />
            <span>Hedeflerim & Koç Notları</span>
            {myNotes.length > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                activePortalTab === 'hedefler' ? 'bg-indigo-800 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {myNotes.length} Not
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Main Student Page Body */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        
        {/* =========================================================
            TAB 1: KOÇUN ÇALIŞMA PROGRAMI & GÜNLÜK GÖREVLER
           ========================================================= */}
        {activePortalTab === 'program' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Header / Summary Card */}
            <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl shadow-indigo-950/10 border border-slate-800 relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-2 max-w-xl">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-bold">
                    <CalendarDays className="w-3.5 h-3.5" />
                    <span>Koçunun Hazırladığı Çalışma Programı</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    Haftalık Hedeflerin & Çalışma Planın 🎯
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    Koçunun sana özel atadığı ders çalışma saatleri, soru hedefleri ve konu kazanımları. Tamamladığın görevleri işaretleyerek ilerlemeni koçuna iletebilirsin.
                  </p>
                </div>

                {/* Progress Card */}
                <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 min-w-[220px] space-y-3 shrink-0">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-semibold">Görev Tamamlama</span>
                    <span className="text-indigo-300 font-black text-sm">%{completionPercentage}</span>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full transition-all duration-500"
                      style={{ width: `${completionPercentage}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-300 pt-1 border-t border-white/10">
                    <span>Tamamlanan: <strong className="text-emerald-400 font-bold">{completedTasksCount}</strong> / {totalTasksCount}</span>
                    <span>Bekleyen: <strong className="text-amber-400 font-bold">{pendingTasksCount}</strong></span>
                  </div>
                </div>
              </div>

              {/* Quick Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-5 mt-5 border-t border-white/10 text-xs">
                <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-0.5">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Bugünkü Görevler</div>
                  <div className="text-base font-black text-white flex items-center gap-1.5">
                    <span>{todayTasks.length} Görev</span>
                    {todayTasks.length > 0 && (
                      <span className="text-[10px] text-emerald-400 font-bold">({todayCompleted} Bitti)</span>
                    )}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-0.5">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Toplam Hedef Soru</div>
                  <div className="text-base font-black text-indigo-300">{totalTargetQuestions} Soru</div>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-0.5">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Planlanan Süre</div>
                  <div className="text-base font-black text-white">
                    {Math.floor(totalTargetMinutes / 60)}s {totalTargetMinutes % 60}dk
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-0.5">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Hızlı Eylem</div>
                  <button
                    onClick={() => setIsUploadModalOpen(true)}
                    className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
                  >
                    <span>Test Fotoğrafı Yükle</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>

            {/* Task Controls & Filters */}
            <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                {/* Status Filter Chips */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  {(['Tümü', 'Bugün', 'Bekleyenler', 'Tamamlandı'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => {
                        setTaskStatusFilter(filter);
                        setRecentlyToggledIds(new Set());
                      }}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border whitespace-nowrap cursor-pointer ${
                        taskStatusFilter === filter
                          ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {filter}
                      {filter === 'Tümü' && totalTasksCount > 0 && ` (${totalTasksCount})`}
                      {filter === 'Bugün' && todayTasks.length > 0 && ` (${todayTasks.length})`}
                      {filter === 'Bekleyenler' && pendingTasksCount > 0 && ` (${pendingTasksCount})`}
                      {filter === 'Tamamlandı' && completedTasksCount > 0 && ` (${completedTasksCount})`}
                    </button>
                  ))}
                </div>

                {/* Search Bar */}
                <div className="relative min-w-[220px]">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={taskSearch}
                    onChange={(e) => setTaskSearch(e.target.value)}
                    placeholder="Ders, konu veya kazanım ara..."
                    className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 bg-slate-50/50"
                  />
                </div>
              </div>

              {/* Tasks List */}
              {filteredTasks.length > 0 ? (
                <div className="space-y-3 pt-2">
                  {filteredTasks.map((task) => {
                    const isDone = task.durum === 'Tamamlandı';
                    const isToday = task.tarih === todayStr;

                    return (
                      <div
                        key={task.id}
                        className={`p-4 sm:p-5 rounded-2xl border transition-all space-y-3 ${
                          isDone
                            ? 'bg-slate-50/70 border-slate-200 opacity-80'
                            : isToday
                            ? 'bg-white border-indigo-300 shadow-xs ring-1 ring-indigo-500/10'
                            : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'
                        }`}
                      >
                        {/* Top Line: Tags & Time */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            {/* Date Badge */}
                            <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-lg flex items-center gap-1.5 ${
                              isToday
                                ? 'bg-indigo-100 text-indigo-800 font-black'
                                : 'bg-slate-100 text-slate-700'
                            }`}>
                              <Calendar className="w-3 h-3 text-indigo-600" />
                              <span>{isToday ? 'Bugün' : task.tarih}</span>
                            </span>

                            {/* Task Type */}
                            <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                              {task.gorevTuru}
                            </span>

                            {/* Status Badge */}
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                                task.durum === 'Tamamlandı'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : task.durum === 'Devam Ediyor'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {task.durum}
                            </span>

                            {/* DISTINCT PRIMARY BADGE: Soru ise Soru Sayısı, Konu ise Süre */}
                            {isQuestionTaskType(task.gorevTuru) ? (
                              <span className="text-[11px] font-black px-2.5 py-0.5 rounded-lg bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1 shadow-2xs">
                                <Target className="w-3.5 h-3.5 text-amber-700" />
                                <span>Hedef: {task.hedefSoruSayisi} Soru</span>
                              </span>
                            ) : (
                              <span className="text-[11px] font-black px-2.5 py-0.5 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1 shadow-2xs">
                                <Clock className="w-3.5 h-3.5 text-emerald-700" />
                                <span>Süre: {task.hedefSureDakika} Dakika</span>
                              </span>
                            )}

                            {/* Time */}
                            {task.baslangicSaati && (
                              <span className="text-[11px] font-medium px-2 py-0.5 rounded-lg bg-slate-100 text-slate-600 flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                <span>{task.baslangicSaati}</span>
                              </span>
                            )}
                          </div>

                          {/* Toggle Done Button */}
                          <button
                            onClick={() => handleToggleTaskWithFeedback(task.id)}
                            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 self-start sm:self-auto cursor-pointer ${
                              isDone
                                ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border border-emerald-300 shadow-2xs'
                                : 'bg-slate-900 hover:bg-indigo-600 text-white shadow-xs active:scale-95'
                            }`}
                          >
                            {isDone ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                                <span>Tamamlandı ✓</span>
                              </>
                            ) : (
                              <>
                                <Circle className="w-3.5 h-3.5" />
                                <span>Görevi Tamamla</span>
                              </>
                            )}
                          </button>
                        </div>

                        {/* Middle Line: Subject & Topic */}
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-xs text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md">
                              {task.ders}
                            </span>
                            <h4 className={`text-sm sm:text-base font-black ${
                              isDone ? 'line-through text-slate-500' : 'text-slate-900'
                            }`}>
                              {task.konu}
                            </h4>
                            {isDone && recentlyToggledIds.has(task.id) && (
                              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 animate-pulse">
                                Yeni Tamamlandı ✓
                              </span>
                            )}
                          </div>

                          {/* Target Questions & MEB Outcomes */}
                          <div className="flex items-center gap-3 text-xs text-slate-600 flex-wrap pt-1">
                            {task.hedefSoruSayisi > 0 && (
                              <div className="flex items-center gap-1 font-bold text-indigo-900">
                                <Target className="w-3.5 h-3.5 text-indigo-600" />
                                <span>Hedef: {task.hedefSoruSayisi} Soru</span>
                              </div>
                            )}

                            {task.hedefKazanim && (
                              <div className="flex items-center gap-1 text-[11px] text-slate-500 italic">
                                <span>📌 Kazanım:</span>
                                <span className="font-semibold text-slate-700">{task.hedefKazanim}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Coach Instruction Quote if present */}
                        {task.kocAciklamasi && (
                          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-700 space-y-1">
                            <div className="flex items-center gap-1.5 font-bold text-[10px] text-indigo-700 uppercase tracking-wider">
                              <MessageSquareQuote className="w-3.5 h-3.5" />
                              <span>Koç Talimatı / Notu:</span>
                            </div>
                            <p className="text-slate-700 text-xs italic leading-relaxed">
                              "{task.kocAciklamasi}"
                            </p>
                          </div>
                        )}

                        {/* Student Feedback Note Area */}
                        <div className="pt-3 border-t border-slate-100 space-y-2">
                          <div className="flex items-center justify-between">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                              <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                              <span>Koçunuza Not / Geri Bildirim:</span>
                            </label>
                            {task.ogrenciNotu && (
                              <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-100 flex items-center gap-1 animate-in fade-in">
                                <span>Kaydedildi ✓</span>
                              </span>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              id={`student-note-${task.id}`}
                              placeholder="Örn: 50 soru çözüldü, süre yetmedi vb. notunuzu yazın..."
                              defaultValue={task.ogrenciNotu || ''}
                              className="flex-1 px-3 py-1.5 bg-slate-50/50 hover:bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-slate-700 transition-all placeholder:text-slate-400"
                            />
                            <button
                              onClick={() => {
                                const inputEl = document.getElementById(`student-note-${task.id}`) as HTMLInputElement;
                                if (inputEl && onToggleTask) {
                                  onToggleTask(task.id, inputEl.value);
                                  showPortalToast('Koçunuza not iletildi ✓');
                                }
                              }}
                              className="px-3.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-xs transition-all border border-indigo-200 active:scale-95 whitespace-nowrap cursor-pointer"
                            >
                              Notu Kaydet
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 rounded-2xl border-2 border-dashed border-slate-200 text-center space-y-3">
                  <ListTodo className="w-10 h-10 text-slate-300 mx-auto" />
                  <div>
                    <div className="text-sm font-bold text-slate-700">
                      {taskStatusFilter === 'Bugün' 
                        ? 'Bugün için atanmış bir görev bulunmuyor' 
                        : 'Bu filtreye uygun çalışma görevi bulunamadı'}
                    </div>
                    <div className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                      Koçun haftalık çalışma programına yeni görevler eklediğinde burada görebilirsin.
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* =========================================================
            TAB 2: TEST YÜKLEME & YAPAY ZEKÂ ÇÖZÜMLERİ
           ========================================================= */}
        {activePortalTab === 'testler' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Header and Upload Action Button */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
              <div>
                <h2 className="text-xl font-bold text-slate-800">Çözdüğün Testler & Yapay Zekâ Analizleri</h2>
                <p className="text-xs text-slate-400 mt-1">Yüklediğin testlerin soru çözümlerini ve MEB kazanımlarını incele.</p>
              </div>
              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-100 transition-all flex items-center gap-2 active:scale-95 self-start sm:self-auto"
              >
                <Camera className="w-4 h-4" />
                <span>Yeni Test Fotoğrafı Yükle</span>
              </button>
            </div>

            {/* Uploaded Tests History */}
            {myArchives.length > 0 ? (
              <div className="space-y-3">
                {myArchives.map((arch) => {
                  const isOpen = selectedArchive?.id === arch.id;
                  return (
                    <div
                      key={arch.id}
                      className={`bg-white border rounded-2xl transition-all overflow-hidden ${
                        isOpen
                          ? 'border-indigo-400 shadow-sm ring-1 ring-indigo-400/20'
                          : 'border-slate-200/80 hover:border-slate-300'
                      }`}
                    >
                      {/* Accordion Header */}
                      <div
                        onClick={() => {
                          if (isOpen) {
                            setSelectedArchive(null);
                          } else {
                            setSelectedArchive(arch);
                          }
                        }}
                        className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer select-none"
                      >
                        <div className="flex items-center gap-2.5 flex-wrap">
                          <span
                            className={`text-[9px] font-black px-1.5 py-0.5 rounded ${
                              arch.sinavTuru === 'TYT'
                                ? 'bg-indigo-100 text-indigo-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {arch.sinavTuru}
                          </span>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-800 leading-tight">
                            {arch.sinavAdi}
                          </h4>
                          <span className="text-[10px] text-slate-400">({arch.tarih})</span>
                          {getAIStatusBadge(arch)}
                          {arch.isNew && (
                            <span className="text-[9px] font-black px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                              ✨ Koç İncelemesinde
                            </span>
                          )}
                        </div>

                        <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-0 border-slate-100">
                          <div className="text-xs font-bold text-slate-500">
                            Net: <span className="text-indigo-700 font-extrabold">{arch.toplamNet?.toFixed(2) || '0.00'}</span>
                            <span className="text-[10px] text-slate-400 font-normal ml-1.5">
                              ({arch.dogruSayisi}D {arch.yanlisSayisi}Y {arch.bosSayisi}B)
                            </span>
                          </div>
                          <div className="p-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-400">
                            {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </div>
                        </div>
                      </div>

                      {/* Accordion Content */}
                      {isOpen && (
                        <div className="px-4 pb-5 pt-1 border-t border-slate-100 space-y-6">
                          
                          {/* Ongoing background AI processing states */}
                          {(arch.aiStatus === 'rate_limited' || arch.aiStatus === 'processing' || arch.aiStatus === 'pending' || arch.aiStatus === 'error') && (
                            <div className={`p-3.5 rounded-xl border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                              arch.aiStatus === 'rate_limited'
                                ? 'bg-amber-50 border-amber-200 text-amber-900'
                                : arch.aiStatus === 'error'
                                ? 'bg-rose-50 border-rose-200 text-rose-900'
                                : 'bg-indigo-50 border-indigo-200 text-indigo-900'
                            }`}>
                              <div className="flex items-center gap-2.5">
                                {arch.aiStatus === 'rate_limited' ? (
                                  <Hourglass className="w-4 h-4 text-amber-600 shrink-0 animate-spin" />
                                ) : arch.aiStatus === 'error' ? (
                                  <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                                ) : (
                                  <Loader2 className="w-4 h-4 text-indigo-600 shrink-0 animate-spin" />
                                )}
                                <div className="space-y-0.5">
                                  <div className="font-bold">
                                    {arch.aiStatus === 'rate_limited'
                                      ? 'API Kotası Bekleniyor (Yeniden deneniyor...)'
                                      : arch.aiStatus === 'error'
                                      ? 'Çözüm sırasında sorun oluştu'
                                      : (arch.aiStatusMessage || 'Yapay zekâ soruları çözüyor...')}
                                  </div>
                                  <div className="text-[11px] opacity-80">
                                    Sonuçlar hazırlandığında bu ekran otomatik güncellenecektir. Dilerseniz yeniden başlatabilirsiniz.
                                  </div>
                                </div>
                              </div>

                              <button
                                onClick={() => handleStudentRetryAI(arch)}
                                disabled={retryingArchiveId === arch.id}
                                className="shrink-0 px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs self-end sm:self-auto disabled:opacity-50 cursor-pointer"
                              >
                                <RefreshCw className={`w-3.5 h-3.5 ${retryingArchiveId === arch.id ? 'animate-spin' : ''}`} />
                                <span>{retryingArchiveId === arch.id ? 'Sıraya Alınıyor...' : 'Kaldığı Sayfadan Çözdür'}</span>
                              </button>
                            </div>
                          )}

                          {/* Booklet Photo Viewer with interactive zoom/pan */}
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Camera className="w-4 h-4 text-indigo-600" />
                                <span className="text-xs font-bold text-slate-900">
                                  Sınav Kitapçığı Fotoğrafları ({arch.sayfaFotolari?.length || 0} Sayfa)
                                </span>
                              </div>

                              {/* Zoom controls */}
                              <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200">
                                <button
                                  onClick={() => setStudentZoom((z) => Math.min(z + 0.25, 3))}
                                  className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200"
                                  title="Yakınlaştır"
                                >
                                  <ZoomIn className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => setStudentZoom((z) => Math.max(z - 0.25, 0.5))}
                                  className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200"
                                  title="Uzaklaştır"
                                >
                                  <ZoomOut className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    setStudentZoom(1);
                                    setStudentPan({ x: 0, y: 0 });
                                  }}
                                  className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200"
                                  title="Sıfırla"
                                >
                                  <RotateCcw className="w-3.5 h-3.5" />
                                </button>
                                <span className="text-[10px] font-bold text-slate-500 px-1.5">
                                  {Math.round(studentZoom * 100)}%
                                </span>
                              </div>
                            </div>

                            {/* Image Canvas with Drag-to-Pan */}
                            <div className="relative w-full h-80 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center select-none">
                              {studentSelectedQuestionNo && arch.sorular && (
                                (() => {
                                  const selectedQ = arch.sorular.find((q) => q.soruNo === studentSelectedQuestionNo);
                                  return selectedQ ? (
                                    <div className="absolute top-3 left-3 right-3 z-10 bg-slate-900/90 backdrop-blur-md border border-indigo-500/40 text-white px-3.5 py-2 rounded-xl text-xs flex items-center justify-between shadow-lg">
                                      <div className="flex items-center gap-2">
                                        <span className="w-5 h-5 rounded-md bg-indigo-600 text-white font-black text-[10px] flex items-center justify-center">
                                          {selectedQ.soruNo}
                                        </span>
                                        <div>
                                          <span className="font-bold text-indigo-200">Soru {selectedQ.soruNo}:</span> {selectedQ.ders} - {selectedQ.konu}
                                          <span className="text-[10px] text-slate-400 ml-2">(Sayfa {selectedQ.sayfaNo || (studentActivePageIndex + 1)})</span>
                                        </div>
                                      </div>
                                      <button
                                        onClick={() => setStudentSelectedQuestionNo(null)}
                                        className="text-slate-400 hover:text-white text-[11px]"
                                      >
                                        Kapat ✕
                                      </button>
                                    </div>
                                  ) : null;
                                })()
                              )}

                              {arch.sayfaFotolari && arch.sayfaFotolari[studentActivePageIndex] ? (
                                <div
                                  onMouseDown={handleStudentMouseDown}
                                  onMouseMove={handleStudentMouseMove}
                                  onMouseUp={handleStudentMouseUp}
                                  onMouseLeave={handleStudentMouseUp}
                                  onTouchStart={handleStudentTouchStart}
                                  onTouchMove={handleStudentTouchMove}
                                  onTouchEnd={handleStudentTouchEnd}
                                  className="w-full h-full flex items-center justify-center cursor-grab active:cursor-grabbing overflow-hidden touch-none"
                                >
                                  <img
                                    src={arch.sayfaFotolari[studentActivePageIndex]}
                                    alt={`Kitapçık Sayfa ${studentActivePageIndex + 1}`}
                                    style={{
                                      transform: `translate(${studentPan.x}px, ${studentPan.y}px) scale(${studentZoom})`,
                                      transition: studentIsDragging ? 'none' : 'transform 0.15s ease-out',
                                      transformOrigin: 'center center',
                                    }}
                                    className="max-w-full max-h-full object-contain pointer-events-none select-none"
                                  />
                                </div>
                              ) : (
                                <div className="text-center text-slate-500 text-xs">
                                  Bu sınav için yüklenmiş sayfa fotoğrafı bulunamadı.
                                </div>
                              )}
                            </div>

                            {/* Thumbnails Swapper */}
                            {arch.sayfaFotolari && arch.sayfaFotolari.length > 0 && (
                              <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 pt-1">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-[11px] font-bold text-slate-400 mr-1">Sayfalar:</span>
                                  {arch.sayfaFotolari.map((_, idx) => {
                                    const pageNum = idx + 1;
                                    const pageQCount = (arch.sorular || []).filter((q) => (q.sayfaNo || 1) === pageNum).length;
                                    return (
                                      <button
                                        key={idx}
                                        onClick={() => {
                                          setStudentActivePageIndex(idx);
                                          setStudentZoom(1);
                                          setStudentPan({ x: 0, y: 0 });
                                        }}
                                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border whitespace-nowrap flex items-center gap-1 ${
                                          studentActivePageIndex === idx
                                            ? 'bg-indigo-600 text-white border-indigo-600'
                                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                                        }`}
                                      >
                                        <span>{pageNum}. Sayfa</span>
                                        {pageQCount > 0 && (
                                          <span className={`text-[9px] px-1.5 rounded-full font-bold ${
                                            studentActivePageIndex === idx ? 'bg-indigo-800 text-indigo-100' : 'bg-slate-100 text-slate-600'
                                          }`}>
                                            {pageQCount} Soru
                                          </span>
                                        )}
                                      </button>
                                    );
                                  })}
                                </div>

                                {arch.sayfaFotolari.length > 1 && (
                                  <button
                                    onClick={() => setStudentSelectedPageFilter('all')}
                                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all border whitespace-nowrap ${
                                      studentSelectedPageFilter === 'all'
                                        ? 'bg-slate-800 text-white border-slate-800'
                                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                                    }`}
                                  >
                                    Tüm Soruları Göster
                                  </button>
                                )}
                              </div>
                            )}
                          </div>

                          {/* Soru Listesi & MEB Kazanımları */}
                          {arch.sorular && arch.sorular.length > 0 ? (
                            <div className="space-y-3 pt-2">
                              <div className="flex items-center justify-between">
                                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                                  📝 Yapay Zekâ Soru Çözümleri & MEB Kazanımları
                                </h4>
                                <span className="text-[10px] text-slate-400">
                                  💡 Bir soruya tıklayarak fotoğrafta o soruya odaklanabilirsiniz
                                </span>
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-96 overflow-y-auto pr-1">
                                {(arch.sorular || [])
                                  .filter((q) => studentSelectedPageFilter === 'all' || (q.sayfaNo || 1) === studentSelectedPageFilter)
                                  .map((q) => {
                                    const isQSelected = studentSelectedQuestionNo === q.soruNo;
                                    return (
                                      <div
                                        key={q.soruNo}
                                        onClick={() => {
                                          setStudentSelectedQuestionNo(q.soruNo);
                                          const pNum = q.sayfaNo || 1;
                                          if (arch.sayfaFotolari && arch.sayfaFotolari.length >= pNum) {
                                            setStudentActivePageIndex(pNum - 1);
                                          }
                                        }}
                                        className={`p-3.5 rounded-xl border transition-all cursor-pointer text-xs space-y-1.5 ${
                                          isQSelected
                                            ? 'bg-indigo-50 border-indigo-400 shadow-xs'
                                            : 'bg-slate-50 border-slate-200/80 hover:border-indigo-200'
                                        }`}
                                      >
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-1.5">
                                            <span className="font-bold text-slate-800">Soru {q.soruNo}: {q.ders}</span>
                                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-white text-slate-500 border border-slate-200 font-semibold">
                                              Sayfa {q.sayfaNo || 1}
                                            </span>
                                          </div>
                                          <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                                            q.dogruMu ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                                          }`}>
                                            {q.dogruMu ? 'DOĞRU' : 'YANLIŞ'}
                                          </span>
                                        </div>

                                        <div className="text-slate-700 text-[11px]">Konu: <strong>{q.konu}</strong></div>
                                        
                                        {q.kazanimAciklama && (
                                          <p className="text-[11px] text-slate-500 italic line-clamp-2">
                                            📌 {q.kazanimAciklama}
                                          </p>
                                        )}

                                        <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1.5 border-t border-slate-100">
                                          <span>
                                            Seçimin: <strong className="text-slate-700">{q.isaretlenenSik || 'Boş'}</strong> • Doğru: <strong className="text-emerald-700">{q.dogruCevap}</strong>
                                          </span>
                                          <span className="text-indigo-600 font-bold hover:underline flex items-center gap-1">
                                            <Camera className="w-3 h-3" /> Fotoğrafta Odaklan
                                          </span>
                                        </div>
                                      </div>
                                    );
                                  })}
                              </div>
                            </div>
                          ) : (
                            <div className="p-6 text-center text-slate-400 text-xs">
                              Bu sınavın soru ayrıntıları henüz yapay zekâ tarafından analiz ediliyor. Tamamlandığında burada listelenecektir.
                            </div>
                          )}

                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center space-y-3">
                <Camera className="w-10 h-10 text-slate-300 mx-auto" />
                <div>
                  <div className="text-sm font-bold text-slate-700">Henüz bir test fotoğrafı yüklemediniz</div>
                  <div className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                    Çözdüğünüz deneme veya yaprak testlerin fotoğrafını çekip yükleyerek yapay zekâ analizi yaptırabilir ve koçunuzla paylaşabilirsiniz.
                  </div>
                </div>
                <button
                  onClick={() => setIsUploadModalOpen(true)}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-100"
                >
                  <Camera className="w-4 h-4" />
                  <span>İlk Testimi Fotoğrafla & Yükle</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* =========================================================
            TAB 3: HEDEFLER & KOÇ NOTLARI
           ========================================================= */}
        {activePortalTab === 'hedefler' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Student Target Card */}
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-2xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-2xl ${
                      student.avatarBg || 'bg-indigo-600'
                    } text-white flex items-center justify-center font-black text-lg shadow-md shrink-0`}
                  >
                    {student.adSoyad.charAt(0)}
                  </div>
                  <div>
                    <h2 className="text-base font-black text-slate-900">{student.adSoyad}</h2>
                    <div className="text-xs text-slate-500 font-medium">
                      {student.sinif} • {student.alan} • YKS {student.yksHedefYili}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700">
                    Hedef Sıralama: <strong>{student.hedefSiralama}</strong>
                  </div>
                  <div className="px-3 py-1.5 rounded-xl bg-indigo-50 border border-indigo-100 text-xs text-indigo-700 font-bold">
                    {student.hedefPuan} Puan
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70">
                  <div className="text-slate-400 font-bold uppercase tracking-wider text-[10px] mb-1">
                    Hedef Üniversite & Bölüm
                  </div>
                  <div className="font-bold text-slate-900">{student.hedefUniversite}</div>
                  <div className="text-indigo-700 font-semibold">{student.hedefBolum}</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70">
                  <div className="text-slate-400 font-bold uppercase tracking-wider text-[10px] mb-1">
                    Genel Koç Tavsiyesi
                  </div>
                  <div className="text-slate-700 italic">
                    {student.kocNotu || 'Koçunuz henüz genel bir not eklemedi.'}
                  </div>
                </div>
              </div>
            </div>

            {/* Coach Notes List */}
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-2xs space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <MessageSquareQuote className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900">
                    Koçumun Rehberlik & Strateji Notları ({myNotes.length})
                  </h3>
                  <p className="text-xs text-slate-500">
                    Koçun tarafından sana özel yazılan değerlendirmeler ve motivasyon yönlendirmeleri
                  </p>
                </div>
              </div>

              {myNotes.length > 0 ? (
                <div className="space-y-3">
                  {myNotes.map((note) => (
                    <div
                      key={note.id}
                      className="p-4 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 font-bold text-[10px]">
                            {note.kategori}
                          </span>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            note.oncelik === 'Kritik'
                              ? 'bg-rose-100 text-rose-800'
                              : note.oncelik === 'Önemli'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-200 text-slate-700'
                          }`}>
                            {note.oncelik}
                          </span>
                          <h4 className="font-bold text-slate-900">{note.baslik}</h4>
                        </div>
                        <span className="text-[11px] text-slate-400 font-medium">{note.tarih}</span>
                      </div>
                      <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{note.icerik}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 rounded-2xl border-2 border-dashed border-slate-200 text-center space-y-2">
                  <MessageSquareQuote className="w-8 h-8 text-slate-300 mx-auto" />
                  <div className="text-xs font-bold text-slate-600">Henüz kayıtlı bir koç notu bulunmuyor</div>
                  <div className="text-[11px] text-slate-400">Koçunuz özel not veya değerlendirme eklediğinde burada listelenecektir.</div>
                </div>
              )}
            </div>
          </div>
        )}

      </main>

      {/* Question Photo Lightbox Modal */}
      {viewingPhotoModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-slate-200">
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <Camera className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Sayfa {viewingPhotoModal.pageNo} Fotoğrafı
                    {viewingPhotoModal.question && ` - Soru ${viewingPhotoModal.question.soruNo} (${viewingPhotoModal.question.ders})`}
                  </h3>
                  <p className="text-xs text-slate-400">Yapay zekânın taradığı orijinal test kâğıdı görseli</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
                  <button
                    onClick={() => setModalZoom((z) => Math.min(z + 0.25, 3))}
                    className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
                    title="Yakınlaştır"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setModalZoom((z) => Math.max(z - 0.25, 0.5))}
                    className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
                    title="Uzaklaştır"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      setModalZoom(1);
                      setModalPan({ x: 0, y: 0 });
                    }}
                    className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
                    title="Sıfırla"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[10px] font-bold text-slate-500 px-1">
                    {Math.round(modalZoom * 100)}%
                  </span>
                </div>

                <button
                  onClick={() => {
                    setViewingPhotoModal(null);
                    setModalZoom(1);
                    setModalPan({ x: 0, y: 0 });
                  }}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Photo Viewport */}
            <div
              onMouseDown={handleModalMouseDown}
              onMouseMove={handleModalMouseMove}
              onMouseUp={handleModalMouseUp}
              onMouseLeave={handleModalMouseUp}
              onTouchStart={handleModalTouchStart}
              onTouchMove={handleModalTouchMove}
              onTouchEnd={handleModalTouchEnd}
              className="relative flex-1 min-h-[350px] max-h-[500px] bg-slate-950 flex items-center justify-center overflow-hidden p-4 select-none cursor-grab active:cursor-grabbing touch-none"
            >
              <img
                src={viewingPhotoModal.photoUrl}
                alt="Test Sayfası"
                style={{
                  transform: `translate(${modalPan.x}px, ${modalPan.y}px) scale(${modalZoom})`,
                  transition: modalIsDragging ? 'none' : 'transform 0.15s ease-out',
                  transformOrigin: 'center center',
                }}
                className="max-w-full max-h-[480px] object-contain pointer-events-none select-none"
              />
            </div>

            {/* Question Details Footer if available */}
            {viewingPhotoModal.question && (
              <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <div className="font-bold text-slate-800 flex items-center gap-2">
                    <span>Soru {viewingPhotoModal.question.soruNo}: {viewingPhotoModal.question.ders} - {viewingPhotoModal.question.konu}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-black ${
                      viewingPhotoModal.question.dogruMu ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {viewingPhotoModal.question.dogruMu ? 'DOĞRU' : 'YANLIŞ'}
                    </span>
                  </div>
                  {viewingPhotoModal.question.kazanimAciklama && (
                    <div className="text-[11px] text-slate-500 italic">
                      📌 {viewingPhotoModal.question.kazanimAciklama}
                    </div>
                  )}
                </div>

                <div className="text-[11px] text-slate-600 font-mono shrink-0">
                  İşaretlenen: <strong>{viewingPhotoModal.question.isaretlenenSik || 'Boş'}</strong> • Doğru Cevap: <strong className="text-emerald-700">{viewingPhotoModal.question.dogruCevap}</strong>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Upload Test Modal */}
      {isUploadModalOpen && (
        <StudentTestUploadModal
          isOpen={isUploadModalOpen}
          onClose={() => setIsUploadModalOpen(false)}
          student={student}
          curriculum={curriculum}
          onTestUploaded={handleTestUploaded}
        />
      )}

      {/* Student Toast Notification */}
      {portalToast && (
        <div className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-3 animate-in slide-in-from-bottom-5 duration-200 ${
          portalToast.type === 'success'
            ? 'bg-emerald-600 text-white border-emerald-500 shadow-emerald-500/20'
            : 'bg-indigo-600 text-white border-indigo-500 shadow-indigo-500/20'
        }`}>
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span className="text-xs font-bold">{portalToast.text}</span>
        </div>
      )}

      {/* Footer */}
      <footer className="py-4 text-center text-xs text-slate-400 border-t border-slate-200/80 bg-white">
        Öğrenci No: <span className="font-mono font-bold text-slate-700">{student.pinCode}</span> • Eğitim Koçluğu Portalı
      </footer>
    </div>
  );
};

