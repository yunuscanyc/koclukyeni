import React from 'react';
import { X, Calendar, Clock, BookOpen, Target, CheckCircle2, AlertCircle, FileText, MessageSquare } from 'lucide-react';
import { GorevProgrami, isQuestionTaskType } from '../../types';

interface TaskDetailModalProps {
  task: GorevProgrami | null;
  onClose: () => void;
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
}

export const TaskDetailModal: React.FC<TaskDetailModalProps> = ({
  task,
  onClose,
  onToggleComplete,
  onDelete,
}) => {
  if (!task) return null;

  const isQuestion = isQuestionTaskType(task.gorevTuru);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span
              className={`px-3 py-1 rounded-xl text-xs font-bold ${
                task.durum === 'Tamamlandı'
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : task.durum === 'Devam Ediyor'
                  ? 'bg-amber-50 text-amber-700 border border-amber-200'
                  : 'bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              {task.durum}
            </span>
            <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-xl">
              {task.gorevTuru}
            </span>
            {isQuestion ? (
              <span className="text-xs font-black text-amber-800 bg-amber-100 px-2.5 py-1 rounded-xl border border-amber-200">
                🎯 {task.hedefSoruSayisi} Soru Hedefi
              </span>
            ) : (
              <span className="text-xs font-black text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-xl border border-emerald-200">
                ⏱️ {task.hedefSureDakika} dk Çalışma
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Title */}
        <div className="space-y-1">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">{task.ders}</div>
          <h3 className="text-lg font-black text-slate-900 leading-snug">{task.konu}</h3>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-2 gap-3 bg-slate-50 border border-slate-100 rounded-2xl p-4 text-xs">
          <div className="flex items-center gap-2 text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
            <span>Tarih: <strong className="text-slate-900">{task.tarih}</strong></span>
          </div>
          <div className="flex items-center gap-2 text-slate-600">
            <Clock className="w-4 h-4 text-slate-400 shrink-0" />
            <span>
              {isQuestion ? (
                <>Başlama: <strong className="text-slate-900">{task.baslangicSaati || '--:--'}</strong></>
              ) : (
                <>Çalışma Süresi: <strong className="text-emerald-700">{task.hedefSureDakika} dk</strong></>
              )}
            </span>
          </div>
          <div className="flex items-center gap-2 text-slate-600 col-span-2">
            {isQuestion ? (
              <>
                <Target className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Hedef Soru Adedi: <strong className="text-amber-900 text-sm font-black">{task.hedefSoruSayisi} Soru</strong></span>
              </>
            ) : (
              <>
                <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Çalışma Hedefi: <strong className="text-emerald-900 font-bold">{task.hedefSureDakika} Dakika Konu Tekrarı / Ders Çalışması</strong></span>
              </>
            )}
          </div>
        </div>

        {/* Target Outcome */}
        {task.hedefKazanim && (
          <div className="space-y-1">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
              <span>İlişkili MEB Kazanımı</span>
            </div>
            <div className="text-xs bg-indigo-50/50 border border-indigo-100 text-indigo-950 p-3 rounded-xl font-medium">
              {task.hedefKazanim}
            </div>
          </div>
        )}

        {/* Coach Instructions */}
        {task.kocAciklamasi && (
          <div className="space-y-1">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-amber-500" />
              <span>Koçun Özel Talimatı</span>
            </div>
            <div className="text-xs bg-amber-50/50 border border-amber-100 text-amber-950 p-3.5 rounded-xl font-medium leading-relaxed whitespace-pre-line">
              {task.kocAciklamasi}
            </div>
          </div>
        )}

        {/* Student Feedback Note */}
        {task.ogrenciNotu && (
          <div className="space-y-1">
            <div className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-emerald-500" />
              <span>Öğrencinin Geri Bildirim Notu</span>
            </div>
            <div className="text-xs bg-emerald-50/50 border border-emerald-100 text-emerald-950 p-3.5 rounded-xl font-medium leading-relaxed whitespace-pre-line">
              {task.ogrenciNotu}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <button
            onClick={() => {
              if (confirm('Bu çalışma görevini silmek istediğinize emin misiniz?')) {
                onDelete(task.id);
                onClose();
              }
            }}
            className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-3 py-2 rounded-xl hover:bg-rose-50 transition-colors"
          >
            Görevi Sil
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onToggleComplete(task.id);
                onClose();
              }}
              className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-xs ${
                task.durum === 'Tamamlandı'
                  ? 'bg-amber-600 text-white hover:bg-amber-700'
                  : 'bg-emerald-600 text-white hover:bg-emerald-700'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{task.durum === 'Tamamlandı' ? 'Devam Ediyora Çevir' : 'Görevi Tamamla'}</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
            >
              Kapat
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
