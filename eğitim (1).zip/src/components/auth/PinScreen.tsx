import React, { useState, useEffect, useRef } from 'react';
import { 
  Lock, 
  ShieldCheck, 
  Delete, 
  Sparkles, 
  UserCheck, 
  GraduationCap, 
  ArrowRight,
  AlertCircle,
  KeyRound,
  Eye,
  EyeOff
} from 'lucide-react';
import { Student } from '../../types';
import { DEFAULT_COACH_PIN } from '../../utils/pinUtils';
import { PWAInstallButton } from '../pwa/PWAInstallButton';

interface PinScreenProps {
  coachPin: string;
  students: Student[];
  onLoginCoach: () => void;
  onLoginStudent: (student: Student) => void;
}

export const PinScreen: React.FC<PinScreenProps> = ({
  coachPin,
  students,
  onLoginCoach,
  onLoginStudent,
}) => {
  const [pin, setPin] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);
  const [showDigits, setShowDigits] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input automatically
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // Handle PIN verification
  const verifyPin = (codeToTest: string) => {
    if (codeToTest.length !== 6) return;

    // Check if Coach PIN
    if (codeToTest === coachPin) {
      setErrorMsg(null);
      onLoginCoach();
      return;
    }

    // Check if any Student PIN
    const matchedStudent = students.find((s) => s.pinCode === codeToTest);
    if (matchedStudent) {
      setErrorMsg(null);
      onLoginStudent(matchedStudent);
      return;
    }

    // Not matched
    setIsShaking(true);
    setErrorMsg('Geçersiz 6 haneli PIN kodu! Lütfen koç PIN kodunuzu veya size verilen öğrenci kodunu giriniz.');
    setTimeout(() => {
      setIsShaking(false);
      setPin('');
      inputRef.current?.focus();
    }, 600);
  };

  const handleKeyPress = (digit: string) => {
    if (pin.length >= 6) return;
    const nextPin = pin + digit;
    setPin(nextPin);
    setErrorMsg(null);
    if (nextPin.length === 6) {
      verifyPin(nextPin);
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setErrorMsg(null);
  };

  const handleClear = () => {
    setPin('');
    setErrorMsg(null);
  };

  // Physical keyboard listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        handleKeyPress(e.key);
      } else if (e.key === 'Backspace') {
        handleDelete();
      } else if (e.key === 'Escape') {
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [pin]);

  const quickFill = (code: string) => {
    setPin(code);
    setErrorMsg(null);
    verifyPin(code);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-between items-center p-4 sm:p-6 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white relative overflow-hidden">
      {/* Background Decorative Lighting */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-violet-600/15 rounded-full blur-3xl pointer-events-none" />

      {/* Header Info */}
      <div className="w-full max-w-md pt-4 sm:pt-8 flex items-center justify-between z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-indigo-900/50">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-black text-white tracking-tight flex items-center gap-1.5">
              <span>EĞİTİM KOÇLUĞU</span>
              <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                PRO
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-medium">YKS Takip & Analiz Portalı</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <PWAInstallButton variant="header" />
          <button
            type="button"
            onClick={() => setShowDigits(!showDigits)}
            className="p-2 text-slate-400 hover:text-slate-200 rounded-xl hover:bg-slate-800 transition-colors flex items-center gap-1.5 text-xs font-semibold"
            title={showDigits ? "PIN'i Gizle" : "PIN'i Göster"}
          >
            {showDigits ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            <span className="text-[11px] hidden sm:inline">{showDigits ? 'Gizle' : 'Göster'}</span>
          </button>
        </div>
      </div>

      {/* Main PIN Entry Box */}
      <div className="w-full max-w-md my-auto py-6 flex flex-col items-center z-10">
        <div className="w-16 h-16 rounded-3xl bg-slate-800 border border-slate-700/80 flex items-center justify-center text-indigo-400 mb-5 shadow-xl shadow-slate-950/40">
          <KeyRound className="w-8 h-8" />
        </div>

        <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight text-center">
          Giriş İçin PIN Kodunu Girin
        </h1>
        <p className="text-xs text-slate-400 text-center mt-1.5 max-w-xs">
          Koç veya öğrenci 6 haneli güvenlik PIN kodunuzu girerek sisteme erişebilirsiniz.
        </p>

        {/* Hidden native input for mobile focus & auto keyboard */}
        <input
          ref={inputRef}
          type="tel"
          pattern="[0-9]*"
          maxLength={6}
          value={pin}
          onChange={(e) => {
            const val = e.target.value.replace(/\D/g, '').slice(0, 6);
            setPin(val);
            if (val.length === 6) verifyPin(val);
          }}
          className="opacity-0 absolute -z-10 pointer-events-none"
          autoFocus
        />

        {/* 6 Digit Display Blocks */}
        <div 
          onClick={() => inputRef.current?.focus()}
          className={`flex items-center justify-center gap-2.5 sm:gap-3.5 my-7 cursor-pointer ${
            isShaking ? 'animate-bounce text-rose-500' : ''
          }`}
        >
          {[0, 1, 2, 3, 4, 5].map((index) => {
            const hasValue = index < pin.length;
            const isCurrent = index === pin.length;
            const digitChar = pin[index];

            return (
              <div
                key={index}
                className={`w-11 h-13 sm:w-13 sm:h-16 rounded-2xl flex items-center justify-center font-black text-xl sm:text-2xl transition-all duration-150 ${
                  hasValue
                    ? 'bg-indigo-600/20 border-2 border-indigo-500 text-white shadow-md shadow-indigo-900/30 scale-105'
                    : isCurrent
                    ? 'bg-slate-800 border-2 border-indigo-400 text-slate-400 ring-2 ring-indigo-500/20'
                    : 'bg-slate-800/80 border border-slate-700/80 text-slate-600'
                }`}
              >
                {hasValue ? (
                  showDigits ? (
                    digitChar
                  ) : (
                    <span className="w-3.5 h-3.5 rounded-full bg-indigo-400 inline-block" />
                  )
                ) : isCurrent ? (
                  <span className="w-2 h-2 rounded-full bg-indigo-400/60 animate-ping inline-block" />
                ) : (
                  <span className="text-slate-700 text-sm">•</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Error Notification */}
        {errorMsg && (
          <div className="w-full mb-4 px-3.5 py-2.5 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Virtual Numeric Keypad */}
        <div className="w-full max-w-xs grid grid-cols-3 gap-2.5 sm:gap-3">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleKeyPress(digit)}
              className="h-13 sm:h-14 rounded-2xl bg-slate-800/90 hover:bg-slate-750 active:bg-indigo-600 active:text-white border border-slate-700/60 text-white text-lg font-bold shadow-sm transition-all active:scale-95 flex items-center justify-center"
            >
              {digit}
            </button>
          ))}

          {/* Clear Key */}
          <button
            type="button"
            onClick={handleClear}
            className="h-13 sm:h-14 rounded-2xl bg-slate-800/50 hover:bg-slate-800 active:bg-slate-700 border border-slate-700/50 text-slate-400 text-xs font-bold transition-all active:scale-95 flex items-center justify-center"
            title="Temizle"
          >
            Temizle
          </button>

          {/* 0 Key */}
          <button
            type="button"
            onClick={() => handleKeyPress('0')}
            className="h-13 sm:h-14 rounded-2xl bg-slate-800/90 hover:bg-slate-750 active:bg-indigo-600 active:text-white border border-slate-700/60 text-white text-lg font-bold shadow-sm transition-all active:scale-95 flex items-center justify-center"
          >
            0
          </button>

          {/* Backspace Key */}
          <button
            type="button"
            onClick={handleDelete}
            className="h-13 sm:h-14 rounded-2xl bg-slate-800/50 hover:bg-slate-800 active:bg-slate-700 border border-slate-700/50 text-slate-300 transition-all active:scale-95 flex items-center justify-center"
            title="Geri Sil"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Quick Test Demo Helper (Bottom Section) */}
      <div className="w-full max-w-md pb-4 pt-2 z-10 border-t border-slate-800/80">
        <div className="text-[11px] font-bold text-slate-400 mb-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Hızlı Test / Hazır PIN Kodları</span>
          </span>
          <span className="text-[10px] text-slate-500 font-normal">Tıklayarak otomatik doldurabilirsiniz</span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {/* Coach Quick Button */}
          <button
            type="button"
            onClick={() => quickFill(coachPin)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 text-xs font-bold transition-all hover:scale-102"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            <span>Koç PIN: <strong>{coachPin}</strong></span>
          </button>

          {/* Sample Students Quick Buttons */}
          {students.slice(0, 3).map((std) => (
            <button
              key={std.id}
              type="button"
              onClick={() => quickFill(std.pinCode)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 text-xs font-medium transition-all hover:scale-102"
              title={`${std.adSoyad} PIN: ${std.pinCode}`}
            >
              <UserCheck className="w-3 h-3 text-emerald-400" />
              <span>{std.adSoyad.split(' ')[0]}: <strong>{std.pinCode}</strong></span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
