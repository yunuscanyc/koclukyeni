import React from 'react';
import { 
  User, 
  FileText, 
  CalendarCheck, 
  HelpCircle, 
  Award, 
  BookOpen, 
  BarChart2, 
  Camera, 
  Archive,
  GraduationCap,
  Sparkles,
  ArrowLeft,
  KeyRound,
  Copy
} from 'lucide-react';
import { Student, StudentProfileTab } from '../../types';

interface StudentProfileViewProps {
  student: Student;
  activeTab: StudentProfileTab;
  onTabChange: (tab: StudentProfileTab) => void;
  onBackToList: () => void;
  newUploadsCount?: number;
  children: React.ReactNode;
}

export const StudentProfileView: React.FC<StudentProfileViewProps> = ({
  student,
  activeTab,
  onTabChange,
  onBackToList,
  newUploadsCount = 0,
  children,
}) => {
  const tabs: {
    key: StudentProfileTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
    badgeColor?: string;
  }[] = [
    { key: 'genel', label: '1. Genel Bilgiler', icon: User },
    { key: 'koc-notlari', label: '2. Koç Notları', icon: FileText },
    { key: 'calisma-programi', label: '3. Çalışma Programı', icon: CalendarCheck },
    { key: 'soru-takibi', label: '4. Soru Takibi', icon: HelpCircle },
    { key: 'denemeler', label: '5. Denemeler (TYT/AYT)', icon: Award },
    { key: 'kazanimlar', label: '6. MEB Müfredat Kazanımları', icon: BookOpen },
    { key: 'raporlar', label: '7. Raporlar & AI Koçluk', icon: BarChart2 },
    { key: 'sinav-analiz', label: '📸 8. Sınav & Kazanım Analizi', icon: Camera, badge: 'AI Optik' },
    { 
      key: 'sinav-gecmisi', 
      label: '📑 9. Sınav Geçmişi & Arşiv', 
      icon: Archive,
      badge: newUploadsCount > 0 ? `${newUploadsCount} YENİ TEST` : undefined,
      badgeColor: newUploadsCount > 0 ? 'bg-amber-400 text-slate-950 font-black animate-pulse' : undefined
    },
  ];
  return (
    <div className="space-y-6">
      {/* Student Profile Quick Banner */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-5 sm:p-6 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button
            onClick={onBackToList}
            className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors shrink-0"
            title="Tüm Öğrencilere Dön"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div
            className={`w-14 h-14 rounded-2xl ${
              student.avatarBg || 'bg-indigo-600'
            } text-white flex items-center justify-center font-black text-xl shadow-md shrink-0`}
          >
            {student.adSoyad.charAt(0)}
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg sm:text-xl font-black text-slate-900">{student.adSoyad}</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200">
                {student.sinif}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                {student.alan}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1.5 flex-wrap">
              <span>🎯 {student.hedefUniversite} - <strong className="text-indigo-700">{student.hedefBolum}</strong></span>
              <span className="text-slate-300">•</span>
              <span>Hedef: <strong>{student.hedefSiralama}</strong></span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end md:self-auto flex-wrap">
          {/* Öğrenci PIN Kodu Rozeti */}
          <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-900 font-semibold shadow-2xs">
            <KeyRound className="w-3.5 h-3.5 text-indigo-600" />
            <span>Öğrenci PIN: <strong className="font-mono text-indigo-700 font-bold">{student.pinCode}</strong></span>
            <button
              onClick={() => navigator.clipboard?.writeText(student.pinCode)}
              className="p-0.5 text-indigo-400 hover:text-indigo-700 transition-colors ml-0.5"
              title="PIN Kodunu Kopyala"
            >
              <Copy className="w-3 h-3" />
            </button>
          </div>

          <div className="px-3.5 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
            Kayıt: <strong className="text-slate-900">{student.kayitTarihi}</strong>
          </div>
        </div>
      </div>

      {/* 9 Tabs Navigation (Wrapped for full visibility) */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-2 shadow-2xs">
        <div className="flex items-center flex-wrap gap-1.5">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => onTabChange(tab.key)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 bg-slate-50/50 border border-slate-200/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`text-[9px] font-black px-1.5 py-0.2 rounded ${
                      tab.badgeColor || (isActive ? 'bg-indigo-400 text-slate-900' : 'bg-indigo-50 text-indigo-700')
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Render Active Tab Content */}
      <div className="transition-all animate-in fade-in duration-150">
        {children}
      </div>
    </div>
  );
};
