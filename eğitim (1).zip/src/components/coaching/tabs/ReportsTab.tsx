import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  Target, 
  Sparkles, 
  Award, 
  CheckCircle2, 
  AlertTriangle, 
  Brain, 
  Loader2, 
  BarChart2,
  BookOpen,
  Filter
} from 'lucide-react';
import { Student, DenemeSinavi, SoruTakipKaydi, Kazanim, OgrenciSinavKaydi, KazanimIstatistik } from '../../../types';

interface ReportsTabProps {
  student: Student;
  exams: DenemeSinavi[];
  questions: SoruTakipKaydi[];
  curriculum: Kazanim[];
  examArchives: OgrenciSinavKaydi[];
}

export const ReportsTab: React.FC<ReportsTabProps> = ({
  student,
  exams,
  questions,
  curriculum,
  examArchives,
}) => {
  const [selectedTrack, setSelectedTrack] = useState<'Tümü' | 'Sayısal' | 'Eşit Ağırlık' | 'Sözel'>('Tümü');
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  // Compute aggregate question stats
  const totalQuestions = questions.reduce((acc, q) => acc + q.cozulenSoru, 0);
  const totalCorrect = questions.reduce((acc, q) => acc + q.dogruSayisi, 0);
  const totalWrong = questions.reduce((acc, q) => acc + q.yanlisSayisi, 0);
  const accuracyRate = totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0;

  // Compute practice exam nets
  const tytExams = exams.filter((e) => e.sinavTuru === 'TYT');
  const aytExams = exams.filter((e) => e.sinavTuru === 'AYT');
  const latestTyt = tytExams[0];
  const latestAyt = aytExams[0];

  const targetScoreNum = Number(student.hedefPuan) || 490;
  const currentEstScore = latestAyt?.puan || latestTyt?.puan || 450;
  const scoreGap = targetScoreNum - currentEstScore;

  // Compute Outcome Success Rates combining questions and photo exam archive
  const kazanimStats: KazanimIstatistik[] = useMemo(() => {
    const map = new Map<string, KazanimIstatistik>();

    // From question tracking
    questions.forEach((q) => {
      const key = `${q.ders}-${q.konu}`;
      const existing = map.get(key) || {
        kazanimKodu: `KOD.${q.ders.slice(0, 3)}`,
        kazanimAciklama: `${q.ders} ${q.konu} temel kazanımı`,
        ders: q.ders,
        konu: q.konu,
        toplamSoru: 0,
        dogruSayisi: 0,
        yanlisSayisi: 0,
        bosSayisi: 0,
        basariYuzdesi: 0,
      };

      existing.toplamSoru += q.cozulenSoru;
      existing.dogruSayisi += q.dogruSayisi;
      existing.yanlisSayisi += q.yanlisSayisi;
      existing.bosSayisi += q.bosSayisi;
      map.set(key, existing);
    });

    // From photo exam archives
    examArchives.forEach((arch) => {
      arch.sorular?.forEach((s) => {
        const key = `${s.ders}-${s.konu}`;
        const existing = map.get(key) || {
          kazanimKodu: s.kazanimKodu || 'GENEL',
          kazanimAciklama: s.kazanimAciklama || `${s.ders} ${s.konu}`,
          ders: s.ders,
          konu: s.konu,
          toplamSoru: 0,
          dogruSayisi: 0,
          yanlisSayisi: 0,
          bosSayisi: 0,
          basariYuzdesi: 0,
        };

        existing.toplamSoru += 1;
        if (s.dogruMu) {
          existing.dogruSayisi += 1;
        } else if (s.isaretlenenSik === 'Boş') {
          existing.bosSayisi += 1;
        } else {
          existing.yanlisSayisi += 1;
        }
        map.set(key, existing);
      });
    });

    return Array.from(map.values()).map((item) => ({
      ...item,
      basariYuzdesi: item.toplamSoru > 0 ? Math.round((item.dogruSayisi / item.toplamSoru) * 100) : 0,
    }));
  }, [questions, examArchives]);

  // Filter kazanim stats by track
  const filteredKazanimStats = useMemo(() => {
    return kazanimStats.filter((k) => {
      if (selectedTrack === 'Sayısal') {
        return ['Matematik', 'Geometri', 'Fizik', 'Kimya', 'Biyoloji'].some((d) =>
          k.ders.toLowerCase().includes(d.toLowerCase())
        );
      }
      if (selectedTrack === 'Eşit Ağırlık') {
        return ['Matematik', 'Geometri', 'Türkçe', 'Edebiyat', 'Tarih', 'Coğrafya'].some((d) =>
          k.ders.toLowerCase().includes(d.toLowerCase())
        );
      }
      if (selectedTrack === 'Sözel') {
        return ['Türkçe', 'Edebiyat', 'Tarih', 'Coğrafya', 'Felsefe', 'Din'].some((d) =>
          k.ders.toLowerCase().includes(d.toLowerCase())
        );
      }
      return true;
    });
  }, [kazanimStats, selectedTrack]);

  const weakOutcomes = filteredKazanimStats
    .filter((k) => k.basariYuzdesi < 70)
    .sort((a, b) => a.basariYuzdesi - b.basariYuzdesi);

  const strongOutcomes = filteredKazanimStats
    .filter((k) => k.basariYuzdesi >= 70)
    .sort((a, b) => b.basariYuzdesi - a.basariYuzdesi);

  // Trigger Gemini AI Coach Advice
  const handleGetAICoachingAdvice = async () => {
    setIsLoadingAi(true);

    try {
      const response = await fetch('/api/ai/coaching-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student,
          weakOutcomes: weakOutcomes.slice(0, 5),
          recentExams: exams.slice(0, 3),
          selectedTrack,
        }),
      });

      const data = await response.json();
      setAiAdvice(data.advice || 'Koçluk tavsiyesi oluşturulamadı.');
    } catch (err: any) {
      setAiAdvice('Bağlantı hatası oluştu, lütfen tekrar deneyiniz.');
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Target Comparison Banner */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-8 shadow-2xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                7. Hedef & Performans Raporu
              </h3>
              <p className="text-xs text-slate-500">
                {student.adSoyad} • {student.sinif} ({student.alan} Alanı)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {['Tümü', 'Sayısal', 'Eşit Ağırlık', 'Sözel'].map((tr) => (
              <button
                key={tr}
                onClick={() => setSelectedTrack(tr as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                  selectedTrack === tr
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {tr}
              </button>
            ))}
          </div>
        </div>

        {/* 3 Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Hedef Tablosu</div>
            <div className="text-sm font-bold text-slate-900">{student.hedefUniversite}</div>
            <div className="text-xs text-indigo-700 font-semibold">{student.hedefBolum}</div>
            <div className="pt-2 border-t border-slate-200 flex justify-between text-xs">
              <span className="text-slate-500">Hedef Sıralama:</span>
              <span className="font-extrabold text-slate-900">{student.hedefSiralama}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Hedef Taban Puan:</span>
              <span className="font-extrabold text-indigo-700">{student.hedefPuan}</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Mevcut Durum</div>
            <div className="text-sm font-bold text-slate-900">
              {latestAyt ? `${latestAyt.denemeAdi}` : latestTyt ? `${latestTyt.denemeAdi}` : 'Son Deneme'}
            </div>
            <div className="text-xs text-slate-500">
              {latestTyt ? `TYT: ${latestTyt.toplamNet.toFixed(1)} Net` : ''} {latestAyt ? `• AYT: ${latestAyt.toplamNet.toFixed(1)} Net` : ''}
            </div>
            <div className="pt-2 border-t border-slate-200 flex justify-between text-xs">
              <span className="text-slate-500">Son Tahmini Puan:</span>
              <span className="font-extrabold text-emerald-700">~{currentEstScore} Puan</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Soru Doğruluk Oranı:</span>
              <span className="font-extrabold text-slate-900">%{accuracyRate}</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-indigo-50/50 border border-indigo-200/70 space-y-2 flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-indigo-600">Net & Puan Açığı</div>
              <div className="text-2xl font-black text-rose-600 mt-1">
                {scoreGap > 0 ? `+${scoreGap.toFixed(1)} Puan` : 'Hedef Seviyede'}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                {scoreGap > 0
                  ? `Hedefe ulaşmak için ortalama ${Math.round(scoreGap / 3.8)} net daha artış gerekiyor.`
                  : 'Mevcut netler hedeflenen taban puanı karşılıyor.'}
              </p>
            </div>
            <div className="text-[11px] text-slate-400 font-medium">
              Öncelik: Zayıf MEB kazanımlarını kapatmak
            </div>
          </div>
        </div>
      </div>

      {/* Weak & Strong Outcomes Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Weak Outcomes */}
        <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <h4 className="text-sm font-bold text-slate-900">
                Geliştirilmesi Gereken Zayıf Kazanımlar ({weakOutcomes.length})
              </h4>
            </div>
            <span className="text-[11px] text-slate-400">&lt; %70 Başarı</span>
          </div>

          <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
            {weakOutcomes.length > 0 ? (
              weakOutcomes.map((k) => (
                <div
                  key={`${k.ders}-${k.konu}`}
                  className="bg-rose-50/40 border border-rose-100 rounded-2xl p-3.5 space-y-2"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{k.ders} - {k.konu}</span>
                    <span className="font-black text-rose-700">%{k.basariYuzdesi}</span>
                  </div>
                  <div className="w-full h-2 bg-rose-100 rounded-full overflow-hidden">
                    <div
                      className="bg-rose-500 h-full rounded-full"
                      style={{ width: `${k.basariYuzdesi}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>{k.dogruSayisi} D / {k.toplamSoru} Soru</span>
                    <span>{k.yanlisSayisi} Yanlış, {k.bosSayisi} Boş</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-slate-400 text-xs">
                Kritik seviyede zayıf kazanım tespit edilmedi.
              </div>
            )}
          </div>
        </div>

        {/* Strong Outcomes */}
        <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-bold text-slate-900">
                Güçlü & Kazanılmış Konular ({strongOutcomes.length})
              </h4>
            </div>
            <span className="text-[11px] text-slate-400">&gt;= %70 Başarı</span>
          </div>

          <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
            {strongOutcomes.length > 0 ? (
              strongOutcomes.map((k) => (
                <div
                  key={`${k.ders}-${k.konu}`}
                  className="bg-emerald-50/40 border border-emerald-100 rounded-2xl p-3.5 space-y-2"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{k.ders} - {k.konu}</span>
                    <span className="font-black text-emerald-700">%{k.basariYuzdesi}</span>
                  </div>
                  <div className="w-full h-2 bg-emerald-100 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-500 h-full rounded-full"
                      style={{ width: `${k.basariYuzdesi}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>{k.dogruSayisi} D / {k.toplamSoru} Soru</span>
                    <span>Stabil ve Pekiştirilmiş</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-slate-400 text-xs">
                Henüz yeterli soru verisi girilmedi.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* AI Coaching Prescription Card */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-8 shadow-2xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-100">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">
                  Yapay Zekâ Hedef Odaklı Koçluk Reçetesi
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Gemini AI
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Öğrencinin hedeflediği {student.hedefUniversite} için nokta atışı 4 adımlı aksiyon planı
              </p>
            </div>
          </div>

          <button
            onClick={handleGetAICoachingAdvice}
            disabled={isLoadingAi}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-100 transition-all disabled:opacity-50 active:scale-95 shrink-0"
          >
            {isLoadingAi ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Reçete Hazırlanıyor...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>🤖 Yapay Zekâdan Hedef Odaklı Tavsiye Al</span>
              </>
            )}
          </button>
        </div>

        {aiAdvice ? (
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-6 text-xs text-slate-800 leading-relaxed whitespace-pre-line space-y-3 font-sans">
            {aiAdvice}
          </div>
        ) : (
          <div className="bg-slate-50/70 border border-dashed border-slate-200 rounded-2xl p-8 text-center text-slate-400 space-y-2">
            <Sparkles className="w-6 h-6 text-indigo-400 mx-auto" />
            <p className="text-xs font-semibold text-slate-700">
              Kişiselleştirilmiş Koçluk Reçetesi Oluşturun
            </p>
            <p className="text-[11px] text-slate-400 max-w-md mx-auto">
              Yukarıdaki butona tıklayarak öğrencinin zayıf MEB kazanımlarını, hedef taban puanını ve deneme netlerini sentezleyen profesyonel bir koçluk stratejisi alabilirsiniz.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
