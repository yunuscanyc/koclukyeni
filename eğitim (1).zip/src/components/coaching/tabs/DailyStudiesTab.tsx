import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Circle, 
  Trash2, 
  Eye, 
  Target,
  BookOpen,
  HelpCircle,
  Sparkles,
  AlertCircle,
  Check,
  Layers
} from 'lucide-react';
import { GorevProgrami, GorevTuru, isQuestionTaskType } from '../../../types';
import { TaskDetailModal } from '../../modals/TaskDetailModal';

interface DailyStudiesTabProps {
  tasks: GorevProgrami[];
  onAddTask: (task: Omit<GorevProgrami, 'id'>) => void;
  onToggleComplete: (id: string) => void;
  onDeleteTask: (id: string) => void;
  studentName: string;
}

const COMMON_SUBJECTS = [
  'AYT Matematik',
  'TYT Türkçe',
  'AYT Fizik',
  'AYT Kimya',
  'AYT Biyoloji',
  'TYT Matematik',
  'TYT Geometri',
  'AYT Edebiyat',
  'Tarih & Coğrafya'
];

export const DailyStudiesTab: React.FC<DailyStudiesTabProps> = ({
  tasks,
  onAddTask,
  onToggleComplete,
  onDeleteTask,
  studentName,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedTask, setSelectedTask] = useState<GorevProgrami | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('Bekleyenler');
  const [typeFilter, setTypeFilter] = useState<'all' | 'question' | 'study'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Form Task Category ('soru' or 'konu')
  const [taskCategory, setTaskCategory] = useState<'soru' | 'konu'>('soru');

  // Form states
  const [tarih, setTarih] = useState(new Date().toISOString().split('T')[0]);
  const [baslangicSaati, setBaslangicSaati] = useState('18:00');
  const [hedefSureDakika, setHedefSureDakika] = useState<number | string>(60);
  const [gorevTuru, setGorevTuru] = useState<GorevTuru>('Soru Çözümü');
  const [ders, setDers] = useState('AYT Matematik');
  const [konu, setKonu] = useState('');
  const [hedefSoruSayisi, setHedefSoruSayisi] = useState<number | string>(50);
  const [hedefKazanim, setHedefKazanim] = useState('');
  const [kocAciklamasi, setKocAciklamasi] = useState('');
  
  // Feedback states
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Switch task category
  const handleCategoryChange = (category: 'soru' | 'konu') => {
    setTaskCategory(category);
    setErrorMessage(null);
    if (category === 'soru') {
      setGorevTuru('Soru Çözümü');
      if (!hedefSoruSayisi || Number(hedefSoruSayisi) <= 0) {
        setHedefSoruSayisi(50);
      }
    } else {
      setGorevTuru('Konu Tekrarı');
      if (!hedefSureDakika || Number(hedefSureDakika) <= 0) {
        setHedefSureDakika(60);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Form validations
    if (!ders.trim()) {
      setErrorMessage('Lütfen ders adını belirtiniz.');
      return;
    }

    if (!konu.trim()) {
      setErrorMessage('Lütfen konu başlığını yazınız (Örn: Türev Geometrik Yorum).');
      return;
    }

    const isQuestion = taskCategory === 'soru' || isQuestionTaskType(gorevTuru);

    if (isQuestion) {
      const parsedQuestions = Number(hedefSoruSayisi);
      if (!parsedQuestions || parsedQuestions <= 0) {
        setErrorMessage('Soru çözme görevi için lütfen hedef soru adedini giriniz (en az 1 soru).');
        return;
      }
    } else {
      const parsedDuration = Number(hedefSureDakika);
      if (!parsedDuration || parsedDuration <= 0) {
        setErrorMessage('Konu tekrarı / çalışma görevi için lütfen süreyi (dakika) giriniz.');
        return;
      }
    }

    setIsSubmitting(true);

    try {
      onAddTask({
        studentId: '',
        tarih,
        baslangicSaati: baslangicSaati || '18:00',
        hedefSureDakika: !isQuestion ? (Number(hedefSureDakika) || 60) : (Number(hedefSureDakika) || 60),
        gorevTuru,
        ders: ders.trim(),
        konu: konu.trim(),
        hedefSoruSayisi: isQuestion ? (Number(hedefSoruSayisi) || 0) : 0,
        hedefKazanim: hedefKazanim.trim(),
        kocAciklamasi: kocAciklamasi.trim(),
        durum: 'Bekliyor',
      });

      // Reset form & show feedback
      setKonu('');
      setHedefKazanim('');
      setKocAciklamasi('');
      setSuccessMessage('Görev başarıyla eklendi!');
      setStatusFilter('Bekleyenler'); // Ensure it is visible
      setTypeFilter('all');

      setTimeout(() => {
        setSuccessMessage(null);
        setShowAddForm(false);
      }, 1200);
    } catch (err: any) {
      setErrorMessage('Görev kaydedilirken bir hata oluştu: ' + (err?.message || 'Bilinmeyen hata'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredTasks = tasks.filter((t) => {
    let matchesStatus = true;
    if (statusFilter === 'Bekleyenler') {
      matchesStatus = t.durum !== 'Tamamlandı';
    } else if (statusFilter !== 'Tümü') {
      matchesStatus = t.durum === statusFilter;
    }
    const isQ = isQuestionTaskType(t.gorevTuru);
    const matchesType =
      typeFilter === 'all' ||
      (typeFilter === 'question' && isQ) ||
      (typeFilter === 'study' && !isQ);

    const matchesSearch =
      t.konu.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.ders.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.hedefKazanim && t.hedefKazanim.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesStatus && matchesType && matchesSearch;
  });

  const totalTasks = tasks.length;
  const completedCount = tasks.filter((t) => t.durum === 'Tamamlandı').length;
  const pendingCount = tasks.filter((t) => t.durum !== 'Tamamlandı').length;
  const progressPercent = totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0;

  // Question tasks vs Study tasks count
  const questionTasksCount = tasks.filter(t => isQuestionTaskType(t.gorevTuru)).length;
  const studyTasksCount = tasks.filter(t => !isQuestionTaskType(t.gorevTuru)).length;

  return (
    <div className="space-y-6">
      {/* Progress & Stats Card */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-7 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              3. Çalışma Programı & Haftalık Görev Takibi
            </h3>
            <p className="text-xs text-slate-500">
              {studentName} için atanan soru hedefleri, konu tekrarları ve koç talimatları
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs px-3 py-1 rounded-xl bg-amber-50 text-amber-800 font-bold border border-amber-200 flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-amber-600" />
              <span>{questionTasksCount} Soru Görevi</span>
            </span>
            <span className="text-xs px-3 py-1 rounded-xl bg-indigo-50 text-indigo-800 font-bold border border-indigo-200 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-indigo-600" />
              <span>{studyTasksCount} Konu/Tekrar</span>
            </span>
            <span className="text-xs px-3 py-1 rounded-xl bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
              {completedCount} Tamamlandı
            </span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs text-slate-500 font-medium">
            <span>Genel Görev Tamamlanma Oranı</span>
            <span className="font-bold text-slate-900">%{progressPercent} ({completedCount}/{totalTasks})</span>
          </div>
          <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Action and Filter Controls */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Görevlerde, derslerde veya konularda ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs focus:ring-2 focus:ring-indigo-500 shadow-2xs"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Category Filter */}
          <div className="flex items-center bg-slate-100 p-1 rounded-2xl">
            <button
              onClick={() => setTypeFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                typeFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tümü
            </button>
            <button
              onClick={() => setTypeFilter('question')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                typeFilter === 'question'
                  ? 'bg-white text-amber-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Target className="w-3.5 h-3.5 text-amber-500" />
              <span>Soru Çözme</span>
            </button>
            <button
              onClick={() => setTypeFilter('study')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                typeFilter === 'study'
                  ? 'bg-white text-indigo-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-indigo-500" />
              <span>Konu / Tekrar</span>
            </button>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            {['Bekleyenler', 'Tamamlandı', 'Tümü'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                  statusFilter === st
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <button
            onClick={() => {
              setShowAddForm(!showAddForm);
              setErrorMessage(null);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-all active:scale-95 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Yeni Görev Ekle</span>
          </button>
        </div>
      </div>

      {/* Add Task Form with Specific Soru vs Konu Distinction */}
      {showAddForm && (
        <div className="bg-white border-2 border-indigo-500/30 rounded-3xl p-6 sm:p-7 shadow-xl space-y-5 animate-in fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h4 className="text-sm font-black text-slate-900">
                Öğrenciye Yeni Çalışma Görevi Ata
              </h4>
              <p className="text-xs text-slate-500">
                Görev türüne göre soru adedi veya çalışma süresi girerek programa ekleyin.
              </p>
            </div>
            <button
              onClick={() => setShowAddForm(false)}
              className="text-xs font-bold text-slate-400 hover:text-slate-600 px-2 py-1 rounded-lg hover:bg-slate-100"
            >
              Kapat
            </button>
          </div>

          {/* Alert Messages */}
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span className="font-semibold">{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-bold">{successMessage}</span>
            </div>
          )}

          {/* TWO MAIN TASK MODES: Soru Çözümü vs Konu Tekrarı / Ders Çalışması */}
          <div className="space-y-2">
            <label className="block text-xs font-black text-slate-700 uppercase tracking-wider">
              1. Görev Ayrımını Seçin:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => handleCategoryChange('soru')}
                className={`p-4 rounded-2xl border-2 text-left transition-all flex items-start gap-3.5 ${
                  taskCategory === 'soru'
                    ? 'border-amber-500 bg-amber-50/50 shadow-sm ring-2 ring-amber-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className={`p-2.5 rounded-xl shrink-0 ${taskCategory === 'soru' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-500'}`}>
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-900 flex items-center gap-2">
                    <span>Soru Çözümü & Deneme</span>
                    {taskCategory === 'soru' && (
                      <span className="px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 text-[10px] font-black">
                        Seçildi
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Öğrenciye çözülecek <strong>Soru Adedi</strong> hedeflenir. Listede soru adedi öne çıkarılır.
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleCategoryChange('konu')}
                className={`p-4 rounded-2xl border-2 text-left transition-all flex items-start gap-3.5 ${
                  taskCategory === 'konu'
                    ? 'border-indigo-500 bg-indigo-50/50 shadow-sm ring-2 ring-indigo-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className={`p-2.5 rounded-xl shrink-0 ${taskCategory === 'konu' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-900 flex items-center gap-2">
                    <span>Konu Tekrarı & Ders Çalışması</span>
                    {taskCategory === 'konu' && (
                      <span className="px-2 py-0.5 rounded-full bg-indigo-200 text-indigo-900 text-[10px] font-black">
                        Seçildi
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Öğrenciye ayrılacak <strong>Çalışma Süresi (Dakika)</strong> hedeflenir. Listede süre öne çıkarılır.
                  </div>
                </div>
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 pt-1">
            {/* Alt Tür & Zamanlama */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {taskCategory === 'soru' ? 'Soru Türü' : 'Çalışma Türü'}
                </label>
                <select
                  value={gorevTuru}
                  onChange={(e) => setGorevTuru(e.target.value as GorevTuru)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 font-medium"
                >
                  {taskCategory === 'soru' ? (
                    <>
                      <option value="Soru Çözümü">Soru Çözümü (Test / Soru Bankası)</option>
                      <option value="Branş Denemesi">Branş Denemesi</option>
                      <option value="Genel Deneme">Genel Deneme Çözümü</option>
                    </>
                  ) : (
                    <>
                      <option value="Konu Tekrarı">Konu Tekrarı</option>
                      <option value="Ders Çalışma">Ders Çalışma</option>
                      <option value="Konu Çalışması">Konu Anlatımı / Çalışması</option>
                      <option value="Tekrar & Özet">Özet Çıkarma & Formül Tekrarı</option>
                      <option value="Video İzleme">Ders Videosu İzleme</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Tarih</label>
                <div className="flex gap-1.5">
                  <input
                    type="date"
                    required
                    value={tarih}
                    onChange={(e) => setTarih(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="button"
                    onClick={() => setTarih(new Date().toISOString().split('T')[0])}
                    className="px-2.5 py-1 text-[11px] font-bold rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 whitespace-nowrap"
                  >
                    Bugün
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Başlama Saati</label>
                <input
                  type="time"
                  value={baslangicSaati}
                  onChange={(e) => setBaslangicSaati(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* DYNAMIC FIELD: Soru Adedi OR Çalışma Süresi */}
            {taskCategory === 'soru' ? (
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="text-xs font-black text-amber-900 flex items-center gap-1.5">
                    <Target className="w-4 h-4 text-amber-600" />
                    <span>Hedef Soru Adedi (Çözülecek Soru Sayısı) *</span>
                  </label>
                  <span className="text-[11px] text-amber-700 font-semibold">
                    Öğrenci bu görevi tamamlamak için bu kadar soru çözecektir.
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="relative flex-1 max-w-[200px]">
                    <input
                      type="number"
                      min="1"
                      placeholder="Örn: 60"
                      value={hedefSoruSayisi}
                      onChange={(e) => setHedefSoruSayisi(e.target.value)}
                      className="w-full pl-3.5 pr-14 py-2 bg-white border border-amber-300 rounded-xl text-sm font-black text-amber-950 focus:ring-2 focus:ring-amber-500"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-amber-700">
                      Soru
                    </span>
                  </div>

                  {/* Quick Select Buttons for Question Count */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[25, 40, 50, 75, 100, 120].map((qty) => (
                      <button
                        key={qty}
                        type="button"
                        onClick={() => setHedefSoruSayisi(qty)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                          Number(hedefSoruSayisi) === qty
                            ? 'bg-amber-600 text-white shadow-xs'
                            : 'bg-white text-amber-900 border border-amber-200 hover:bg-amber-100/50'
                        }`}
                      >
                        {qty} Soru
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="text-xs font-black text-indigo-900 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-indigo-600" />
                    <span>Hedef Çalışma Süresi (Dakika) *</span>
                  </label>
                  <span className="text-[11px] text-indigo-700 font-semibold">
                    Konu tekrarı veya video için ayrılacak net çalışma süresi
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="relative flex-1 max-w-[200px]">
                    <input
                      type="number"
                      min="1"
                      placeholder="Örn: 60"
                      value={hedefSureDakika}
                      onChange={(e) => setHedefSureDakika(e.target.value)}
                      className="w-full pl-3.5 pr-14 py-2 bg-white border border-indigo-300 rounded-xl text-sm font-black text-indigo-950 focus:ring-2 focus:ring-indigo-500"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-indigo-700">
                      Dakika
                    </span>
                  </div>

                  {/* Quick Select Buttons for Duration */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[30, 45, 60, 90, 120].map((mins) => (
                      <button
                        key={mins}
                        type="button"
                        onClick={() => setHedefSureDakika(mins)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                          Number(hedefSureDakika) === mins
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'bg-white text-indigo-900 border border-indigo-200 hover:bg-indigo-100/50'
                        }`}
                      >
                        {mins} dk
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Ders & Konu */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Ders *</label>
                <input
                  type="text"
                  required
                  placeholder="Örn: AYT Matematik, TYT Türkçe"
                  value={ders}
                  onChange={(e) => setDers(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
                />

                {/* Common Subject Pills */}
                <div className="flex items-center gap-1.5 flex-wrap mt-1.5">
                  <span className="text-[10px] text-slate-400 font-semibold">Hızlı Seç:</span>
                  {COMMON_SUBJECTS.map((sub) => (
                    <button
                      key={sub}
                      type="button"
                      onClick={() => setDers(sub)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md transition-all ${
                        ders === sub
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                      }`}
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Konu Başlığı *</label>
                <input
                  type="text"
                  required
                  placeholder="Örn: Türev Geometrik Yorum & Teğet Denklemleri"
                  value={konu}
                  onChange={(e) => setKonu(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 font-medium"
                />
              </div>
            </div>

            {/* İlişkili MEB Kazanımı */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                İlişkili MEB Kazanımı <span className="text-slate-400 font-normal">(İsteğe Bağlı)</span>
              </label>
              <input
                type="text"
                placeholder="Örn: MAT.AYT.05 - Türev yardımıyla fonksiyonların artan-azalan aralıklarını belirler."
                value={hedefKazanim}
                onChange={(e) => setHedefKazanim(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Koçun Özel Talimatı */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Koçun Özel Talimatı / Çalışma Notu <span className="text-slate-400 font-normal">(İsteğe Bağlı)</span>
              </label>
              <textarea
                rows={2}
                placeholder="Hangi kitaptan çözülecek, süre tutulacak mı, takılan sorular nasıl analiz edilecek?"
                value={kocAciklamasi}
                onChange={(e) => setKocAciklamasi(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  setShowAddForm(false);
                  setErrorMessage(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Vazgeç
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-100 transition-all flex items-center gap-2 active:scale-98 disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                <span>
                  {taskCategory === 'soru'
                    ? `Görevi Kaydet (${hedefSoruSayisi || 0} Soru Hedefi)`
                    : `Görevi Kaydet (${hedefSureDakika || 0} dk Süre)`}
                </span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Task Cards List: Distinct Display for Soru vs Konu */}
      <div className="space-y-3">
        {filteredTasks.length > 0 ? (
          filteredTasks.map((t) => {
            const isCompleted = t.durum === 'Tamamlandı';
            const isQuestion = isQuestionTaskType(t.gorevTuru);

            return (
              <div
                key={t.id}
                className={`bg-white border rounded-3xl p-4 sm:p-5 shadow-2xs hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  isCompleted
                    ? 'border-emerald-200/80 bg-emerald-50/15'
                    : isQuestion
                    ? 'border-slate-200/90 hover:border-amber-300'
                    : 'border-slate-200/90 hover:border-indigo-300'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <button
                    onClick={() => onToggleComplete(t.id)}
                    className="mt-0.5 text-slate-400 hover:text-emerald-600 transition-colors shrink-0"
                    title={isCompleted ? 'Devam Ediyora Çevir' : 'Görevi Tamamla'}
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                    ) : (
                      <Circle className="w-6 h-6" />
                    )}
                  </button>

                  <div className="space-y-1.5">
                    {/* Top Row: Lesson, Task Type & DISTINCT PRIMARY BADGE */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-black text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-lg border border-indigo-100">
                        {t.ders}
                      </span>

                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                        {t.gorevTuru}
                      </span>

                      {/* DISTINCT DISPLAY: Soru Çözümü ise Soru Adedi, Konu ise Süre */}
                      {isQuestion ? (
                        <span className="text-[11px] font-black px-2.5 py-0.5 rounded-lg bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1 shadow-2xs">
                          <Target className="w-3.5 h-3.5 text-amber-700" />
                          <span>Hedef: {t.hedefSoruSayisi} Soru</span>
                        </span>
                      ) : (
                        <span className="text-[11px] font-black px-2.5 py-0.5 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1 shadow-2xs">
                          <Clock className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Süre: {t.hedefSureDakika} Dakika</span>
                        </span>
                      )}

                      {/* Durum Rozeti */}
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                          isCompleted
                            ? 'bg-emerald-100 text-emerald-800'
                            : t.durum === 'Devam Ediyor'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {t.durum}
                      </span>
                    </div>

                    {/* Konu Başlığı */}
                    <h4
                      className={`text-sm sm:text-base font-black text-slate-900 ${
                        isCompleted ? 'line-through text-slate-400' : ''
                      }`}
                    >
                      {t.konu}
                    </h4>

                    {/* Meta: Tarih, Saat & Detay */}
                    <div className="flex items-center gap-3 text-xs text-slate-400 flex-wrap">
                      <span className="flex items-center gap-1 text-slate-500 font-medium">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>{t.tarih}</span>
                      </span>

                      <span className="flex items-center gap-1 text-slate-500 font-medium">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>Saat: {t.baslangicSaati || '--:--'}</span>
                      </span>

                      {isQuestion && t.hedefSureDakika > 0 && (
                        <span className="text-slate-400 text-[11px]">
                          (Tahmini: {t.hedefSureDakika} dk)
                        </span>
                      )}
                    </div>

                    {/* MEB Kazanımı */}
                    {t.hedefKazanim && (
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-0.5">
                        <BookOpen className="w-3 h-3 text-indigo-500 shrink-0" />
                        <span className="truncate max-w-xl">{t.hedefKazanim}</span>
                      </div>
                    )}

                    {/* Koç Açıklaması */}
                    {t.kocAciklamasi && (
                      <p className="text-xs text-slate-700 bg-slate-50 px-3 py-1.5 rounded-xl mt-1 border border-slate-100 font-medium leading-relaxed">
                        💡 <strong>Koç Talimatı:</strong> {t.kocAciklamasi}
                      </p>
                    )}

                    {/* Öğrenci Geri Bildirimi / Notu (Varsa) */}
                    {t.ogrenciNotu && (
                      <p className="text-xs text-emerald-900 bg-emerald-50/70 px-3 py-1.5 rounded-xl mt-1.5 border border-emerald-100/80 font-semibold leading-relaxed animate-in fade-in">
                        📝 <strong>Öğrenci Notu:</strong> "{t.ogrenciNotu}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Sağ Butonlar */}
                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => setSelectedTask(t)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>İncele</span>
                  </button>

                  <button
                    onClick={() => {
                      if (confirm('Bu çalışma görevini silmek istediğinize emin misiniz?')) {
                        onDeleteTask(t.id);
                      }
                    }}
                    className="p-2 text-slate-300 hover:text-rose-600 rounded-xl hover:bg-rose-50 transition-colors"
                    title="Görevi Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-2">
            <Calendar className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-xs font-semibold text-slate-600">Bu kritere uygun görev bulunamadı.</p>
            <p className="text-[11px] text-slate-400">Yeni görev eklemek için yukarıdaki "Yeni Görev Ekle" butonuna tıklayabilirsiniz.</p>
          </div>
        )}
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
          onToggleComplete={onToggleComplete}
          onDelete={onDeleteTask}
        />
      )}
    </div>
  );
};
