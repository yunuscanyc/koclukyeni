import React, { useState, useEffect } from 'react';
import { 
  Archive, 
  Search, 
  Calendar, 
  CheckCircle2, 
  XCircle, 
  MinusCircle, 
  Trash2, 
  Eye, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Camera, 
  BookOpen,
  ChevronRight,
  Sparkles,
  Loader2,
  Hourglass,
  RefreshCw
} from 'lucide-react';
import { OgrenciSinavKaydi, SinavSorusu } from '../../../types';
import { retryExamAIAnalysis } from '../../../lib/apiService';

interface ExamHistoryTabProps {
  archives: OgrenciSinavKaydi[];
  onDeleteArchive: (id: string) => void;
  studentName: string;
  onSaveExamArchive?: (archive: OgrenciSinavKaydi) => void;
}

export const ExamHistoryTab: React.FC<ExamHistoryTabProps> = ({
  archives,
  onDeleteArchive,
  studentName,
  onSaveExamArchive,
}) => {
  const [selectedArchiveId, setSelectedArchiveId] = useState<string | null>(
    archives[0]?.id || null
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<'Tümü' | 'TYT' | 'AYT'>('Tümü');

  // Viewer State for the selected exam
  const [activePageIndex, setActivePageIndex] = useState<number>(0);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [selectedQuestionNo, setSelectedQuestionNo] = useState<number | null>(null);
  const [selectedPageFilter, setSelectedPageFilter] = useState<'all' | number>('all');

  const [isRetrying, setIsRetrying] = useState(false);
  const [retryMessage, setRetryMessage] = useState<string | null>(null);

  // When coach views an archive, mark it as read (isNew: false)
  useEffect(() => {
    if (selectedArchiveId && onSaveExamArchive) {
      const active = archives.find((a) => a.id === selectedArchiveId);
      if (active && active.isNew) {
        onSaveExamArchive({ ...active, isNew: false, durum: 'İncelendi' });
      }
    }
  }, [selectedArchiveId, archives, onSaveExamArchive]);

  const handleRetryAI = async (archiveId: string) => {
    try {
      setIsRetrying(true);
      setRetryMessage(null);
      const res = await retryExamAIAnalysis(archiveId, activeArchive || undefined);
      setRetryMessage(res.message || 'Yapay zekâ kuyruğuna eklendi.');
    } catch (err: any) {
      setRetryMessage('Hata: ' + (err?.message || 'İşlem başlatılamadı'));
    } finally {
      setIsRetrying(false);
    }
  };

  const getAIStatusTag = (arch: OgrenciSinavKaydi, isSelected: boolean) => {
    const status = arch.aiStatus || (arch.sorular && arch.sorular.length > 0 ? 'completed' : 'processing');
    if (status === 'completed') {
      return (
        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 ${
          isSelected ? 'bg-emerald-400 text-slate-950' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
        }`}>
          <CheckCircle2 className="w-2.5 h-2.5" />
          <span>Yapay Zekâ Çözdü</span>
        </span>
      );
    }
    if (status === 'rate_limited') {
      return (
        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 animate-pulse ${
          isSelected ? 'bg-amber-300 text-amber-950' : 'bg-amber-50 text-amber-800 border border-amber-200'
        }`}>
          <Hourglass className="w-2.5 h-2.5" />
          <span>Kota Bekleniyor</span>
        </span>
      );
    }
    return (
      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 ${
        isSelected ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
      }`}>
        <Loader2 className="w-2.5 h-2.5 animate-spin" />
        <span>Devam Ediyor</span>
      </span>
    );
  };

  const filteredArchives = archives.filter((a) => {
    const matchesType = selectedType === 'Tümü' || a.sinavTuru === selectedType;
    const matchesSearch =
      a.sinavAdi.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.tarih.includes(searchQuery);
    return matchesType && matchesSearch;
  });

  const activeArchive =
    archives.find((a) => a.id === selectedArchiveId) || null;

  // Reset page and selection when switching active archive
  useEffect(() => {
    setActivePageIndex(0);
    setSelectedQuestionNo(null);
    setSelectedPageFilter('all');
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, [selectedArchiveId]);

  // Zoom controls
  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.25, 3));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.25, 0.5));
  const handleResetZoom = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Pan image with mouse & touch dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    e.preventDefault();
    setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  };

  const handleMouseUp = () => setIsDragging(false);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      setDragStart({ x: e.touches[0].clientX - pan.x, y: e.touches[0].clientY - pan.y });
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    setPan({ x: e.touches[0].clientX - dragStart.x, y: e.touches[0].clientY - dragStart.y });
  };

  const handleTouchEnd = () => setIsDragging(false);

  // When clicking on a question, switch to that question's page photo and highlight
  const handleSelectQuestion = (q: SinavSorusu) => {
    setSelectedQuestionNo(q.soruNo);

    // Determine target page index
    let targetIndex = -1;
    if (typeof q.sayfaNo === 'number' && q.sayfaNo >= 1) {
      targetIndex = q.sayfaNo - 1;
    } else if (q.sayfaFotoUrl && activeArchive?.sayfaFotolari) {
      targetIndex = activeArchive.sayfaFotolari.indexOf(q.sayfaFotoUrl);
    }

    if (targetIndex >= 0 && activeArchive?.sayfaFotolari && targetIndex < activeArchive.sayfaFotolari.length) {
      setActivePageIndex(targetIndex);
    }
  };

  const currentPhoto = activeArchive?.sayfaFotolari?.[activePageIndex] || null;

  // Filter questions by selected page filter if active
  const displayedQuestions = (activeArchive?.sorular || []).filter((q) => {
    if (selectedPageFilter === 'all') return true;
    const qPage = q.sayfaNo || 1;
    return qPage === selectedPageFilter;
  });

  const selectedQuestionObj = activeArchive?.sorular?.find((q) => q.soruNo === selectedQuestionNo);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-7 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Archive className="w-4 h-4" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                9. Sınav Geçmişi & Sayfa Fotoğrafları Arşivi
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              {studentName} için yapay zekâ optik taraması yapılmış tüm denemeler ve sayfa görselleri ({archives.length} Kayıt)
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            {['Tümü', 'TYT', 'AYT'].map((t) => (
              <button
                key={t}
                onClick={() => setSelectedType(t as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                  selectedType === t
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main 2-Column Responsive Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left List of Archives */}
        <div className="lg:col-span-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Arşivde deneme ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 shadow-2xs"
            />
          </div>

          <div className="space-y-1.5 max-h-[700px] overflow-y-auto pr-1">
            {filteredArchives.length > 0 ? (
              filteredArchives.map((arch) => {
                const isSelected = activeArchive?.id === arch.id;
                return (
                  <div
                    key={arch.id}
                    onClick={() => {
                      setSelectedArchiveId(isSelected ? null : arch.id);
                      setActivePageIndex(0);
                      setZoom(1);
                      setPan({ x: 0, y: 0 });
                    }}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer space-y-1.5 ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white text-slate-800 border-slate-200/90 hover:border-indigo-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1 flex-wrap">
                        <span
                          className={`text-[9px] font-black px-1.5 py-0.2 rounded ${
                            isSelected
                              ? 'bg-white/20 text-white'
                              : arch.sinavTuru === 'TYT'
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {arch.sinavTuru}
                        </span>

                        {arch.isNew && (
                          <span className={`text-[8px] font-black px-1 py-0.2 rounded-full ${
                            isSelected ? 'bg-amber-400 text-slate-950' : 'bg-amber-100 text-amber-900 border border-amber-300'
                          } animate-pulse`}>
                            YENİ
                          </span>
                        )}

                        {arch.ogrenciYukledi && !arch.isNew && (
                          <span className={`text-[8px] font-bold px-1 py-0.2 rounded ${
                            isSelected ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700'
                          }`}>
                            📸 Öğrenci
                          </span>
                        )}

                        {getAIStatusTag(arch, isSelected)}
                      </div>

                      <span
                        className={`text-[9px] font-semibold ${
                          isSelected ? 'text-indigo-100' : 'text-slate-400'
                        }`}
                      >
                        {arch.tarih}
                      </span>
                    </div>

                    <h4 className="text-[11px] font-bold leading-tight line-clamp-1">{arch.sinavAdi}</h4>

                    <div
                      className={`flex items-center justify-between pt-1 border-t text-[10px] font-bold ${
                        isSelected ? 'border-white/10 text-white' : 'border-slate-100 text-slate-500'
                      }`}
                    >
                      <span>
                        Net: <strong className={isSelected ? 'text-white' : 'text-indigo-700'}>{arch.toplamNet.toFixed(2)}</strong>
                      </span>
                      <span>
                        {arch.dogruSayisi}D • {arch.yanlisSayisi}Y • {arch.bosSayisi}B
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center text-slate-400 text-xs">
                Arşivlenmiş sınav kaydı bulunamadı.
              </div>
            )}
          </div>
        </div>

        {/* Right Detail Viewer: Top Photo Viewer + Bottom Questions Table */}
        <div className="lg:col-span-8 space-y-6">
          {activeArchive ? (
            <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-2xs space-y-6">
              {/* Exam Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                        activeArchive.sinavTuru === 'TYT'
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {activeArchive.sinavTuru}
                    </span>
                    <h3 className="text-base font-bold text-slate-900">{activeArchive.sinavAdi}</h3>
                    {getAIStatusTag(activeArchive, false)}
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Uygulama Tarihi: {activeArchive.tarih} • Toplam {activeArchive.toplamSoru} Soru
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="px-3.5 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800">
                    Net: <span className="text-indigo-700">{activeArchive.toplamNet.toFixed(2)}</span>
                  </div>

                  <button
                    onClick={() => {
                      if (confirm('Bu sınav arşiv kaydını silmek istediğinize emin misiniz?')) {
                        onDeleteArchive(activeArchive.id);
                      }
                    }}
                    className="p-2 text-slate-300 hover:text-rose-600 rounded-xl hover:bg-slate-50 transition-colors"
                    title="Arşivi Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Status Alert for Background AI / Quota */}
              {(activeArchive.aiStatus === 'processing' || activeArchive.aiStatus === 'rate_limited' || activeArchive.aiStatus === 'error') && (
                <div className={`p-4 rounded-2xl border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  activeArchive.aiStatus === 'rate_limited'
                    ? 'bg-amber-50 border-amber-200 text-amber-900'
                    : activeArchive.aiStatus === 'error'
                    ? 'bg-rose-50 border-rose-200 text-rose-900'
                    : 'bg-indigo-50 border-indigo-200 text-indigo-900'
                }`}>
                  <div className="flex items-start gap-2.5">
                    {activeArchive.aiStatus === 'rate_limited' ? (
                      <Hourglass className="w-4 h-4 text-amber-600 shrink-0 mt-0.5 animate-pulse" />
                    ) : activeArchive.aiStatus === 'error' ? (
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    ) : (
                      <Loader2 className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5 animate-spin" />
                    )}
                    <div>
                      <div className="font-bold">
                        {activeArchive.aiStatus === 'rate_limited'
                          ? '⏳ API Kotası Bekleniyor (Otomatik Devam Edecek)'
                          : activeArchive.aiStatus === 'error'
                          ? '❌ Çözüm Sırasında Sorun Oluştu'
                          : '⚡ Yapay Zekâ Soruları Arka Planda Çözüyor'}
                      </div>
                      <div className="text-[11px] opacity-90 mt-0.5">
                        {activeArchive.aiStatusMessage || 'Sistem test fotoğraflarındaki soruları ve MEB kazanımlarını arka planda analiz ediyor.'}
                      </div>
                      {retryMessage && (
                        <div className="text-[11px] font-bold text-indigo-700 mt-1">
                          {retryMessage}
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => handleRetryAI(activeArchive.id)}
                    disabled={isRetrying}
                    className="shrink-0 px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs self-end sm:self-auto disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
                    <span>{isRetrying ? 'Kuyruğa Alınıyor...' : 'Yeniden Çözdür'}</span>
                  </button>
                </div>
              )}

              {/* Page Photos Viewer with Zoom & Pan */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Camera className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs font-bold text-slate-900">
                      Kitapçık Sayfası Fotoğrafı ({activeArchive.sayfaFotolari?.length || 0} Sayfa)
                    </span>
                  </div>

                  {/* Zoom controls */}
                  <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200">
                    <button
                      onClick={handleZoomIn}
                      className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200"
                      title="Yakınlaştır"
                    >
                      <ZoomIn className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleZoomOut}
                      className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200"
                      title="Uzaklaştır"
                    >
                      <ZoomOut className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleResetZoom}
                      className="p-1 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200"
                      title="Sıfırla"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] font-bold text-slate-500 px-1.5">
                      {Math.round(zoom * 100)}%
                    </span>
                  </div>
                </div>

                {/* Photo Display Viewport */}
                <div className="relative w-full h-84 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center select-none">
                  {/* Selected Question Overlay Indicator */}
                  {selectedQuestionObj && (
                    <div className="absolute top-3 left-3 right-3 z-10 bg-slate-900/90 backdrop-blur-md border border-indigo-500/40 text-white px-3.5 py-2 rounded-xl text-xs flex items-center justify-between shadow-lg">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-md bg-indigo-600 text-white font-black text-[10px] flex items-center justify-center">
                          {selectedQuestionObj.soruNo}
                        </span>
                        <div>
                          <span className="font-bold text-indigo-200">Soru {selectedQuestionObj.soruNo}:</span> {selectedQuestionObj.ders} - {selectedQuestionObj.konu}
                          <span className="text-[10px] text-slate-400 ml-2">(Sayfa {selectedQuestionObj.sayfaNo || (activePageIndex + 1)})</span>
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedQuestionNo(null);
                        }}
                        className="text-slate-400 hover:text-white text-[11px] px-2 py-0.5 rounded-lg hover:bg-slate-800"
                      >
                        Kapat ✕
                      </button>
                    </div>
                  )}

                  {currentPhoto ? (
                    <div
                      onMouseDown={handleMouseDown}
                      onMouseMove={handleMouseMove}
                      onMouseUp={handleMouseUp}
                      onMouseLeave={handleMouseUp}
                      onTouchStart={handleTouchStart}
                      onTouchMove={handleTouchMove}
                      onTouchEnd={handleTouchEnd}
                      className="w-full h-full flex items-center justify-center cursor-grab active:cursor-grabbing overflow-hidden touch-none"
                    >
                      <img
                        src={currentPhoto}
                        alt="Sayfa Görseli"
                        style={{
                          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                          transition: isDragging ? 'none' : 'transform 0.15s ease-out',
                          transformOrigin: 'center center',
                        }}
                        className="max-w-full max-h-full object-contain pointer-events-none select-none"
                      />
                    </div>
                  ) : (
                    <div className="text-center text-slate-500 text-xs">
                      Bu sınav için sayfa fotoğrafı kaydedilmedi.
                    </div>
                  )}
                </div>

                {/* Page Thumbnails & Filter Bar */}
                {activeArchive.sayfaFotolari && activeArchive.sayfaFotolari.length > 0 && (
                  <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-bold text-slate-400 mr-1">Sayfalar:</span>
                      {activeArchive.sayfaFotolari.map((img, i) => {
                        const pageNum = i + 1;
                        const pageQuestionsCount = (activeArchive.sorular || []).filter(
                          (q) => (q.sayfaNo || 1) === pageNum
                        ).length;

                        return (
                          <button
                            key={i}
                            onClick={() => {
                              setActivePageIndex(i);
                              setSelectedPageFilter(pageNum);
                              setZoom(1);
                              setPan({ x: 0, y: 0 });
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border flex items-center gap-1.5 ${
                              activePageIndex === i
                                ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            <span>Sayfa {pageNum}</span>
                            {pageQuestionsCount > 0 && (
                              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                                activePageIndex === i ? 'bg-indigo-500 text-white' : 'bg-slate-100 text-slate-600'
                              }`}>
                                {pageQuestionsCount} Soru
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {activeArchive.sayfaFotolari.length > 1 && (
                      <button
                        onClick={() => setSelectedPageFilter('all')}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all border whitespace-nowrap ${
                          selectedPageFilter === 'all'
                            ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                            : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        Tüm Soruları Göster ({activeArchive.sorular?.length || 0})
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Color-Coded Questions Table / Cards */}
              <div className="space-y-3 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Sınav Soruları & MEB Kazanım Eşleşmeleri
                    </h4>
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                      {displayedQuestions.length} Soru {selectedPageFilter !== 'all' ? `(Sayfa ${selectedPageFilter})` : ''}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    💡 Soruya tıklayarak ait olduğu sayfa fotoğrafına odaklanabilirsiniz
                  </span>
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                  {displayedQuestions.map((q, idx) => {
                    const isQuestionSelected = selectedQuestionNo === q.soruNo;
                    const questionPage = q.sayfaNo || (activePageIndex + 1);

                    return (
                      <div
                        key={idx}
                        onClick={() => handleSelectQuestion(q)}
                        className={`p-3.5 rounded-2xl border transition-all text-xs space-y-1.5 cursor-pointer hover:shadow-xs relative ${
                          isQuestionSelected
                            ? 'ring-2 ring-indigo-600 bg-indigo-50/70 border-indigo-300'
                            : q.dogruMu
                            ? 'bg-emerald-50/40 border-emerald-200/80 hover:bg-emerald-50/80'
                            : q.ogrenciCevabi === 'Boş'
                            ? 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                            : 'bg-rose-50/40 border-rose-200/80 hover:bg-rose-50/80'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="w-5 h-5 rounded-md bg-slate-900 text-white font-black text-[11px] flex items-center justify-center">
                              {q.soruNo}
                            </span>
                            <span className="font-bold text-slate-900">{q.ders}</span>
                            <span className="text-slate-400">•</span>
                            <span className="font-semibold text-slate-700">{q.konu}</span>
                            
                            {/* Page link badge */}
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1">
                              <Camera className="w-2.5 h-2.5 text-indigo-600" />
                              <span>Sayfa {questionPage}</span>
                            </span>

                            {q.kazanimKodu && (
                              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white text-indigo-700 border border-slate-200">
                                {q.kazanimKodu}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5">
                            {q.dogruMu ? (
                              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" /> Doğru
                              </span>
                            ) : q.ogrenciCevabi === 'Boş' ? (
                              <span className="text-[10px] font-bold text-slate-600 bg-slate-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                                <MinusCircle className="w-3 h-3" /> Boş
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                                <XCircle className="w-3 h-3" /> Yanlış
                              </span>
                            )}
                          </div>
                        </div>

                        {q.kazanimAciklama && (
                          <p className="text-[11px] text-slate-600 italic">
                            📌 {q.kazanimAciklama}
                          </p>
                        )}

                        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                          <span>
                            İşaretlenen: <strong className="text-slate-800">{q.ogrenciCevabi || 'Boş'}</strong> • Doğru: <strong className="text-emerald-700">{q.dogruCevap}</strong>
                          </span>
                          {q.analizNotu && (
                            <span className="text-slate-500 italic max-w-xs truncate" title={q.analizNotu}>
                              {q.analizNotu}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-3xl p-16 text-center text-slate-400 space-y-2">
              <Archive className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-xs font-semibold text-slate-600">Görüntülemek için soldan bir deneme seçin.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
