import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  HelpCircle, 
  CheckCircle2, 
  XCircle, 
  MinusCircle, 
  Trash2, 
  TrendingUp, 
  BookOpen 
} from 'lucide-react';
import { SoruTakipKaydi } from '../../../types';

interface QuestionsTabProps {
  questions: SoruTakipKaydi[];
  onAddQuestion: (q: Omit<SoruTakipKaydi, 'id'>) => void;
  onDeleteQuestion: (id: string) => void;
  studentName: string;
}

export const QuestionsTab: React.FC<QuestionsTabProps> = ({
  questions,
  onAddQuestion,
  onDeleteQuestion,
  studentName,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedDers, setSelectedDers] = useState<string>('Tümü');
  const [searchQuery, setSearchQuery] = useState('');

  // Form State
  const [tarih, setTarih] = useState(new Date().toISOString().split('T')[0]);
  const [ders, setDers] = useState('Matematik');
  const [konu, setKonu] = useState('');
  const [kaynakKitap, setKaynakKitap] = useState('');
  const [hedefSoru, setHedefSoru] = useState<number>(50);
  const [cozulenSoru, setCozulenSoru] = useState<number>(50);
  const [dogruSayisi, setDogruSayisi] = useState<number>(44);
  const [yanlisSayisi, setYanlisSayisi] = useState<number>(4);
  const [bosSayisi, setBosSayisi] = useState<number>(2);

  const calculatedNet = Math.max(0, Number(dogruSayisi) - Number(yanlisSayisi) * 0.25);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!konu.trim()) return;

    onAddQuestion({
      studentId: '',
      tarih,
      ders,
      konu: konu.trim(),
      kaynakKitap: kaynakKitap.trim() || 'Soru Bankası',
      hedefSoru: Number(hedefSoru) || 0,
      cozulenSoru: Number(cozulenSoru) || 0,
      dogruSayisi: Number(dogruSayisi) || 0,
      yanlisSayisi: Number(yanlisSayisi) || 0,
      bosSayisi: Number(bosSayisi) || 0,
      net: Number(calculatedNet.toFixed(2)),
    });

    setKonu('');
    setKaynakKitap('');
    setShowAddForm(false);
  };

  const filteredQuestions = questions.filter((q) => {
    const matchesDers = selectedDers === 'Tümü' || q.ders === selectedDers;
    const matchesSearch =
      q.konu.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.ders.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.kaynakKitap.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDers && matchesSearch;
  });

  const totalSolved = questions.reduce((acc, q) => acc + q.cozulenSoru, 0);
  const totalCorrect = questions.reduce((acc, q) => acc + q.dogruSayisi, 0);
  const totalWrong = questions.reduce((acc, q) => acc + q.yanlisSayisi, 0);
  const totalEmpty = questions.reduce((acc, q) => acc + q.bosSayisi, 0);
  const totalNet = questions.reduce((acc, q) => acc + q.net, 0);
  const accuracyRate = totalSolved > 0 ? Math.round((totalCorrect / totalSolved) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Question Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs">
          <div className="text-xs text-slate-400 font-semibold mb-1">Toplam Çözülen</div>
          <div className="text-2xl font-black text-slate-900">{totalSolved} <span className="text-xs font-normal text-slate-400">Soru</span></div>
          <div className="text-[11px] text-slate-500 mt-1">Haftalık soru kotası</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs">
          <div className="text-xs text-emerald-600 font-semibold mb-1 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Doğru & Net</span>
          </div>
          <div className="text-2xl font-black text-emerald-700">{totalCorrect} <span className="text-xs font-normal text-emerald-600">({totalNet.toFixed(1)} Net)</span></div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">%{accuracyRate} Doğruluk Oranı</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs">
          <div className="text-xs text-rose-600 font-semibold mb-1 flex items-center gap-1">
            <XCircle className="w-3.5 h-3.5" />
            <span>Yanlış Sayısı</span>
          </div>
          <div className="text-2xl font-black text-rose-700">{totalWrong} <span className="text-xs font-normal text-rose-400">Soru</span></div>
          <div className="text-[11px] text-slate-500 mt-1">Tekrar edilecek kazanımlar</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-3xl p-5 shadow-2xs">
          <div className="text-xs text-slate-500 font-semibold mb-1 flex items-center gap-1">
            <MinusCircle className="w-3.5 h-3.5" />
            <span>Boş Sayısı</span>
          </div>
          <div className="text-2xl font-black text-slate-700">{totalEmpty} <span className="text-xs font-normal text-slate-400">Soru</span></div>
          <div className="text-[11px] text-slate-500 mt-1">Konu eksiği analizleri</div>
        </div>
      </div>

      {/* Filter and Add Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Konu, ders veya kaynak kitap ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs focus:ring-2 focus:ring-indigo-500 shadow-2xs"
          />
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-all active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Soru Kaydı Ekle</span>
        </button>
      </div>

      {/* Lesson Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {['Tümü', 'Matematik', 'Geometri', 'Fizik', 'Kimya', 'Biyoloji', 'Türkçe', 'Tarih', 'Coğrafya'].map((d) => (
          <button
            key={d}
            onClick={() => setSelectedDers(d)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
              selectedDers === d
                ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {d}
          </button>
        ))}
      </div>

      {/* Add Question Form */}
      {showAddForm && (
        <div className="bg-white border-2 border-indigo-500/30 rounded-3xl p-6 sm:p-7 shadow-lg space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h4 className="text-sm font-bold text-slate-900">
              Yeni Günlük Soru Çözümü Kaydı
            </h4>
            <button
              onClick={() => setShowAddForm(false)}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              Kapat
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Tarih *</label>
                <input
                  type="date"
                  required
                  value={tarih}
                  onChange={(e) => setTarih(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Ders *</label>
                <select
                  value={ders}
                  onChange={(e) => setDers(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Matematik">Matematik</option>
                  <option value="Geometri">Geometri</option>
                  <option value="Türkçe">Türkçe</option>
                  <option value="Edebiyat">Edebiyat</option>
                  <option value="Fizik">Fizik</option>
                  <option value="Kimya">Kimya</option>
                  <option value="Biyoloji">Biyoloji</option>
                  <option value="Tarih">Tarih</option>
                  <option value="Coğrafya">Coğrafya</option>
                  <option value="Felsefe & Din">Felsefe & Din</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Konu Başlığı *</label>
                <input
                  type="text"
                  required
                  placeholder="Örn: Trigonometri Yarım Açı"
                  value={konu}
                  onChange={(e) => setKonu(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Kaynak Kitap</label>
                <input
                  type="text"
                  placeholder="Örn: 3D Soru Bankası"
                  value={kaynakKitap}
                  onChange={(e) => setKaynakKitap(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Numbers */}
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Hedef Soru</label>
                <input
                  type="number"
                  min="0"
                  value={hedefSoru}
                  onChange={(e) => setHedefSoru(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-center"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-800 mb-1">Çözülen</label>
                <input
                  type="number"
                  min="0"
                  value={cozulenSoru}
                  onChange={(e) => setCozulenSoru(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-100 border border-slate-300 rounded-xl text-xs font-black text-slate-900 text-center"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-emerald-700 mb-1">Doğru</label>
                <input
                  type="number"
                  min="0"
                  value={dogruSayisi}
                  onChange={(e) => setDogruSayisi(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-900 text-center"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-rose-700 mb-1">Yanlış</label>
                <input
                  type="number"
                  min="0"
                  value={yanlisSayisi}
                  onChange={(e) => setYanlisSayisi(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-900 text-center"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Boş</label>
                <input
                  type="number"
                  min="0"
                  value={bosSayisi}
                  onChange={(e) => setBosSayisi(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 text-center"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-indigo-700 mb-1">Net</label>
                <div className="px-3 py-2 bg-indigo-50 border border-indigo-200 rounded-xl text-xs font-black text-indigo-700 text-center">
                  {calculatedNet.toFixed(2)}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Vazgeç
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs"
              >
                Kaydet
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Questions Table */}
      <div className="bg-white border border-slate-200/90 rounded-3xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3 px-4">Tarih</th>
                <th className="py-3 px-4">Ders</th>
                <th className="py-3 px-4">Konu</th>
                <th className="py-3 px-4">Kaynak</th>
                <th className="py-3 px-3 text-center">Çözülen</th>
                <th className="py-3 px-3 text-center">D</th>
                <th className="py-3 px-3 text-center">Y</th>
                <th className="py-3 px-3 text-center">B</th>
                <th className="py-3 px-3 text-center">Net</th>
                <th className="py-3 px-4 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
              {filteredQuestions.length > 0 ? (
                filteredQuestions.map((q) => {
                  const rate = q.cozulenSoru > 0 ? Math.round((q.dogruSayisi / q.cozulenSoru) * 100) : 0;
                  return (
                    <tr key={q.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 text-slate-500 whitespace-nowrap">{q.tarih}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-900 whitespace-nowrap">{q.ders}</td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800">{q.konu}</td>
                      <td className="py-3.5 px-4 text-slate-500 text-[11px]">{q.kaynakKitap}</td>
                      <td className="py-3.5 px-3 text-center font-extrabold text-slate-900 whitespace-nowrap">{q.cozulenSoru}</td>
                      <td className="py-3.5 px-3 text-center text-emerald-700 font-bold whitespace-nowrap">{q.dogruSayisi}</td>
                      <td className="py-3.5 px-3 text-center text-rose-700 font-bold whitespace-nowrap">{q.yanlisSayisi}</td>
                      <td className="py-3.5 px-3 text-center text-slate-400 font-semibold whitespace-nowrap">{q.bosSayisi}</td>
                      <td className="py-3.5 px-3 text-center whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-black">
                          {q.net.toFixed(2)}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => onDeleteQuestion(q.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg transition-colors"
                          title="Kaydı Sil"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    Henüz soru çözümü kaydı bulunmuyor.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
