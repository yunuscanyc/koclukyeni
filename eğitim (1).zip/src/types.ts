export type SinifType = '9. Sınıf' | '10. Sınıf' | '11. Sınıf' | '12. Sınıf' | 'Mezun';
export type AlanType = 'Sayısal' | 'Eşit Ağırlık' | 'Sözel' | 'Dil' | 'Belirtilmemiş';
export type DurumType = 'Aktif' | 'Donduruldu' | 'Tamamlandı' | 'Pasif';

// 1. ÖĞRENCİ MODELİ
export interface Student {
  id: string;
  pinCode: string; // 6 haneli benzersiz öğrenci erişim PIN numarası
  adSoyad: string;
  dogumTarihi: string;
  kayitTarihi: string;
  sinif: SinifType;
  alan: AlanType;
  yksHedefYili: string;
  hedefUniversite: string;
  hedefBolum: string;
  hedefPuan: number | string;
  hedefSiralama: number | string;
  durum: DurumType;
  kocNotu: string;
  avatarBg?: string;
}

// Kimlik Doğrulama / PIN Rolleri
export type AuthRole = 'coach' | 'student';
export interface AuthSession {
  role: AuthRole;
  studentId?: string;
}

// 2. KOÇ NOTLARI
export type NoteKategori =
  | 'Haftalık Değerlendirme'
  | 'Hedef & Strateji'
  | 'Ödev & Görev'
  | 'Veli Görüşmesi'
  | 'Sınav Analizi'
  | 'Motivasyon & Rehberlik'
  | 'Genel';

export type NoteOncelik = 'Kritik' | 'Önemli' | 'Normal' | 'Düşük';

export interface CoachNote {
  id: string;
  studentId: string;
  tarih: string;
  kategori: NoteKategori;
  oncelik: NoteOncelik;
  baslik: string;
  icerik: string;
}

// 3. ÇALIŞMA PROGRAMI GÖREVLERİ
export type GorevTuru =
  | 'Soru Çözümü'
  | 'Konu Tekrarı'
  | 'Ders Çalışma'
  | 'Konu Çalışması'
  | 'Tekrar & Özet'
  | 'Branş Denemesi'
  | 'Genel Deneme'
  | 'Video İzleme';

export const isQuestionTaskType = (turu: string): boolean => {
  return (
    turu === 'Soru Çözümü' ||
    turu === 'Branş Denemesi' ||
    turu === 'Genel Deneme'
  );
};

export type GorevDurumu = 'Bekliyor' | 'Devam Ediyor' | 'Tamamlandı' | 'Eksik Kaldı';

export interface GorevProgrami {
  id: string;
  studentId: string;
  tarih: string;
  baslangicSaati: string; // "18:00"
  hedefSureDakika: number; // 60
  gorevTuru: GorevTuru;
  ders: string;
  konu: string;
  hedefSoruSayisi: number;
  hedefKazanim: string;
  kocAciklamasi: string;
  durum: GorevDurumu;
  ogrenciNotu?: string;
  updatedAt?: number;
}

// 4. GÜNLÜK SORU TAKİBİ
export interface SoruTakipKaydi {
  id: string;
  studentId: string;
  tarih: string;
  ders: string;
  konu: string;
  kaynakKitap: string;
  hedefSoru: number;
  cozulenSoru: number;
  dogruSayisi: number;
  yanlisSayisi: number;
  bosSayisi: number;
  net: number;
}

// 5. DENEMELER (TYT / AYT)
export interface DersNetDetay {
  dersAdi: string;
  dogru: number;
  yanlis: number;
  bos: number;
  net: number;
}

export interface DenemeSinavi {
  id: string;
  studentId: string;
  ogrenciAdSoyad?: string;
  sinavTuru: 'TYT' | 'AYT';
  denemeAdi: string;
  yayin: string;
  tarih: string;
  toplamNet: number;
  puan?: number | null;
  siralama?: number | null;
  toplamKatilimci?: number | null;
  kocYorumu?: string | null;
  dersler: DersNetDetay[];
}

// 6. MEB MÜFREDAT KAZANIMLARI
export type KazanimOnem = 'Kritik' | 'Yüksek' | 'Orta' | 'Temel';

export interface Kazanim {
  id: string;
  sinif?: SinifType | string;
  sinavTuru: 'TYT' | 'AYT' | 'TÜMÜ';
  ders: string;
  konu: string;
  kazanimKodu: string;
  aciklama: string;
  onemDerecesi: KazanimOnem;
  yil: string;
}

// 7. FOTOĞRAFLI SINAV & KAZANIM ANALİZİ
export type SinavSorusu = SoruAnalizDetay;

export interface SoruAnalizDetay {
  soruNo: number;
  sayfaNo?: number;
  ders: string;
  konu: string;
  isaretlenenSik?: string; // "A", "B", "C", "D", "E", "Boş"
  ogrenciCevabi?: string;
  dogruCevap: string;     // "A", "B", "C", "D", "E"
  dogruMu: boolean;
  kazanimKodu?: string;
  kazanimAciklama?: string;
  soruOzeti?: string;
  analizNotu?: string;
  sayfaFotoUrl?: string;
  soruFotografYolu?: string; // base64 or photo URL
}

export type AIProcessingStatus = 'pending' | 'processing' | 'completed' | 'rate_limited' | 'error';

export interface OgrenciSinavKaydi {
  id: string;
  studentId: string;
  ogrenciAdSoyad?: string;
  sinavTuru: 'TYT' | 'AYT';
  sinavAdi: string;
  tarih: string;
  toplamSoru: number;
  dogruSayisi: number;
  yanlisSayisi: number;
  bosSayisi: number;
  net?: number;
  toplamNet: number;
  sorular: SoruAnalizDetay[];
  fotografYollari?: string[];
  sayfaFotolari?: string[];
  isNew?: boolean; // Koç ekranında "YENİ" uyarısı için
  ogrenciYukledi?: boolean; // Öğrenci portalından yüklendiğini belirtir
  yuklemeZamani?: string; // "12.09.2026 14:30" gibi detaylı yükleme zamanı
  durum?: 'Yeni' | 'İncelendi' | 'Değerlendirildi';
  aiStatus?: AIProcessingStatus; // 'completed' | 'processing' | 'rate_limited' | 'pending' | 'error'
  aiStatusMessage?: string; // e.g. "Yapay zekâ çözdü", "Devam ediyor", "Kota sıfırlanması bekleniyor..."
  ogrenciNotu?: string; // Öğrencinin testle ilgili koça yazdığı not
  kocGeriBildirimi?: string; // Koçun bu teste özel geri bildirimi
}

// Aliases for WinForms simulator or other legacy references
export type ExamRecord = DenemeSinavi;
export type DailyStudy = GorevProgrami;
export type QuestionEntry = SoruTakipKaydi;
export type OutcomeItem = Kazanim;

// Kazanım İstatistik Modeli (Raporlar için)
export interface KazanimIstatistik {
  kazanimKodu: string;
  kazanimAciklama: string;
  ders: string;
  konu: string;
  toplamSoru: number;
  dogruSayisi: number;
  yanlisSayisi: number;
  bosSayisi: number;
  basariYuzdesi: number;
}

// Tab navigation keys
export type StudentProfileTab =
  | 'genel'
  | 'koc-notlari'
  | 'calisma-programi'
  | 'soru-takibi'
  | 'denemeler'
  | 'kazanimlar'
  | 'raporlar'
  | 'sinav-analiz'
  | 'sinav-gecmisi';

export type MainViewMode = 'students' | 'student-detail' | 'analytics' | 'ai-coach' | 'curriculum' | 'winforms-simulator';
