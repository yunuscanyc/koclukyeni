import React, { useState, useEffect } from 'react';
import { CoachingHeader } from './components/coaching/CoachingHeader';
import { StudentListView } from './components/coaching/StudentListView';
import { StudentProfileView } from './components/coaching/StudentProfileView';

// 9 Tabs
import { GeneralInfoTab } from './components/coaching/tabs/GeneralInfoTab';
import { CoachNotesTab } from './components/coaching/tabs/CoachNotesTab';
import { DailyStudiesTab } from './components/coaching/tabs/DailyStudiesTab';
import { QuestionsTab } from './components/coaching/tabs/QuestionsTab';
import { ExamsTab } from './components/coaching/tabs/ExamsTab';
import { OutcomesTab } from './components/coaching/tabs/OutcomesTab';
import { GlobalCurriculumView } from './components/coaching/GlobalCurriculumView';
import { ReportsTab } from './components/coaching/tabs/ReportsTab';
import { ExamAnalysisTab } from './components/coaching/tabs/ExamAnalysisTab';
import { ExamHistoryTab } from './components/coaching/tabs/ExamHistoryTab';

// Modals
import { AddStudentModal } from './components/modals/AddStudentModal';
import { AICoachAskModal } from './components/modals/AICoachAskModal';

// Authentication & Student Portal
import { PinScreen } from './components/auth/PinScreen';
import { StudentPortalView } from './components/portal/StudentPortalView';
import { DEFAULT_COACH_PIN, ensureAllStudentsHavePins, generateRandom6DigitPin } from './utils/pinUtils';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';

// Seed Data & Types
import { 
  INITIAL_STUDENTS, 
  INITIAL_COACH_NOTES, 
  INITIAL_TASKS, 
  INITIAL_QUESTION_TRACKS, 
  INITIAL_EXAMS, 
  INITIAL_CURRICULUM,
  INITIAL_EXAM_ARCHIVES
} from './data/coachingSeedData';

import { 
  Student, 
  CoachNote, 
  GorevProgrami, 
  SoruTakipKaydi, 
  DenemeSinavi, 
  Kazanim, 
  OgrenciSinavKaydi,
  StudentProfileTab,
  MainViewMode,
  AuthSession
} from './types';

import {
  seedDatabaseIfEmpty,
  getStudents,
  saveStudent,
  deleteStudent,
  getCoachNotes,
  saveCoachNote,
  deleteCoachNote,
  getTasks,
  saveTask,
  deleteTask,
  getQuestions,
  saveQuestion,
  deleteQuestion,
  getExams,
  saveExam,
  deleteExam,
  getCurriculum,
  saveCurriculumItem,
  deleteCurriculumItem,
  bulkReplaceCurriculumInFirestore,
  bulkAppendCurriculumToFirestore,
  getExamArchives,
  saveExamArchive,
  deleteExamArchive
} from './lib/firebaseService';

export default function App() {
  // Navigation State
  const [viewMode, setViewMode] = useState<MainViewMode>('students');
  const [activeTab, setActiveTab] = useState<StudentProfileTab>('genel');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Authentication State
  const [authSession, setAuthSession] = useState<AuthSession | null>(() => {
    try {
      const saved = localStorage.getItem('yks_kocluk_auth_session_v1');
      if (saved) return JSON.parse(saved);
    } catch {}
    return null; // Sayfa açıldığında doğrudan PIN kodu ekranı karşılar
  });
  const [coachPin] = useState<string>(DEFAULT_COACH_PIN);

  useEffect(() => {
    try {
      if (authSession) {
        localStorage.setItem('yks_kocluk_auth_session_v1', JSON.stringify(authSession));
      } else {
        localStorage.removeItem('yks_kocluk_auth_session_v1');
      }
    } catch {}
  }, [authSession]);

  // Modals
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [isAiAskOpen, setIsAiAskOpen] = useState(false);

  // Core Data States loaded from Cloud Firestore
  const [students, setStudents] = useState<Student[]>(() => ensureAllStudentsHavePins(INITIAL_STUDENTS));
  const [activeStudentId, setActiveStudentId] = useState<string>(() => INITIAL_STUDENTS[0]?.id || '');
  const [notes, setNotes] = useState<CoachNote[]>(INITIAL_COACH_NOTES);
  const [tasks, setTasks] = useState<GorevProgrami[]>(INITIAL_TASKS);
  const [questions, setQuestions] = useState<SoruTakipKaydi[]>(INITIAL_QUESTION_TRACKS);
  const [exams, setExams] = useState<DenemeSinavi[]>(INITIAL_EXAMS);
  const [curriculum, setCurriculum] = useState<Kazanim[]>(INITIAL_CURRICULUM);
  const [examArchives, setExamArchives] = useState<OgrenciSinavKaydi[]>(INITIAL_EXAM_ARCHIVES);

  // Background sync with Firestore
  useEffect(() => {
    let isMounted = true;
    async function initFirestoreData() {
      try {
        await seedDatabaseIfEmpty();

        const [
          dbStudents,
          dbNotes,
          dbTasks,
          dbQuestions,
          dbExams,
          dbCurriculum,
          dbArchives
        ] = await Promise.all([
          getStudents(),
          getCoachNotes(),
          getTasks(),
          getQuestions(),
          getExams(),
          getCurriculum(),
          getExamArchives()
        ]);

        if (!isMounted) return;

        // 1. Sync Students
        let serverStudents: Student[] = [];
        try {
          const sRes = await fetch('/api/students');
          if (sRes.ok) serverStudents = await sRes.json();
        } catch {}

        const studentMap = new Map<string, Student>();
        if (dbStudents && dbStudents.length > 0) dbStudents.forEach((s) => studentMap.set(s.id, s));
        if (serverStudents && serverStudents.length > 0) serverStudents.forEach((s) => studentMap.set(s.id, s));
        
        const mergedStudents = Array.from(studentMap.values());
        if (mergedStudents.length > 0) {
          const validatedStudents = ensureAllStudentsHavePins(mergedStudents);
          setStudents(validatedStudents);
          if (!activeStudentId || !validatedStudents.some((s) => s.id === activeStudentId)) {
            setActiveStudentId(validatedStudents[0].id);
          }
        }

        // 2. Sync Notes
        let serverNotes: CoachNote[] = [];
        try {
          const sRes = await fetch('/api/notes');
          if (sRes.ok) serverNotes = await sRes.json();
        } catch {}

        const notesMap = new Map<string, CoachNote>();
        INITIAL_COACH_NOTES.forEach((n) => notesMap.set(n.id, n));
        if (dbNotes && dbNotes.length > 0) dbNotes.forEach((n) => notesMap.set(n.id, n));
        if (serverNotes && serverNotes.length > 0) serverNotes.forEach((n) => notesMap.set(n.id, n));
        setNotes(Array.from(notesMap.values()));
        
        // 3. Sync Tasks (Görevler)
        let serverTasks: GorevProgrami[] = [];
        try {
          const sRes = await fetch('/api/tasks');
          if (sRes.ok) serverTasks = await sRes.json();
        } catch {}

        const taskMap = new Map<string, GorevProgrami>();
        INITIAL_TASKS.forEach((t) => taskMap.set(t.id, t));
        if (serverTasks && serverTasks.length > 0) serverTasks.forEach((t) => taskMap.set(t.id, t));
        if (dbTasks && dbTasks.length > 0) {
          dbTasks.forEach((t) => {
            const existing = taskMap.get(t.id);
            if (!existing) {
              taskMap.set(t.id, t);
            } else {
              const eTime = existing.updatedAt || 0;
              const dTime = t.updatedAt || 0;
              taskMap.set(t.id, dTime >= eTime ? t : existing);
            }
          });
        }
        setTasks(Array.from(taskMap.values()));

        // 4. Sync Questions
        let serverQuestions: SoruTakipKaydi[] = [];
        try {
          const sRes = await fetch('/api/questions');
          if (sRes.ok) serverQuestions = await sRes.json();
        } catch {}

        const questionMap = new Map<string, SoruTakipKaydi>();
        INITIAL_QUESTION_TRACKS.forEach((q) => questionMap.set(q.id, q));
        if (dbQuestions && dbQuestions.length > 0) dbQuestions.forEach((q) => questionMap.set(q.id, q));
        if (serverQuestions && serverQuestions.length > 0) serverQuestions.forEach((q) => questionMap.set(q.id, q));
        setQuestions(Array.from(questionMap.values()));

        // 5. Sync Exams (Deneme Sınavları)
        let serverExams: DenemeSinavi[] = [];
        try {
          const sRes = await fetch('/api/exams');
          if (sRes.ok) serverExams = await sRes.json();
        } catch {}

        const examMap = new Map<string, DenemeSinavi>();
        INITIAL_EXAMS.forEach((e) => examMap.set(e.id, e));
        if (dbExams && dbExams.length > 0) dbExams.forEach((e) => examMap.set(e.id, e));
        if (serverExams && serverExams.length > 0) serverExams.forEach((e) => examMap.set(e.id, e));
        setExams(Array.from(examMap.values()));

        // 6. Sync Curriculum (Kazanımlar)
        let serverCurriculum: Kazanim[] = [];
        try {
          const sRes = await fetch('/api/curriculum');
          if (sRes.ok) serverCurriculum = await sRes.json();
        } catch {}

        const curriculumMap = new Map<string, Kazanim>();
        INITIAL_CURRICULUM.forEach((c) => curriculumMap.set(c.id, c));
        if (dbCurriculum && dbCurriculum.length > 0) dbCurriculum.forEach((c) => curriculumMap.set(c.id, c));
        if (serverCurriculum && serverCurriculum.length > 0) serverCurriculum.forEach((c) => curriculumMap.set(c.id, c));
        setCurriculum(Array.from(curriculumMap.values()));

        // 7. Sync Archives (Sınav Fotoğrafları ve Optik Çözümler)
        let serverArchives: OgrenciSinavKaydi[] = [];
        try {
          const sRes = await fetch('/api/archives');
          if (sRes.ok) serverArchives = await sRes.json();
        } catch {}

        // Purge arch-1 from Firestore if present
        if (dbArchives && dbArchives.some((a) => a.id === 'arch-1' || a.sinavAdi?.includes('TYT Matematik & Geometri Sayfa Taraması'))) {
          deleteExamArchive('arch-1').catch(() => {});
        }

        // Purge arch-1 from server database if present
        if (serverArchives && serverArchives.some((a) => a.id === 'arch-1' || a.sinavAdi?.includes('TYT Matematik & Geometri Sayfa Taraması'))) {
          fetch('/api/archives/arch-1', { method: 'DELETE' }).catch(() => {});
        }

        const archiveMap = new Map<string, OgrenciSinavKaydi>();
        INITIAL_EXAM_ARCHIVES.forEach((a) => archiveMap.set(a.id, a));
        if (dbArchives && dbArchives.length > 0) {
          dbArchives.forEach((a) => {
            if (a.id !== 'arch-1' && !a.sinavAdi?.includes('TYT Matematik & Geometri Sayfa Taraması')) {
              archiveMap.set(a.id, a);
            }
          });
        }
        if (serverArchives && serverArchives.length > 0) {
          serverArchives.forEach((a) => {
            if (a.id !== 'arch-1' && !a.sinavAdi?.includes('TYT Matematik & Geometri Sayfa Taraması')) {
              archiveMap.set(a.id, a);
            }
          });
        }

        archiveMap.delete('arch-1');
        const finalArchives = Array.from(archiveMap.values()).filter(
          (a) => a.id !== 'arch-1' && !a.sinavAdi?.includes('TYT Matematik & Geometri Sayfa Taraması')
        );
        setExamArchives(finalArchives);
      } catch (error) {
        console.warn("Firestore background sync note:", error);
      }
    }
    initFirestoreData();
    return () => {
      isMounted = false;
    };
  }, []);

  // Periodic polling for active background AI jobs and real-time syncing of tasks, exams, notes, and questions
  useEffect(() => {
    const hasActiveJobs = examArchives.some(
      (a) => a.aiStatus === 'processing' || a.aiStatus === 'rate_limited' || a.aiStatus === 'pending'
    );

    // Poll every 3 seconds if jobs are running, or every 10 seconds otherwise
    const pollInterval = hasActiveJobs ? 3000 : 10000;

    const timer = setInterval(async () => {
      try {
        // 1. Sync Exam Archives (AI optical sheets)
        let serverArchives: OgrenciSinavKaydi[] = [];
        try {
          const res = await fetch('/api/archives');
          if (res.ok) serverArchives = await res.json();
        } catch {}

        let fsArchives: OgrenciSinavKaydi[] = [];
        try {
          fsArchives = await getExamArchives();
        } catch {}

        if (serverArchives.length > 0 || fsArchives.length > 0) {
          // Sync completed AI archives from server to Firestore if Firestore doesn't have completed version yet
          serverArchives.forEach((sa) => {
            if (sa.aiStatus === 'completed' && sa.sorular && sa.sorular.length > 0) {
              const fsMatch = fsArchives.find((x) => x.id === sa.id);
              if (!fsMatch || fsMatch.aiStatus !== 'completed' || !fsMatch.sorular || fsMatch.sorular.length === 0) {
                saveExamArchive(sa).catch((e) => console.warn('Background sync archive to Firestore error:', e));
              }
            }
          });

          setExamArchives((prev) => {
            const map = new Map<string, OgrenciSinavKaydi>();

            const applyToMap = (a: OgrenciSinavKaydi) => {
              if (!a || !a.id || a.id === 'arch-1' || a.sinavAdi?.includes('TYT Matematik & Geometri Sayfa Taraması')) return;
              const existing = map.get(a.id);
              if (!existing) {
                const hasQ = Array.isArray(a.sorular) && a.sorular.length > 0;
                const isDone = a.aiStatus === 'completed' || (hasQ && a.aiStatus !== 'rate_limited');
                map.set(a.id, {
                  ...a,
                  aiStatus: isDone ? 'completed' : (a.aiStatus || 'processing'),
                  aiStatusMessage: isDone ? 'Yapay zekâ çözdü' : (a.aiStatusMessage || 'Devam ediyor'),
                });
                return;
              }

              const currentQCount = existing.sorular?.length || 0;
              const incomingQCount = a.sorular?.length || 0;

              const isCurrentCompleted = existing.aiStatus === 'completed' || currentQCount > 0;
              const isIncomingCompleted = a.aiStatus === 'completed' || incomingQCount > 0;

              let merged: OgrenciSinavKaydi;
              if (incomingQCount > currentQCount) {
                merged = { ...existing, ...a };
              } else if (currentQCount > incomingQCount) {
                merged = { ...a, ...existing };
              } else if (isIncomingCompleted && !isCurrentCompleted) {
                merged = { ...existing, ...a };
              } else if (isCurrentCompleted && !isIncomingCompleted) {
                merged = { ...a, ...existing };
              } else {
                merged = { ...existing, ...a };
              }

              // Retain photo arrays if present in either source
              const existingPhotos = existing.sayfaFotolari || existing.fotografYollari || [];
              const incomingPhotos = a.sayfaFotolari || a.fotografYollari || [];
              const finalPhotos = incomingPhotos.length > 0 ? incomingPhotos : existingPhotos;
              merged.sayfaFotolari = finalPhotos;
              merged.fotografYollari = finalPhotos;

              // Ensure completed status if questions exist
              const totalQ = merged.sorular?.length || 0;
              if (totalQ > 0 && merged.aiStatus !== 'rate_limited') {
                merged.aiStatus = 'completed';
                merged.aiStatusMessage = 'Yapay zekâ çözdü';
              }

              map.set(a.id, merged);
            };

            prev.forEach(applyToMap);
            fsArchives.forEach(applyToMap);
            serverArchives.forEach(applyToMap);

            return Array.from(map.values());
          });
        }

        // 2. Sync Study Tasks (Görev ve Çalışma Programları)
        let fsTasks: GorevProgrami[] = [];
        try {
          fsTasks = await getTasks();
        } catch {}

        let serverTasks: GorevProgrami[] = [];
        try {
          const tRes = await fetch('/api/tasks');
          if (tRes.ok) serverTasks = await tRes.json();
        } catch {}

        if (fsTasks.length > 0 || serverTasks.length > 0) {
          setTasks((prev) => {
            const map = new Map<string, GorevProgrami>();
            serverTasks.forEach((t) => map.set(t.id, t));
            fsTasks.forEach((t) => {
              const current = map.get(t.id);
              if (!current) {
                map.set(t.id, t);
              } else {
                const cTime = current.updatedAt || 0;
                const fTime = t.updatedAt || 0;
                map.set(t.id, fTime >= cTime ? t : current);
              }
            });

            prev.forEach((localTask) => {
              const remote = map.get(localTask.id);
              if (!remote) {
                map.set(localTask.id, localTask);
              } else {
                const localTime = localTask.updatedAt || 0;
                const remoteTime = remote.updatedAt || 0;
                if (localTime >= remoteTime) {
                  // Keep local task state if local is newer or equal
                  map.set(localTask.id, localTask);
                } else {
                  map.set(localTask.id, remote);
                }
              }
            });
            return Array.from(map.values());
          });
        }

        // 3. Sync Exams (Deneme Sınav Sonuçları)
        let fsExams: DenemeSinavi[] = [];
        try {
          fsExams = await getExams();
        } catch {}
        if (fsExams.length > 0) {
          setExams((prev) => {
            const map = new Map<string, DenemeSinavi>();
            prev.forEach((e) => map.set(e.id, e));
            fsExams.forEach((e) => map.set(e.id, e));
            return Array.from(map.values());
          });
        }

        // 4. Sync Coach Notes (Koç Notları)
        let fsNotes: CoachNote[] = [];
        try {
          fsNotes = await getCoachNotes();
        } catch {}
        if (fsNotes.length > 0) {
          setNotes((prev) => {
            const map = new Map<string, CoachNote>();
            prev.forEach((n) => map.set(n.id, n));
            fsNotes.forEach((n) => map.set(n.id, n));
            return Array.from(map.values());
          });
        }

        // 5. Sync Questions (Soru Takibi)
        let fsQuestions: SoruTakipKaydi[] = [];
        try {
          fsQuestions = await getQuestions();
        } catch {}
        if (fsQuestions.length > 0) {
          setQuestions((prev) => {
            const map = new Map<string, SoruTakipKaydi>();
            prev.forEach((q) => map.set(q.id, q));
            fsQuestions.forEach((q) => map.set(q.id, q));
            return Array.from(map.values());
          });
        }
      } catch (e) {
        // Silently ignore polling errors in background
      }
    }, pollInterval);

    return () => clearInterval(timer);
  }, [examArchives]);

  const activeStudent = students.find((s) => s.id === activeStudentId) || students[0] || null;

  // Student Actions
  const handleSelectStudent = (id: string) => {
    setActiveStudentId(id);
    setViewMode('student-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddStudent = async (newStd: Omit<Student, 'id'>) => {
    const existingPins = students.map((s) => s.pinCode);
    const pin = newStd.pinCode || generateRandom6DigitPin(existingPins);
    const studentWithId: Student = {
      ...newStd,
      pinCode: pin,
      id: `std-${Date.now()}`,
    };
    setStudents((prev) => [studentWithId, ...prev]);
    setActiveStudentId(studentWithId.id);
    setViewMode('student-detail');
    setActiveTab('genel');
    try {
      await saveStudent(studentWithId);
    } catch (e) {
      console.warn('Firestore saveStudent note:', e);
    }
    try {
      await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studentWithId),
      });
    } catch (e) {
      console.warn('Backend /api/students error:', e);
    }
  };

  const handleUpdateStudent = async (updated: Student) => {
    setStudents((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
    try {
      await saveStudent(updated);
    } catch (e) {
      console.warn('Firestore saveStudent note:', e);
    }
    try {
      await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
    } catch (e) {
      console.warn('Backend /api/students error:', e);
    }
  };

  const handleDeleteStudent = async (id: string) => {
    if (confirm('Öğrenciyi silmek istediğinize emin misiniz?')) {
      setStudents((prev) => prev.filter((s) => s.id !== id));
      if (activeStudentId === id) {
        const remaining = students.filter((s) => s.id !== id);
        if (remaining[0]) setActiveStudentId(remaining[0].id);
        else setViewMode('students');
      }
      try {
        await deleteStudent(id);
      } catch (e) {
        console.warn('Firestore deleteStudent note:', e);
      }
      try {
        await fetch(`/api/students/${id}`, { method: 'DELETE' });
      } catch (e) {
        console.warn('Backend /api/students delete error:', e);
      }
    }
  };

  // Sub-record actions for Active Student
  const studentNotes = notes.filter((n) => !n.studentId || n.studentId === activeStudent?.id);
  const handleAddNote = async (note: Omit<CoachNote, 'id'>) => {
    const newNote: CoachNote = {
      ...note,
      id: `note-${Date.now()}`,
      studentId: activeStudent?.id || '',
    };
    setNotes((prev) => [newNote, ...prev]);
    try {
      await saveCoachNote(newNote);
    } catch (e) {
      console.warn('Firestore saveCoachNote note:', e);
    }
    try {
      await fetch('/api/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newNote),
      });
    } catch (e) {
      console.warn('Backend /api/notes error:', e);
    }
  };
  const handleDeleteNote = async (id: string) => {
    if (confirm('Bu koç notunu silmek istediğinize emin misiniz?')) {
      setNotes((prev) => prev.filter((n) => n.id !== id));
      try {
        await deleteCoachNote(id);
      } catch (e) {
        console.warn('Firestore deleteCoachNote note:', e);
      }
      try {
        await fetch(`/api/notes/${id}`, { method: 'DELETE' });
      } catch (e) {
        console.warn('Backend /api/notes delete error:', e);
      }
    }
  };

  const currentActiveStudentId = activeStudent?.id || students[0]?.id || 'std-1';
  const studentTasks = tasks.filter((t) => !t.studentId || t.studentId === currentActiveStudentId);
  const handleAddTask = async (task: Omit<GorevProgrami, 'id'>) => {
    const newTask: GorevProgrami = {
      ...task,
      id: `task-${Date.now()}`,
      studentId: task.studentId || currentActiveStudentId,
    };
    setTasks((prev) => [newTask, ...prev]);

    // Background dual sync
    try {
      await saveTask(newTask);
    } catch (e) {
      console.warn('Firestore saveTask note:', e);
    }
    try {
      await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTask),
      });
    } catch (e) {
      console.warn('Backend /api/tasks error:', e);
    }
  };
  const handleToggleTask = async (id: string, ogrenciNotu?: string) => {
    const isStatusToggle = ogrenciNotu === undefined;
    const now = Date.now();

    let targetTask: GorevProgrami | null = null;
    const existingTask = tasks.find((t) => t.id === id);
    if (existingTask) {
      targetTask = {
        ...existingTask,
        durum: isStatusToggle
          ? (existingTask.durum === 'Tamamlandı' ? 'Devam Ediyor' : 'Tamamlandı')
          : existingTask.durum,
        ogrenciNotu: ogrenciNotu !== undefined ? ogrenciNotu : existingTask.ogrenciNotu,
        updatedAt: now,
      };
    }

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const updated: GorevProgrami = {
            ...t,
            durum: isStatusToggle
              ? (t.durum === 'Tamamlandı' ? 'Devam Ediyor' : 'Tamamlandı')
              : t.durum,
            ogrenciNotu: ogrenciNotu !== undefined ? ogrenciNotu : t.ogrenciNotu,
            updatedAt: now,
          };
          targetTask = updated;
          return updated;
        }
        return t;
      })
    );

    if (targetTask) {
      const taskToSave: GorevProgrami = targetTask;
      try {
        await saveTask(taskToSave);
      } catch (e) {
        console.warn('Firestore saveTask note:', e);
      }
      try {
        await fetch('/api/tasks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(taskToSave),
        });
      } catch (e) {
        console.warn('Backend /api/tasks error:', e);
      }
    }
  };
  const handleDeleteTask = async (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    try {
      await deleteTask(id);
    } catch (e) {
      console.warn('Firestore deleteTask note:', e);
    }
    try {
      await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('Backend /api/tasks delete error:', e);
    }
  };

  const studentQuestions = questions.filter((q) => !q.studentId || q.studentId === activeStudent?.id);
  const handleAddQuestion = async (q: Omit<SoruTakipKaydi, 'id'>) => {
    const newQ: SoruTakipKaydi = {
      ...q,
      id: `q-${Date.now()}`,
      studentId: activeStudent?.id || '',
    };
    setQuestions((prev) => [newQ, ...prev]);
    try {
      await saveQuestion(newQ);
    } catch (e) {
      console.warn('Firestore saveQuestion note:', e);
    }
    try {
      await fetch('/api/questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newQ),
      });
    } catch (e) {
      console.warn('Backend /api/questions error:', e);
    }
  };
  const handleDeleteQuestion = async (id: string) => {
    if (confirm('Bu soru takip kaydını silmek istediğinize emin misiniz?')) {
      setQuestions((prev) => prev.filter((q) => q.id !== id));
      try {
        await deleteQuestion(id);
      } catch (e) {
        console.warn('Firestore deleteQuestion note:', e);
      }
      try {
        await fetch(`/api/questions/${id}`, { method: 'DELETE' });
      } catch (e) {
        console.warn('Backend /api/questions delete error:', e);
      }
    }
  };

  const studentExams = exams.filter((e) => !e.studentId || e.studentId === activeStudent?.id);
  const handleAddExam = async (exam: Omit<DenemeSinavi, 'id'>) => {
    const newExam: DenemeSinavi = {
      ...exam,
      id: `exam-${Date.now()}`,
      studentId: activeStudent?.id || '',
    };
    setExams((prev) => [newExam, ...prev]);
    try {
      await saveExam(newExam);
    } catch (e) {
      console.warn('Firestore saveExam note:', e);
    }
    try {
      await fetch('/api/exams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newExam),
      });
    } catch (e) {
      console.warn('Backend /api/exams error:', e);
    }
  };
  const handleDeleteExam = async (id: string) => {
    if (confirm('Bu deneme sınavını silmek istediğinize emin misiniz?')) {
      setExams((prev) => prev.filter((e) => e.id !== id));
      try {
        await deleteExam(id);
      } catch (e) {
        console.warn('Firestore deleteExam note:', e);
      }
      try {
        await fetch(`/api/exams/${id}`, { method: 'DELETE' });
      } catch (e) {
        console.warn('Backend /api/exams delete error:', e);
      }
    }
  };

  // Curriculum actions
  const handleAddKazanim = async (k: Omit<Kazanim, 'id'>) => {
    const newK: Kazanim = {
      ...k,
      id: `kaz-${Date.now()}`,
    };
    setCurriculum((prev) => [newK, ...prev]);
    try {
      await saveCurriculumItem(newK);
    } catch (e) {
      console.warn('Firestore saveCurriculumItem note:', e);
    }
    try {
      await fetch('/api/curriculum/item', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newK),
      });
    } catch (e) {
      console.warn('Backend /api/curriculum error:', e);
    }
  };

  const handleUpdateKazanim = async (updatedItem: Kazanim) => {
    setCurriculum((prev) =>
      prev.map((k) => (k.id === updatedItem.id ? updatedItem : k))
    );
    try {
      await saveCurriculumItem(updatedItem);
    } catch (e) {
      console.warn('Firestore saveCurriculumItem note:', e);
    }
    try {
      await fetch('/api/curriculum/item', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedItem),
      });
    } catch (e) {
      console.warn('Backend /api/curriculum error:', e);
    }
  };
  const handleBulkAddKazanimlar = async (newItems: Kazanim[], replaceAll: boolean = true) => {
    if (!newItems || newItems.length === 0) return;

    // 1. Immediately update React UI so 1000+ items appear instantaneously
    if (replaceAll) {
      setCurriculum(newItems);
    } else {
      setCurriculum((prev) => {
        const incomingIds = new Set(newItems.map((n) => n.id));
        const filteredPrev = prev.filter((p) => !incomingIds.has(p.id));
        return [...newItems, ...filteredPrev];
      });
    }

    // 2. Fast single-request backend bulk update (replaces in memory and Postgres in milliseconds)
    try {
      await fetch('/api/curriculum/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: newItems, replaceAll }),
      });
    } catch (e) {
      console.warn('Backend /api/curriculum/bulk error:', e);
    }

    // 3. Sync to Firestore in background using batched writes
    try {
      if (replaceAll) {
        await bulkReplaceCurriculumInFirestore(newItems);
      } else {
        await bulkAppendCurriculumToFirestore(newItems);
      }
    } catch (e) {
      console.warn('Firestore bulkReplaceCurriculum note:', e);
    }
  };

  const handleClearAllCurriculum = async () => {
    setCurriculum([]);
    try {
      await fetch('/api/curriculum/all', { method: 'DELETE' });
    } catch (e) {
      console.warn('Backend /api/curriculum/all error:', e);
    }
    try {
      await bulkReplaceCurriculumInFirestore([]);
    } catch (e) {
      console.warn('Firestore clear all note:', e);
    }
  };
  const handleDeleteKazanim = async (id: string) => {
    if (confirm('Bu kazanımı silmek istediğinize emin misiniz?')) {
      setCurriculum((prev) => prev.filter((k) => k.id !== id));
      try {
        await deleteCurriculumItem(id);
      } catch (e) {
        console.warn('Firestore deleteCurriculumItem note:', e);
      }
      try {
        await fetch(`/api/curriculum/${id}`, { method: 'DELETE' });
      } catch (e) {
        console.warn('Backend /api/curriculum delete error:', e);
      }
    }
  };

  // Photo Exam Archive actions
  const studentArchives = examArchives.filter((a) => !a.studentId || a.studentId === activeStudent?.id);
  const handleSaveExamArchive = async (archive: OgrenciSinavKaydi, newDeneme?: Omit<DenemeSinavi, 'id'>) => {
    setExamArchives((prev) => {
      const exists = prev.some((a) => a.id === archive.id);
      if (exists) {
        return prev.map((a) => (a.id === archive.id ? archive : a));
      }
      return [archive, ...prev];
    });

    // 1. Save to Firestore
    try {
      await saveExamArchive(archive);
    } catch (e) {
      console.warn("Firestore saveExamArchive warning:", e);
    }

    // 2. Also save to Express /api/archives to keep backend memory/postgres synced
    try {
      await fetch('/api/archives', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(archive),
      });
    } catch (e) {
      console.warn("Backend /api/archives sync warning:", e);
    }

    if (newDeneme) {
      await handleAddExam(newDeneme);
    }
  };
  const handleDeleteArchive = async (id: string) => {
    if (confirm('Bu sınav arşiv kaydını ve fotoğrafını silmek istediğinize emin misiniz?')) {
      setExamArchives((prev) => prev.filter((a) => a.id !== id));
      try {
        await deleteExamArchive(id);
      } catch (e) {
        console.warn('Firestore deleteExamArchive note:', e);
      }
      try {
        await fetch(`/api/archives/${id}`, { method: 'DELETE' });
      } catch (e) {
        console.warn('Backend /api/archives delete error:', e);
      }
    }
  };

  // 1. PIN Kodu Giriş Ekranı (Sayfa açıldığında karşılayan ekran)
  if (!authSession) {
    return (
      <>
        <PinScreen
          coachPin={coachPin}
          students={students}
          onLoginCoach={() => setAuthSession({ role: 'coach' })}
          onLoginStudent={(student) =>
            setAuthSession({ role: 'student', studentId: student.id })
          }
        />
        <OfflineIndicator />
      </>
    );
  }

  // 2. Öğrenci PIN'i girilmişse: Öğrencinin test yükleme ve takip paneli
  if (authSession.role === 'student') {
    const currentStudent =
      students.find((s) => s.id === authSession.studentId) || students[0];
    const currentStudentArchives = examArchives.filter(
      (a) => !a.studentId || a.studentId === currentStudent?.id
    );
    const currentStudentTasks = tasks.filter(
      (t) => !t.studentId || t.studentId === currentStudent?.id
    );
    const currentStudentNotes = notes.filter(
      (n) => !n.studentId || n.studentId === currentStudent?.id
    );

    return (
      <>
        <StudentPortalView
          student={currentStudent}
          studentArchives={currentStudentArchives}
          studentTasks={currentStudentTasks}
          coachNotes={currentStudentNotes}
          onToggleTask={handleToggleTask}
          curriculum={curriculum}
          onLogout={() => setAuthSession(null)}
          onSaveExamArchive={handleSaveExamArchive}
        />
        <OfflineIndicator />
      </>
    );
  }

  // Calculate new uploaded exams count for coach notifications
  const newUploadedExamsCount = examArchives.filter((a) => a.isNew).length;

  // 3. Koç PIN'i girilmişse: Tam yetkili koçluk ve yönetim sistemi
  return (
    <div className="min-h-screen bg-slate-100/60 text-slate-900 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Top Main Navigation Header */}
      <CoachingHeader
        students={students}
        selectedStudent={activeStudent}
        onSelectStudent={handleSelectStudent}
        viewMode={viewMode}
        onChangeViewMode={(mode) => setViewMode(mode)}
        onOpenAddStudent={() => setIsAddStudentOpen(true)}
        onOpenAiAsk={() => setIsAiAskOpen(true)}
        isMobileMenuOpen={isMobileMenuOpen}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        coachPin={coachPin}
        newExamCount={newUploadedExamsCount}
        onLogout={() => setAuthSession(null)}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {viewMode === 'curriculum' ? (
          <GlobalCurriculumView
            curriculum={curriculum}
            onAddKazanim={handleAddKazanim}
            onUpdateKazanim={handleUpdateKazanim}
            onBulkAddKazanimlar={handleBulkAddKazanimlar}
            onDeleteKazanim={handleDeleteKazanim}
            onClearAllCurriculum={handleClearAllCurriculum}
          />
        ) : viewMode === 'students' || !activeStudent ? (
          <StudentListView
            students={students}
            selectedStudent={activeStudent}
            archives={examArchives}
            onSelectStudent={handleSelectStudent}
            onOpenAddStudent={() => setIsAddStudentOpen(true)}
            onDeleteStudent={handleDeleteStudent}
          />
        ) : (
          <StudentProfileView
            student={activeStudent}
            activeTab={activeTab}
            onTabChange={(tab) => setActiveTab(tab)}
            onBackToList={() => setViewMode('students')}
            newUploadsCount={studentArchives.filter((a) => a.isNew).length}
          >
            {activeTab === 'genel' && (
              <GeneralInfoTab
                student={activeStudent}
                onUpdateStudent={handleUpdateStudent}
              />
            )}

            {activeTab === 'koc-notlari' && (
              <CoachNotesTab
                notes={studentNotes}
                onAddNote={handleAddNote}
                onDeleteNote={handleDeleteNote}
                studentName={activeStudent.adSoyad}
              />
            )}

            {activeTab === 'calisma-programi' && (
              <DailyStudiesTab
                tasks={studentTasks}
                onAddTask={handleAddTask}
                onToggleComplete={handleToggleTask}
                onDeleteTask={handleDeleteTask}
                studentName={activeStudent.adSoyad}
              />
            )}

            {activeTab === 'soru-takibi' && (
              <QuestionsTab
                questions={studentQuestions}
                onAddQuestion={handleAddQuestion}
                onDeleteQuestion={handleDeleteQuestion}
                studentName={activeStudent.adSoyad}
              />
            )}

            {activeTab === 'denemeler' && (
              <ExamsTab
                exams={studentExams}
                onAddExam={handleAddExam}
                onDeleteExam={handleDeleteExam}
                studentId={activeStudent.id}
                studentName={activeStudent.adSoyad}
              />
            )}

            {activeTab === 'kazanimlar' && (
              <OutcomesTab
                curriculum={curriculum}
                onAddKazanim={handleAddKazanim}
                onBulkAddKazanimlar={handleBulkAddKazanimlar}
                onDeleteKazanim={handleDeleteKazanim}
                studentName={activeStudent.adSoyad}
              />
            )}

            {activeTab === 'raporlar' && (
              <ReportsTab
                student={activeStudent}
                exams={studentExams}
                questions={studentQuestions}
                curriculum={curriculum}
                examArchives={studentArchives}
              />
            )}

            {activeTab === 'sinav-analiz' && (
              <ExamAnalysisTab
                student={activeStudent}
                onSaveExamArchive={handleSaveExamArchive}
                onNavigateToHistory={() => setActiveTab('sinav-gecmisi')}
              />
            )}

            {activeTab === 'sinav-gecmisi' && (
              <ExamHistoryTab
                archives={studentArchives}
                onDeleteArchive={handleDeleteArchive}
                onSaveExamArchive={handleSaveExamArchive}
                studentName={activeStudent.adSoyad}
              />
            )}
          </StudentProfileView>
        )}
      </main>

      {/* Add Student Modal */}
      {isAddStudentOpen && (
        <AddStudentModal
          isOpen={isAddStudentOpen}
          onClose={() => setIsAddStudentOpen(false)}
          onSave={handleAddStudent}
          onAdd={handleAddStudent}
        />
      )}

      {/* AI Coach Assistant Drawer / Modal */}
      {isAiAskOpen && (
        <AICoachAskModal
          isOpen={isAiAskOpen}
          onClose={() => setIsAiAskOpen(false)}
          activeStudent={activeStudent}
        />
      )}

      {/* Global Footer */}
      <footer className="bg-white border-t border-slate-200/80 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900">Eğitim Koçluğu Portalı</span>
            <span>— YKS & MEB Müfredat Yönetim Sistemi</span>
          </div>
          <div className="text-slate-400">
            Optik Fotoğraf Analizi • Soru & Kazanım Takibi • Yapay Zekâ Koçluk Reçeteleri
          </div>
        </div>
      </footer>
      {/* Offline Connectivity Indicator */}
      <OfflineIndicator />
    </div>
  );
}
