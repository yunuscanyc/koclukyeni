import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

// Use connection string if available, otherwise individual parameters
const isConfigured = Boolean(
  process.env.DATABASE_URL ||
  (process.env.PGHOST && process.env.PGUSER && process.env.PGPASSWORD)
);

let pool: pg.Pool | null = null;
let useMemoryFallback = !isConfigured;

if (isConfigured) {
  try {
    const sslOption = process.env.DATABASE_URL?.includes('sslmode=disable')
      ? false
      : (process.env.PGSSL === 'true' || process.env.DATABASE_URL?.includes('sslmode=require'))
        ? { rejectUnauthorized: false }
        : false;

    const config: pg.PoolConfig = process.env.DATABASE_URL
      ? { connectionString: process.env.DATABASE_URL, ssl: sslOption }
      : {
          host: process.env.PGHOST,
          port: parseInt(process.env.PGPORT || '5432', 10),
          user: process.env.PGUSER,
          password: process.env.PGPASSWORD,
          database: process.env.PGDATABASE,
          ssl: sslOption,
        };

    pool = new Pool({
      ...config,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 3000,
    });

    pool.on('error', (err) => {
      console.warn('Unexpected error on idle PostgreSQL client, falling back to memory database:', err.message);
      useMemoryFallback = true;
    });

    // Test connection on boot
    pool.query('SELECT NOW()')
      .then(() => {
        console.log('✅ PostgreSQL remote database successfully connected!');
        useMemoryFallback = false;
      })
      .catch((err) => {
        console.warn('PostgreSQL Connection failed, falling back to memory database. Error:', err.message);
        useMemoryFallback = true;
      });
  } catch (e: any) {
    console.warn('Failed to configure PostgreSQL pool, falling back to memory. Error:', e.message);
    useMemoryFallback = true;
  }
} else {
  console.log('PostgreSQL credentials not provided in env. Example seed memory database active.');
}

export { pool, useMemoryFallback };

/**
 * Automatically creates PostgreSQL tables if they don't exist yet.
 */
export async function initializeDatabaseSchema() {
  if (useMemoryFallback || !pool) {
    return;
  }

  let client: pg.PoolClient | null = null;
  try {
    client = await pool.connect();
    await client.query('BEGIN');

    // 1. Students Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS students (
        id VARCHAR(100) PRIMARY KEY,
        pin_code VARCHAR(10) NOT NULL,
        ad_soyad VARCHAR(150) NOT NULL,
        dogum_tarihi VARCHAR(50),
        kayit_tarihi VARCHAR(50),
        sinif VARCHAR(50) NOT NULL,
        alan VARCHAR(50) NOT NULL,
        yks_hedef_yili VARCHAR(10),
        hedef_universite VARCHAR(250),
        hedef_bolum VARCHAR(250),
        hedef_puan VARCHAR(50),
        hedef_siralama VARCHAR(50),
        durum VARCHAR(50) NOT NULL,
        koc_notu TEXT,
        avatar_bg VARCHAR(50)
      )
    `);

    // 2. Notes Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS notes (
        id VARCHAR(100) PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        tarih VARCHAR(50) NOT NULL,
        kategori VARCHAR(100) NOT NULL,
        oncelik VARCHAR(50) NOT NULL,
        baslik VARCHAR(250) NOT NULL,
        icerik TEXT NOT NULL
      )
    `);

    // 3. Tasks Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS tasks (
        id VARCHAR(100) PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        tarih VARCHAR(50) NOT NULL,
        baslangic_saati VARCHAR(20),
        hedef_sure_dakika INTEGER NOT NULL,
        gorev_turu VARCHAR(100) NOT NULL,
        ders VARCHAR(100) NOT NULL,
        konu VARCHAR(250) NOT NULL,
        hedef_soru_sayisi INTEGER,
        hedef_kazanim VARCHAR(250),
        koc_aciklamasi TEXT,
        durum VARCHAR(50) NOT NULL,
        ogrenci_notu TEXT
      )
    `);

    // 4. Questions Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS questions (
        id VARCHAR(100) PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        tarih VARCHAR(50) NOT NULL,
        ders VARCHAR(100) NOT NULL,
        konu VARCHAR(250) NOT NULL,
        kaynak_kitap VARCHAR(250),
        hedef_soru INTEGER NOT NULL,
        cozulen_soru INTEGER NOT NULL,
        dogru_sayisi INTEGER,
        yanlis_sayisi INTEGER,
        bos_sayisi INTEGER,
        net NUMERIC(6, 2)
      )
    `);

    // 5. Exams Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS exams (
        id VARCHAR(100) PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        ogrenci_ad_soyad VARCHAR(150),
        sinav_turu VARCHAR(20) NOT NULL,
        deneme_adi VARCHAR(250) NOT NULL,
        yayin VARCHAR(250),
        tarih VARCHAR(50) NOT NULL,
        toplam_net NUMERIC(6, 2) NOT NULL,
        puan NUMERIC(8, 2),
        siralama INTEGER,
        toplam_katilimci INTEGER,
        koc_yorumu TEXT,
        dersler TEXT -- Stores DersNetDetay[] as JSON string
      )
    `);

    // 6. Curriculum Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS curriculum (
        id VARCHAR(100) PRIMARY KEY,
        sinif VARCHAR(50) DEFAULT '12. Sınıf',
        sinav_turu VARCHAR(20) NOT NULL,
        ders VARCHAR(100) NOT NULL,
        konu VARCHAR(250) NOT NULL,
        kazanim_kodu VARCHAR(100) NOT NULL,
        aciklama TEXT NOT NULL,
        onem_derecesi VARCHAR(50),
        yil VARCHAR(10)
      )
    `);

    // 7. Archives Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS archives (
        id VARCHAR(100) PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        ogrenci_ad_soyad VARCHAR(150),
        sinav_turu VARCHAR(20) NOT NULL,
        sinav_adi VARCHAR(250) NOT NULL,
        tarih VARCHAR(50) NOT NULL,
        toplam_soru INTEGER,
        dogru_sayisi INTEGER,
        yanlis_sayisi INTEGER,
        bos_sayisi INTEGER,
        net NUMERIC(6, 2),
        sorular TEXT, -- Stores SoruAnalizDetay[] as JSON string
        is_new BOOLEAN DEFAULT true,
        ogrenci_yukledi BOOLEAN DEFAULT false,
        yukleme_zamani VARCHAR(50),
        durum VARCHAR(50) DEFAULT 'Yeni',
        ai_status VARCHAR(50) DEFAULT 'completed',
        ai_status_message TEXT,
        ogrenci_notu TEXT,
        sayfa_fotolari TEXT
      )
    `);

    // Ensure backwards compatibility with any existing tables
    await client.query(`
      ALTER TABLE archives ADD COLUMN IF NOT EXISTS is_new BOOLEAN DEFAULT true;
      ALTER TABLE archives ADD COLUMN IF NOT EXISTS ogrenci_yukledi BOOLEAN DEFAULT false;
      ALTER TABLE archives ADD COLUMN IF NOT EXISTS yukleme_zamani VARCHAR(50);
      ALTER TABLE archives ADD COLUMN IF NOT EXISTS durum VARCHAR(50) DEFAULT 'Yeni';
      ALTER TABLE archives ADD COLUMN IF NOT EXISTS ai_status VARCHAR(50) DEFAULT 'completed';
      ALTER TABLE archives ADD COLUMN IF NOT EXISTS ai_status_message TEXT;
      ALTER TABLE archives ADD COLUMN IF NOT EXISTS ogrenci_notu TEXT;
      ALTER TABLE archives ADD COLUMN IF NOT EXISTS sayfa_fotolari TEXT;
      ALTER TABLE tasks ADD COLUMN IF NOT EXISTS ogrenci_notu TEXT;
      ALTER TABLE curriculum ADD COLUMN IF NOT EXISTS sinif VARCHAR(50) DEFAULT '12. Sınıf';
    `);

    await client.query('COMMIT');
    console.log('PostgreSQL database schemas successfully initialized.');
  } catch (error: any) {
    if (client) {
      try { await client.query('ROLLBACK'); } catch {}
    }
    console.error('Failed to initialize PostgreSQL database schema, falling back to memory database:', error.message);
    useMemoryFallback = true;
  } finally {
    if (client) {
      try { client.release(); } catch {}
    }
  }
}
